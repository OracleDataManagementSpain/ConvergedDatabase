#!/bin/bash
#
# =========================================================================================
# Script Name : stop_DBSecLab.sh
#
# Parameter   : None
#
# Notes       : Stop all DBSecLab componants (Glassfish App, OEM13c Console and DBs)
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "===== BEGIN: stop_DBSecLab.sh ====="
echo

# Stopping Oracle DB
#${DBSEC_ADMIN}/stop_cdb.sh cdb1

# Stopping GlassFish App
${DBSEC_ADMIN}/stop_Glassfish.sh

# Starting OEM: OMR + OMS
${DBSEC_ADMIN}/stop_em.sh

# Stopping Oracle DB Listener
#${DBSEC_ADMIN}/stop_listener.sh

# Stopping Markdown Web Server
#${DBSEC_ADMIN}/stop_mdws.sh

echo
echo "===== END: stop_DBSecLab.sh ====="
echo
