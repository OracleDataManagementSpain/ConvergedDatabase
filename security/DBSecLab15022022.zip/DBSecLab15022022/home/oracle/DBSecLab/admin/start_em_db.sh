#!/bin/bash
#
# =========================================================================================
# Script Name : start_em_db.sh
#
# Parameter   : None
#
# Notes       : Start OEM repository database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Start OEM repository database..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-emrep.sh

if [ `ps -ef | grep ora_smon_${ORACLE_SID} | grep -v grep | wc -l` -eq 0 ]; then

  echo
  echo ". Starting the Database and Listener"

  $ORACLE_HOME/bin/lsnrctl start ${OEM_LISTENER}

  $ORACLE_HOME/bin/sqlplus '/as sysdba'<<EOF

     startup;
     alter system register;
     exit;

EOF

else

  echo 
  echo ". It appears ${ORACLE_SID} is already started!"

fi

echo
