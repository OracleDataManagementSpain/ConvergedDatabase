#!/bin/bash
#
# =========================================================================================
# Script Name : stop_em_oms.sh
#
# Parameter   : None
#
# Notes       : Stop OEM OMS
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Stop OEM OMS..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-emrep.sh

echo
echo ". Stop OEM OMS"
echo "--- Begin :`date`"
${OMS_HOME}/bin/emctl stop oms -all -force

echo
echo "--- End :`date`"

echo
