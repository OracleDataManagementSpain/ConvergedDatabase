#!/bin/bash
#
# =========================================================================================
# Script Name : stop_cdb.sh
#
# Parameter   : $1   CDB_NAME
#               $2   PDB_NAME
#
# Notes       : Stop Oracle Database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Stop the Oracle Database ${ORACLE_SID}_${PDB_NAME}..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-cdb.sh $1 $2

echo
echo ". Stop the database"

${ORACLE_HOME}/bin/sqlplus '/as sysdba'<<EOF

shutdown immediate;

exit;
EOF

echo
