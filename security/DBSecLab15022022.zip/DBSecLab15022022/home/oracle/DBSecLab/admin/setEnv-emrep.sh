#!/bin/bash
#
# =========================================================================================
# Script Name : setEnv-emrep.sh
#
# Parameter   : None
#
# Notes       : Set OEM Repository global variables
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# HLO           10/12/2021      Updates for Livelabs-v4 (JAVA_HOME)
# =========================================================================================

#############################################################################
# Set DB Variables
# ---------------------------------------------------------------------------
# Oracle Settings
export ORACLE_HOSTNAME="dbsec-lab"
export ORACLE_HOME="/u01/app/oracle/product/19.0.0/dbhome_1"
export ORACLE_SID="emcdb"
export PDB_NAME="emrep"
export OEM_LISTENER="LISTENER"
export PATH="$ORACLE_HOME/bin:$PATH"

#############################################################################
# Set Components Variables
# ---------------------------------------------------------------------------
# Oracle EMCLI
export OMS_HOME="/u01/app/oracle/middleware2"
export AGENT_HOME="/u01/app/oracle/agent/agent_13.5.0.0.0"
export PATH="${PATH}:${OMS_HOME}/bin"

# Glassfish
export GLASSFISH_HOME="/u01/app/glassfish"

# Java
export JAVA_HOME="/u01/app/jdk1.8.0_201"
export PATH="$JAVA_HOME/bin:$PATH"

#############################################################################
# Set Labs Variables
# ---------------------------------------------------------------------------
# Scripts Directories
export DBSEC_HOME="/home/oracle/DBSecLab"
export DBSEC_ADMIN="$DBSEC_HOME/admin"

#############################################################################
# Display Info
# ---------------------------------------------------------------------------
#echo "=========================================================================="
#figlet OEM Rep Info
echo "=========================================================================="
echo "                  WARNING: YOU ARE USING OEM REPO ENV                     "
echo "--------------------------------------------------------------------------"
echo " . ORACLE_SID  = ${ORACLE_SID}"
echo " . PDB_NAME    = ${PDB_NAME}"
echo " . ORACLE_HOME = ${ORACLE_HOME}"
echo "--------------------------------------------------------------------------"
echo "                      USE THIS SCRIPT TO CHANGE ENV                       "
echo "       source /home/oracle/DBSecLab/admin/setEnv-cdb.sh <CDB> <PDB>       "
echo "=========================================================================="
echo " "
