#!/bin/bash
#
# =========================================================================================
# Script Name : stop_listener.sh
#
# Parameter   : None
#
# Notes       : Stop Database Listener
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Stop the Oracle Database Listener..."
echo "=============================================================================="

tnslsnr=`which tnslsnr`

if [ `ps -ef | grep $tnslsnr | grep -v grep | wc -l` -eq 0 ]; then

  echo
  echo ". The listener $tnslsnr appears to already be stopped!"

else

  echo 
  echo ". Stopping the Oracle listener"
  ${ORACLE_HOME}/bin/lsnrctl stop ${ORACLE_LISTENER}

fi

echo
