#!/bin/bash

# =========================================================================================
# Script Name : start_ogg.sh
#
# Parameter   : None
#
# Notes       : Start Oracle Golden Gate Services
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Start Oracle Golden Gate Services..."
echo "=============================================================================="

echo
echo ". Start Oracle Golden Gate"
${OGG_BIN_HOME}/startSM.sh

echo
echo ". Login to the GoldenGate Administration Server at http://${PUBLIC_IP}:50002"

echo
