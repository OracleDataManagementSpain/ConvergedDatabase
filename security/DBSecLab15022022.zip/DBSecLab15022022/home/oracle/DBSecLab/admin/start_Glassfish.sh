#!/bin/bash
#
# =========================================================================================
# Script Name : start_Glassfish.sh
#
# Parameter   : None
#
# Notes       : Start Glassfish App
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Start Glassfish App..."
echo "=============================================================================="

if [ `ps -ef | grep $GLASSFISH_HOME | grep -v grep | wc -l` -eq 0 ]; then

  ${GLASSFISH_HOME}/glassfish4/bin/asadmin start-domain & 
  sleep 15
  echo
  echo ". You can login to the apps using the appropriate URL:"
  echo
  ${GLASSFISH_HOME}/glassfish4/bin/asadmin list-applications | grep "hr" | awk -v public_ip="${PUBLIC_IP}" '{print "http://" public_ip ":8080/"$1}'
  echo

else

  echo
  echo ". It appears glassfish is already started!"

fi

echo
