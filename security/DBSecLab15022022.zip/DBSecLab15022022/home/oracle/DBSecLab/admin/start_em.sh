#!/bin/bash
#
# =========================================================================================
# Script Name : start_em.sh
#
# Parameter   : None
#
# Notes       : Start OEM (Repository DB, OMS and Agent)
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Start OEM (Repository DB, OMS and Agent)..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-emrep.sh

#${DBSEC_ADMIN}/start_em_db.sh #Service managed
${DBSEC_ADMIN}/start_em_oms.sh
${DBSEC_ADMIN}/start_em_agent.sh

echo
