#!/bin/bash
#
# =========================================================================================
# Script Name : start_DBSecLab.sh
#
# Parameter   : None

#
# Notes       : Start all DBSecLab componants (Glassfish App, OEM13c Console and DBs)
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

CHECK_FILE=`grep "dbsec-lab.localdomain" /etc/hosts | wc -l`
if [ $CHECK_FILE -lt 1 ]; then
  echo
  echo "*********************************************************************************"
  echo "                                                                                 "  
  echo "  ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR  "
  echo "                                                                                 "  
  echo "        In the config file /etc/hosts, dbsec-lab.localdomain must be set         "
  echo "                  Please modify it and execute the script again                  "
  echo "                                                                                 "  
  echo "*********************************************************************************"
  exit 1
fi

CHECK_FILE=`grep "PRESERVE_HOSTINFO=2" /etc/oci-hostname.conf | wc -l`
if [ $CHECK_FILE -lt 1 ]; then
  echo
  echo "*********************************************************************************"
  echo "                                                                                 "  
  echo "  ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR ERROR  "
  echo "                                                                                 "  
  echo "  In the config file /etc/oci-hostname.conf, PRESERVE_HOSTINFO must be set to 3  "
  echo "                  Please modify it and execute the script again                  "
  echo "                                                                                 "  
  echo "*********************************************************************************"
  exit 1
fi

echo
echo "===== BEGIN: start_DBSecLab.sh ====="
echo

. /home/oracle/DBSecLab/admin/setEnv-cdb.sh cdb1 pdb1

# Starting Oracle DB and listener
#${DBSEC_ADMIN}/start_cdb.sh cdb1

# Starting GlassFish App
${DBSEC_ADMIN}/start_Glassfish.sh

# Starting OEM: OMR + OMS
${DBSEC_ADMIN}/start_em.sh

# Starting Markdown Web Server
#${DBSEC_ADMIN}/start_mdws.sh

echo
echo "===== END: start_DBSecLab.sh ====="
echo
