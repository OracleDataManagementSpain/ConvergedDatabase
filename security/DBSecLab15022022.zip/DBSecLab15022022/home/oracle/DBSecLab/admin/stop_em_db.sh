#!/bin/bash
#
# =========================================================================================
# Script Name : stop_em_db.sh
#
# Parameter   : None
#
# Notes       : Stop OEM repository database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Stop the Oracle Database ${ORACLE_SID}_${PDB_NAME}..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-emrep.sh

echo
echo ". Stop the database"

$ORACLE_HOME/bin/sqlplus '/as sysdba'<<EOF

shutdown immediate;

exit;
EOF

#$ORACLE_HOME/bin/lsnrctl stop ${OEM_LISTENER}
echo
