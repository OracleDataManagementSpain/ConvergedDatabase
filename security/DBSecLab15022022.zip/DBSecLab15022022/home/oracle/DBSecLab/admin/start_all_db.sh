#!/bin/bash
. /home/oracle/DBSecLab/admin/setEnv-cdb.sh cdb1 pdb1
export ORAENV_ASK=NO
. oraenv

export ORAENV_ASK=YES

dbstart $ORACLE_HOME
