#!/bin/bash
#
# =========================================================================================
# Script Name : start_mdws.sh
#
# Parameter   : None
#
# Notes       : Start grip Markdown Web Server 
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Start grip Markdown Web Server..."
echo "=============================================================================="

if [ -z ${PUBLIC_IP} ]; then 
 echo
 echo ". Your Public IP was empty... sourcing the environment scripts"
 source ${DBSEC_ADMIN}/setEnv-cdb.sh cdb1 pdb1
fi

echo 
echo ". Launching the Markdown Web Service"
sudo grip --norefresh $DBSEC_HOME/README.md 10.0.0.150:80 > /dev/null 2>&1 &

#echo
#echo "Open your Web Browser at http://${PUBLIC_IP}:80 to access the README.md file"

echo
