#!/bin/bash
#
# =========================================================================================
# Script Name : start_em_agent.sh
#
# Parameter   : None
#
# Notes       : Start OEM agent
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Start OEM agent..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-emrep.sh

echo
echo ". Start OEM agent"
${AGENT_HOME}/bin/emctl start agent

echo
