#!/bin/bash
#
# =========================================================================================
# Script Name : stop_em.sh
#
# Parameter   : None
#
# Notes       : Stop OEM (Repository DB, OMS and Agent)
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Stop OEM (Repository DB, OMS and Agent)..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-emrep.sh

#${DBSEC_ADMIN}/stop_em_db.sh
${DBSEC_ADMIN}/stop_em_oms.sh
${DBSEC_ADMIN}/stop_em_agent.sh

echo
