#!/bin/bash

# =========================================================================================
# Script Name : setEnv-cdb.sh
#
# Parameter   : $1   CDB_NAME
#               $2   PDB_NAME
#
# Notes       : Set DBSecLab global variables
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           24/11/2020      Updates for Livelabs-v2
# HLO           10/12/2021      Updates for Livelabs-v4 (JAVA_HOME)
# =========================================================================================

#############################################################################
# Set DB Variables
# ---------------------------------------------------------------------------
# Oracle Settings
export ORACLE_BASE="/u01/app/oracle"
export ORACLE_HOME="${ORACLE_BASE}/product/19.0.0/dbhome_1"
export ORACLE_HOSTNAME="dbsec-lab"
export ORA_INVENTORY="/u01/app/oraInventory"
export TMP="/tmp"
export TMPDIR="${TMP}"
export PATH="/usr/sbin:/usr/local/bin:${PATH}"
export PATH="${ORACLE_HOME}/bin:${PATH}:/u01/app/sqlcl/bin"
export LD_LIBRARY_PATH="${ORACLE_HOME}/lib:/lib:/usr/lib"
export CLASSPATH="${ORACLE_HOME}/jlib:${ORACLE_HOME}/rdbms/jlib"

# CDB Settings
oracle_instance=""
cdb="$1"
pdb="$2"

if [ -z ${pdb} ] 
 then
   pdb="pdb1"
fi

# if filename argument is not supplied at the command prompt
case $# in
  0) echo " "
     echo "Using default values : ORCLE_SID=${ORACLE_SID}, PDB_NAME=${PDB_NAME}"
     echo "Usage: $0 ORACLE_SID [PDB_NAME]"
     echo " "
     cdb="${ORACLE_SID}"
     pdb="${PDB_NAME}"
     ;;
  1) cdb="${cdb}"
     pdb="${pdb}"
     ;;
  2) cdb="${cdb}"
     pdb="${pdb}"
     ;;
  *) echo " "
     echo "Using values : ORCLE_SID=${cdb}, PDB_NAME=${pdb}"
     echo "WARNING : other arguments ignored"
     echo " "
     echo "Usage: $0 ORACLE_SID [PDB_NAME]"
     echo " "
esac

export ORACLE_SID="${cdb}"
export ORACLE_UNQNAME="${cdb}"
export PDB_NAME="${pdb}"
export DATA_DIR="/u01/oradata/${cdb}"
export ORACLE_LISTENER="LISTENER"

#############################################################################
# Set Components Variables
# ---------------------------------------------------------------------------
# Glassfish
export GLASSFISH_HOME="/u01/app/glassfish"
export JAVA_HOME="/u01/app/jdk1.8.0_201"
export PATH="$PATH:$JAVA_HOME/bin"

# Oracle EMCLI
export OMS_HOME="${ORACLE_BASE}/middleware2"
export AGENT_HOME="${ORACLE_BASE}/agent/agent_13.5.0.0.0"
export PATH="${PATH}:${OMS_HOME}/bin"

# GoldenGate
export OGG_HOME="${ORACLE_BASE}/product/ogg"
export OGG_BIN_HOME="${ORACLE_BASE}/ogg_conf/bin"
export OGG_VAR_HOME="${ORACLE_BASE}/ogg_conf/var"
export OGG_ETC_HOME="${ORACLE_BASE}/ogg_conf/etc"
export PATH="$PATH:${OGG_BIN_HOME}"

# Data Safe
export DS_HOME="/u01/app/ds_connectors"

#SwingBench
export SWBENCH_HOME="/u01/app/swingbench"

#############################################################################
# Set Labs Variables
# ---------------------------------------------------------------------------
# Livelabs Scripts Directories
export DBSEC_HOME="/home/oracle/DBSecLab"
export DBSEC_ADMIN="$DBSEC_HOME/admin"
export DBSEC_LABS="$DBSEC_HOME/livelabs"

# Database Users
export DBUSR_AVAUDIT="avaudituser"
export DBUSR_DBA1="dba_harvey"
export DBUSR_DBA2="dba_debra"
export DBUSR_DBA3="dba_nicole"
export DBUSR_DBA4="dba_junior"
export DBUSR_DS_ADMIN="DS_ADMIN"
export DBUSR_DBV_OWNER="c##dvowner"
export DBUSR_DBV_SAL="c##sec_dba_sal"
export DBUSR_EMPPROD="employeesearch_prod"
export DBUSR_EMPDEV="employeesearch_dev"
export DBUSR_OGGADMIN="c##avggadmin"
export DBUSR_OLS_OWNER="c##oscar_ols"
export DBUSR_OLS_LBAC="lbacsys"
export DBUSR_PA="pa_admin"
export DBUSR_PU="pu_pete"
export DBUSR_SYS="sys"
export DBUSR_SYSTEM="system"
export DBUSR_TSDP="tsdp_labs"
export DBUSR_TSDPADMIN="tsdp_admin"
#
export DBUSR_PWD="Oracle123"

# AVS
export AVCLI_HOME="/u01/app/avcli"
export AV_HOME="/u01/app/avagent"
export PATH="$PATH:$AV_HOME/bin"

# TDE/OKV
export BACKUP_FILE="/u01/oradata/bkp_${ORACLE_SID}_pre-tde.tar"
export WALLET_DIR="/etc/ORACLE/WALLETS/${ORACLE_SID}"
export TDE_HOME="${WALLET_DIR}/tde"
export SEPS_WALLET_DIR="${WALLET_DIR}/tde_seps"
export OKV_USRADM="kvrestadmin"
export OKV_HOME="${WALLET_DIR}/okv"
export OKV_RESTHOME="/u01/app/okvrest"
export PATH="$PATH:${OKV_HOME}/bin:${OKV_RESTHOME}/bin"

#############################################################################
# Set System Variables
# ---------------------------------------------------------------------------
# Alias
alias diag='cd ${ORACLE_BASE}/diag/rdbms/$ORACLE_SID/$ORACLE_SID/trace;pwd'
alias ga=' git add --all :/; git commit -m "update dbsec vm"; git push'
alias l='ls -alrt'
alias labs='cd $DBSEC_LABS;pwd'
alias python=python3
alias rman='rlwrap rman'
alias sqlplus='rlwrap $ORACLE_HOME/bin/sqlplus'
alias sq='sqlplus -s'
alias sqsys='sq / as sysdba'
alias ud="cd $DBSEC_HOME; ./update_workshop.sh; cd -"

# Start DBSecLab components
alias start_all='$DBSEC_HOME/start_DBSecLab.sh'
alias stop_all='$DBSEC_HOME/stop_DBSecLab.sh'

# Start and Stop CDB
alias start_db='$DBSEC_ADMIN/start_cdb.sh'
alias stop_db='$DBSEC_ADMIN/stop_cdb.sh'

# This sets the env variable for the IP addresses
export PUBLIC_IP=`python3 $DBSEC_ADMIN/publicip.py`
export PRIVATE_IP=`hostname -I | awk '{print $1}'`

#############################################################################
# Display Info
# ---------------------------------------------------------------------------
echo "=========================================================================="
figlet DBSecLabs v4
echo "=========================================================================="
echo "                               ENV VARIABLES                              "
echo "--------------------------------------------------------------------------"
echo " . ORACLE_SID  = ${ORACLE_SID}"
echo " . PDB_NAME    = ${PDB_NAME}"
echo " . DBSEC_HOME  = ${DBSEC_HOME}"
echo " . DBSEC_ADMIN = ${DBSEC_ADMIN}"
echo " . DBSEC_LABS  = ${DBSEC_LABS}"
echo " . ORACLE_HOME = ${ORACLE_HOME}"
echo " . DATA_DIR    = ${DATA_DIR}"
echo " . PRIVATE_IP  = ${PRIVATE_IP}"
echo " . PUBLIC_IP   = ${PUBLIC_IP}"
echo "--------------------------------------------------------------------------"
echo "                      USE THIS SCRIPT TO CHANGE ENV                       "
echo "       source /home/oracle/DBSecLab/admin/setEnv-cdb.sh <CDB> <PDB>       "
echo "=========================================================================="
echo " "
