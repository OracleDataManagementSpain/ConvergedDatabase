#!/bin/bash
#
# =========================================================================================
# Script Name : start_cdb.sh
#
# Parameter   : $1   CDB_NAME
#               $2   PDB_NAME
#
# Notes       : Start Oracle Database and Listener
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Start the Oracle Database ${ORACLE_SID} and its Listener..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-cdb.sh $1 $2

if [ -z ${ORACLE_SID} ]; then

  echo
  echo "!!! WARNING !!!"
  echo "ORACLE_SID is null, setting to the default of cdb1"
  echo
  ORACLE_SID=cdb1

fi

if [ `ps -ef | grep ora_smon_${ORACLE_SID} | grep -v grep | wc -l` -eq 0 ]; then

  echo
  echo ". Starting the Database"
  
  ${ORACLE_HOME}/bin/sqlplus '/as sysdba'<<EOF

    startup;
    alter system register;
    show pdbs
    exit;

EOF

else
  echo 
  echo ". The database $ORACLE_SID appears to already be running!"
fi

tnslsnr=`which tnslsnr`

if [ `ps -ef | grep $tnslsnr | grep -v grep | wc -l` -eq 0 ]; then

  echo
  echo ". Starting the Oracle listener"
  ${ORACLE_HOME}/bin/lsnrctl start ${ORACLE_LISTENER}

else

  echo 
  echo ". The listener $tnslsnr appears to already be running!"

fi 

echo
