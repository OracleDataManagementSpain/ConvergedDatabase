#!/bin/bash
#
# =========================================================================================
# Script Name : stop_em_agent.sh
#
# Parameter   : None
#
# Notes       : Stop OEM agent
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           04/10/2019      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Stop OEM agent..."
echo "=============================================================================="

source ${DBSEC_ADMIN}/setEnv-emrep.sh

echo
echo ". Stop OEM agent"
${AGENT_HOME}/bin/emctl stop agent

echo
