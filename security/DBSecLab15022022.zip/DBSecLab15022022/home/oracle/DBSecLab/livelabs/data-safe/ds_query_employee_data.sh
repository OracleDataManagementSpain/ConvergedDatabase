#!/bin/bash

# =========================================================================================
# Script Name : ds_query_employee_data.sh
#
# Parameter   : None
#
# Notes       : View sensitive data for table DEMO_HR_EMPLOYEES in PROD and DEV environment
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           06/12/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " View sensitive data for table DEMO_HR_EMPLOYEES..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba <<EOF

set lines 200
set pages 999
col firstname       format a15
col lastname        format a15
col email           format a45
col phonemobile     format a20
col corporate_card  format a20

prompt
prompt ...in PROD
SELECT userid, firstname, lastname, email, phonemobile, startdate, corporate_card, salary
  FROM ${DBUSR_EMPPROD}.demo_hr_employees
 WHERE userid IN (73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91)
 ORDER BY 1;

prompt
prompt
prompt
prompt ...in DEV
SELECT userid, firstname, lastname, email, phonemobile, startdate, corporate_card, salary
  FROM ${DBUSR_EMPDEV}.demo_hr_employees
 WHERE userid IN (73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91)
 ORDER BY 1;

exit;
EOF

echo
