#!/bin/bash

# =========================================================================================
# Script Name : ds_restore_pdb1_dev.sh
#
# Parameter   : None
#
# Notes       : Reset the DEV tables on PDB1 by cloning data from PROD schema
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           07/12/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="
echo " Reset the ${DBUSR_EMPDEV}@PDB1 tables by cloning data"
echo " from ${DBUSR_EMPPROD}@PDB1 schema..."
echo "=============================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

set trimspool on;
set lines 180
set pages 999
set echo on;

show user;

prompt
prompt . Truncate the current DEV tables
TRUNCATE TABLE ${DBUSR_EMPDEV}.demo_hr_supplemental_data;
TRUNCATE TABLE ${DBUSR_EMPDEV}.demo_hr_roles;
TRUNCATE TABLE ${DBUSR_EMPDEV}.demo_hr_users;
TRUNCATE TABLE ${DBUSR_EMPDEV}.demo_hr_user_labels;
TRUNCATE TABLE ${DBUSR_EMPDEV}.demo_hr_employees;

prompt
prompt . Cloning PROD data into DEV tables
INSERT INTO ${DBUSR_EMPDEV}.demo_hr_employees          SELECT * FROM ${DBUSR_EMPPROD}.demo_hr_employees;
INSERT INTO ${DBUSR_EMPDEV}.demo_hr_roles              SELECT * FROM ${DBUSR_EMPPROD}.demo_hr_roles;
INSERT INTO ${DBUSR_EMPDEV}.demo_hr_supplemental_data  SELECT * FROM ${DBUSR_EMPPROD}.demo_hr_supplemental_data;
INSERT INTO ${DBUSR_EMPDEV}.demo_hr_users              SELECT * FROM ${DBUSR_EMPPROD}.demo_hr_users;
INSERT INTO ${DBUSR_EMPDEV}.demo_hr_user_labels        SELECT * FROM ${DBUSR_EMPPROD}.demo_hr_user_labels;

commit;

exit;
EOF

echo
