#!/bin/bash

# =========================================================================================
# Script Name : ds_drop_user.sh
#
# Parameter   : $1   PDB_NAME
#
# Notes       : Drop the Data Safe ADMIN user on the pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           03/12/2021      Creation
# =========================================================================================

if [ -z "$1" ]; then
 echo
 echo "ERROR: You did not include a PDB name!"
 echo
 exit 1
else
 pdbname=$1
fi

echo
echo "=============================================================================="	
echo " Drop the Data Safe ADMIN user on pluggable database ${pdbname}..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${pdbname} as sysdba<<EOF
        
DROP USER ${DBUSR_DS_ADMIN} cascade;
          
exit;
EOF

echo
