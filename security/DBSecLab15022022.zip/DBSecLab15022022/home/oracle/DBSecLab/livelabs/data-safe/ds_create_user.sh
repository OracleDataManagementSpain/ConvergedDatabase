#!/bin/bash

# =========================================================================================
# Script Name : ds_create_user.sh
#
# Parameter   : $1   PDB_NAME
#
# Notes       : Create the Data Safe ADMIN user on the pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           03/12/2021      Creation
# =========================================================================================

if [ -z "$1" ]; then
 echo
 echo "ERROR: You did not include a PDB name!"
 echo
 exit 1
else
 pdbname=$1
fi

echo
echo "=============================================================================="	
echo " Create the Data Safe ADMIN user on pluggable database ${pdbname}..."
echo "=============================================================================="	

cd $DS_HOME/util
sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${pdbname} as sysdba<<EOF
        
DROP USER ${DBUSR_DS_ADMIN} cascade;
CREATE USER ${DBUSR_DS_ADMIN} IDENTIFIED BY ${DBUSR_PWD} DEFAULT TABLESPACE "USERS" TEMPORARY TABLESPACE "TEMP";
GRANT CONNECT, RESOURCE TO ${DBUSR_DS_ADMIN};
GRANT UNLIMITED TABLESPACE TO ${DBUSR_DS_ADMIN};
        
@datasafe_privileges.sql ${DBUSR_DS_ADMIN} GRANT ALL
          
exit;
EOF

echo
