#!/bin/bash

# =========================================================================================
# Script Name : nne_disable.sh
#
# Parameter   : None
#
# Notes       : Disable the Native Network Encryption mode
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# HLO           18/10/2021      Updates for Livelabs-v4
# =========================================================================================

echo
echo "=============================================================================="	
echo " Disable the Native Network Encryption mode..."
echo "=============================================================================="	

echo 
echo ". Existing sqlnet.ora file:"
cat ${ORACLE_HOME}/network/admin/sqlnet.ora

# Return the sqlnet.ora file to it's original state:
echo 
echo ". Remove SQLNET.ENCRYPTION_SERVER line..."
sed -i '/SQLNET.ENCRYPTION_SERVER/d' ${ORACLE_HOME}/network/admin/sqlnet.ora

echo 
echo ". New sqlnet.ora file:"
cat ${ORACLE_HOME}/network/admin/sqlnet.ora

echo ". Native Network Encryption is now disabled!"

echo
