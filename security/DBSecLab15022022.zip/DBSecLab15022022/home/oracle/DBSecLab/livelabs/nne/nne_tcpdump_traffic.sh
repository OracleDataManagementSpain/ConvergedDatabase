#!/bin/bash

# =========================================================================================
# Script Name : nne_tcpdump_traffic.sh
#
# Parameter   : None
#
# Notes       : Run tcpdump on the traffic to analyze the packets in transit on the network
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Run tcpdump on the traffic to analyze the packets in transit on the network..."
echo "=============================================================================="	

echo 
echo ". Run tcpdump in the background, monitoring port 1521"
sudo tcpdump -nnvvXSs 1514 -i any '(port 1521) and (length > 74)' -w tcpdump.pcap &
sleep 5

sqlplus ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

prompt
prompt . Execute SQL commands using PDB1 so we are on port 1521
select firstname, lastname, salary, address_1 from employeesearch_prod.demo_hr_employees;

exit;
EOF

sleep 6

echo 
echo ". Interupt (kill) the tcpdump process"
pid=$(ps -e | pgrep tcpdump)  
echo "...PID to kill is $pid"
sleep 5
sudo kill -2 $pid
echo "...process is now killed!"

echo 
echo ". View the output of our tcpdump file using strings"
strings tcpdump.pcap 

echo
