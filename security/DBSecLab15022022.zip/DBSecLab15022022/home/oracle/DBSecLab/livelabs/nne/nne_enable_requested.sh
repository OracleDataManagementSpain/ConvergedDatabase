#!/bin/bash

# =========================================================================================
# Script Name : nne_enable_requested.sh
#
# Parameter   : None
#
# Notes       : Enable Native Network Encryption in REQUESTED mode
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# HLO           18/10/2021      Updates for Livelabs-v4
# =========================================================================================

echo
echo "=============================================================================="	
echo " Enable Native Network Encryption in REQUESTED mode..."
echo "=============================================================================="	

echo
echo ". Modify \$ORACLE_HOME/network/admin/sqlnet.ora"
sed -i '/SQLNET.ENCRYPTION_SERVER/d' ${ORACLE_HOME}/network/admin/sqlnet.ora
echo -e "\nSQLNET.ENCRYPTION_SERVER=REQUESTED" >> ${ORACLE_HOME}/network/admin/sqlnet.ora

echo 
echo ". Display the new contents of the sqlnet.ora:"
cat ${ORACLE_HOME}/network/admin/sqlnet.ora

echo ". Native Network Encryption is now enabled!"

echo
