#!/bin/bash

# =========================================================================================
# Script Name : nne_view_sqlnet_ora.sh
#
# Parameter   : None
#
# Notes       : Displays the SQLNet.ora file content
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Displays the SQLNet.ora file content..."
echo "=============================================================================="	

echo
echo ". The contents of the sqlnet.ora are:"
cat ${ORACLE_HOME}/network/admin/sqlnet.ora

HAS_WALLET_ENTRY=`grep ENCRYPTION_WALLET_LOCATION ${ORACLE_HOME}/network/admin/sqlnet.ora | wc -l`

if [ $HAS_WALLET_ENTRY -gt 0 ]; then
 echo 
 echo "!!! The sqlnet.ora has an old parameter in it and we are going to remove it first !!!"

 echo 
 echo ". Copy the old sqlnet.ora"
 cp ${ORACLE_HOME}/network/admin/sqlnet.ora ${ORACLE_HOME}/network/admin/sqlnet.ora.has_wallet_location

 echo 
 echo ". Modify the new one correctly by deleting wrong lines"
 sed -i '/ENCRYPTION_WALLET_LOCATION/d' ${ORACLE_HOME}/network/admin/sqlnet.ora
 sed -i '/METHOD_DATA/d' ${ORACLE_HOME}/network/admin/sqlnet.ora
 sed -i '/\DIRECTORY\=/d' ${ORACLE_HOME}/network/admin/sqlnet.ora

 echo 
 echo ". Let's view the new sqlnet.ora now"
 cat ${ORACLE_HOME}/network/admin/sqlnet.ora

fi 

echo
