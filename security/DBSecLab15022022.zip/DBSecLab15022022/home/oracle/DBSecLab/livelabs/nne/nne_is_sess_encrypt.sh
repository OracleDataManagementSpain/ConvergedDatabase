#!/bin/bash

# =========================================================================================
# Script Name : nne_is_sess_encrypt.sh
#
# Parameter   : None
#
# Notes       : Check if the network is already encrypted
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Check if the network is already encrypted..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@pdb1 <<EOF

set lines 140
set pages 999
col username format a20
col auth_type format a10
col network_service_banner format a45

BREAK ON SID SKIP PAGE ON SID

prompt
prompt . Query if there is a "Encryption service adapter" row in the query output
select a.sid, a.username, b.authentication_type as auth_type, regexp_substr(b.network_service_banner,'[^:]+',1,1 ) network_service_banner
  from V\$SESSION a
     , V\$SESSION_CONNECT_INFO b
 where a.sid = sys_context('userenv','sid')
   and a.sid = b.sid;

exit;
EOF
 
echo
