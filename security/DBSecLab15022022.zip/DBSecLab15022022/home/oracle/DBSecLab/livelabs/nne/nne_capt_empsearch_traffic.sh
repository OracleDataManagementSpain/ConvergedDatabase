#!/bin/bash

# =========================================================================================
# Script Name : nne_capt_empsearch_traffic.sh
#
# Parameter   : None
#
# Notes       : Capture the network traffic to analyze the packets in transit
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Capture the network traffic to analyze the packets in transit..."
echo "=============================================================================="	

if ! [ -x "$(command -v tcpflow)" ]; then
  echo
  echo "Error: tcpflow is not installed." >&2
  echo "Run: sudo yum install -y tcpflow"
  echo "Then try again!"
  exit 1
fi

echo
echo "-----------------------------------------------------------------"
echo "          !!! IMPORTANT - Before running this script !!!         "
echo "-----------------------------------------------------------------"
echo "- From your local Web browser, open the Glassfish App"
echo "  at http://${PUBLIC_IP}:8080/hr_prod_pdb1"
echo 
echo "- Login to the HR Application,"
echo "- Perform some search operations and then view the results here"
echo "-----------------------------------------------------------------"

echo
echo ". Run tcpflow to capture network traffic from the Glassfish HR application"
#sudo tcpflow -i any -c port 1521 -S enable_report=NO
sudo tcpflow -i any -C port 1521 -S enable_report=NO | egrep -i 'Oracle123|authenticate|password|hradmin|oracledemo|SELECT|FROM|WHERE|USER'

echo
