#!/bin/bash

# =========================================================================================
# Script Name : pa_generate_report.sh
#
# Parameter   : None
#
# Notes       : Generate report to analyze the workload captured
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           18/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Generate report to analyze the workload captured..."
echo "=============================================================================="

sqlplus -s ${DBUSR_PA}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 210
set pages 999
col capture       format a20
col has_role      format a20
col module        format a30
col name          format a35
col obj_priv      format a20
col object_name   format a30
col object_owner  format a20
col os_user       format a15
col path          format a35
col rolename      format a20
col run_name      format a20
col sys_priv      format a25
col userhost      format a20
col username      format a20
col used_role     format a20

show con_name
show user;

prompt
prompt . Make sure the user has the CAPTURE_ADMIN role
select sys_context('SYS_SESSION_ROLES','CAPTURE_ADMIN') has_role from dual;

prompt
prompt . Generate the PA Capture Results
BEGIN 
 DBMS_PRIVILEGE_CAPTURE.GENERATE_RESULT(
      name => 'All Database Capture');
END; 
/

exit;
EOF

echo
