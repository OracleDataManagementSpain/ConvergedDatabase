#!/bin/bash

# =========================================================================================
# Script Name : pa_generate_workload.sh
#
# Parameter   : None
#
# Notes       : Generate some workload so we have used and unused roles and privileges
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           18/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Generate some workload so we have used and unused roles and privileges..."
echo "=============================================================================="

sqlplus -s / as sysdba <<EOF

connect ${DBUSR_DBA1}/${DBUSR_PWD}@${PDB_NAME}
select sysdate from dual;
select count(*) from v\$session;
select count(*) from gv\$instance;
select count(*) from v\$process;
select sessions_max, sessions_current, sessions_highwater, users_max from v\$license;
select b.paddr , b.name nme, b.description descr, to_char(b.error) cerror from  v\$bgprocess b, v\$process p where  b.paddr = p.addr;
select sequence#, group# first_change# first_time, archived, bytes from v\$log order by sequence#, group#;
select sum(getmisses)/sum(gets)*100 dictcache from v\$rowcache;
select sum(reloads)/sum(pins) *100 libcache from v\$librarycache;
select * from v\$log;
select * from v\$parameter where name like '%optimizer_index%';
select owner, table_name from dba_tables where table_name like 'EMP%';
select * from dba_users where username = upper('${DBUSR_PU}');
select * from dba_role_privs where grantee = '${DBUSR_PU}';
select count(*) from dba_objects;
select count(*) from user_objects;
select count(*) from EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES

connect ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}
select count(*) from EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES;
select count(*) from EMPLOYEESEARCH_PROD.DEMO_HR_ROLES;
SELECT count(*) from EMPLOYEESEARCH_PROD.DEMO_HR_SUPPLEMENTAL_DATA;
SELECT count(*) from EMPLOYEESEARCH_PROD.DEMO_HR_USERS;

connect ${DBUSR_DBA2}/${DBUSR_PWD}@${PDB_NAME}
select * from dba_users;
select * from dba_tab_privs where grantee = 'DBA_HARVEY';
select * from dba_users where username = 'DBA_HARVEY';
select * from dba_role_privs where grantee = 'DBA_HARVEY';
select * from dba_tab_privs where grantee = 'DBA_HARVEY';

connect ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}
select FIRSTNAME, LASTNAME, EMAIL, PHONEMOBILE, STARTDATE from EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES where USERID = 101 order by LASTNAME;
select * from EMPLOYEESEARCH_PROD.DEMO_HR_SUPPLEMENTAL_DATA where USERID = 101;
select LASTNAME, FIRSTNAME, EMAIL from EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES where manager_id = 101 order by 2;
select count(*) From user_tables;
select count(*) from user_objects;
select USERID, MEMBER_ID, BONUS_AMOUNT from EMPLOYEESEARCH_PROD.DEMO_HR_SUPPLEMENTAL_DATA order by 1;
select * from EMPLOYEESEARCH_PROD.DEMO_HR_SUPPLEMENTAL_DATA where rownum < 10 order by 1;

connect ${DBUSR_DBA1}/${DBUSR_PWD}@${PDB_NAME}
select count(*) from unified_audit_trail;
select sysdate from dual;

connect ${DBUSR_PU}/${DBUSR_PWD}@${PDB_NAME}
select USERID, MEMBER_ID, BONUS_AMOUNT from EMPLOYEESEARCH_PROD.DEMO_HR_SUPPLEMENTAL_DATA where rownum < 10 order by 1;
select FIRSTNAME, LASTNAME, EMAIL, PHONEMOBILE, STARTDATE from EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES where USERID = 101 order by LASTNAME;

exit;
EOF

echo
