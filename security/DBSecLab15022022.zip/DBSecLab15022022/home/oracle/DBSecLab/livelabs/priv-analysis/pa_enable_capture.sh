#!/bin/bash

# =========================================================================================
# Script Name : pa_enable_capture.sh
#
# Parameter   : None
#
# Notes       : Start the workload capture
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           18/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Start the workload capture..."
echo "=============================================================================="

sqlplus -s ${DBUSR_PA}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 210
set pages 999
col name     format a35
col has_role format a20
col enabled  format a20

show con_name
show user;

prompt
prompt . Make sure the user has the CAPTURE_ADMIN role
select sys_context('SYS_SESSION_ROLES','CAPTURE_ADMIN') has_role from dual;

prompt
prompt . Current status of our Capture
select NAME, TYPE, ENABLED from DBA_PRIV_CAPTURES where NAME = 'All Database Capture';

prompt
prompt . Enable our Capture to capture everything!
-- ---------------------------------
-- Database-wide privilege capture
-- If you do not specify any type in your privilege analysis policy, then the used privileges in the database
-- will be captured except those for the user SYS (This is also referred to as unconditional analysis, because
-- it is turned on without any conditions)
-- ---------------------------------
BEGIN
  DBMS_PRIVILEGE_CAPTURE.ENABLE_CAPTURE (
   name       => 'All Database Capture');
END;
/

prompt
prompt . New status of our Capture
select NAME, TYPE, ENABLED from DBA_PRIV_CAPTURES where NAME = 'All Database Capture';

exit;
EOF

echo
