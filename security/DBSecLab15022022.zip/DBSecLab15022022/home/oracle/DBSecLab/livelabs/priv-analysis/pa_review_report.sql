set lines 210
set pages 999
col capture       format a20
col has_role      format a20
col module        format a30
col name          format a35
col obj_priv      format a20
col object_name   format a30
col object_owner  format a20
col os_user       format a15
col path          format a35
col rolename      format a20
col run_name      format a20
col sys_priv      format a25
col userhost      format a20
col username      format a20
col used_role     format a20

prompt
prompt . System Privileges used by User and Role
SELECT USERNAME, USED_ROLE, SYS_PRIV, OBJECT_OWNER, OBJECT_NAME, OBJECT_TYPE, PATH
  FROM DBA_USED_PRIVS 
 WHERE CAPTURE = 'ORA$DEPENDENCY'
   AND SYS_PRIV is not null
    order by username, used_role;

prompt
prompt . Object Privileges used by User and Role
SELECT USERNAME, USED_ROLE, OBJ_PRIV, OBJECT_OWNER, OBJECT_NAME, OBJECT_TYPE, PATH
  FROM DBA_USED_PRIVS 
 WHERE CAPTURE = 'ORA$DEPENDENCY'
   AND SYS_PRIV is null
 order by username, used_role;

prompt
prompt . Capture the used privileges by EMPLOYEESEARCH 
SELECT USERNAME, USED_ROLE, SYS_PRIV, OBJECT_OWNER, OBJECT_NAME, OBJECT_TYPE, PATH
  FROM DBA_USED_PRIVS 
 WHERE USERNAME = 'EMPLOYEESEARCH'
 order by username, used_role;

prompt
prompt . Unused Privileges by EMPLOYEESEARCH 
select username, obj_priv, object_owner, object_name, object_type
from DBA_UNUSED_OBJPRIVS 
 where capture = 'All Database Capture'
   and USERNAME = 'EMPLOYEESEARCH'
 order by username, obj_priv;

prompt
prompt . Used Privileges on EMPLOYEESEARCH Objects
select username, used_role, sys_priv, obj_priv, object_owner, object_name, object_type, path
  from DBA_USED_PRIVS
 where capture = 'All Database Capture'
   and object_owner = 'EMPLOYEESEARCH'
 order by username, used_role;
 
prompt
prompt . Unused Privileges on EMPLOYEESEARCH Objects
select username, sys_priv, obj_priv, object_owner, object_name, object_type, path
  from DBA_UNUSED_PRIVS
 where capture = 'All Database Capture'
   and object_owner = 'EMPLOYEESEARCH'
 order by username;

prompt
prompt . Unused System Privileges 
select username, sys_priv, admin_option
  from DBA_UNUSED_SYSPRIVS 
 where capture = 'All Database Capture'
   and username in ('EMPLOYEESEARCH','PU_PETE')
 order by username, sys_priv;
 
prompt
prompt . Unused User Privileges
select username, user_priv, onuser, grant_option
  from DBA_UNUSED_USERPRIVS
 where capture = 'All Database Capture'
   and username in ('EMPLOYEESEARCH','PU_PETE')
 order by username, user_priv;

prompt
prompt . Used Object Privileges  
select username, used_role, os_user, userhost, module, obj_priv, object_owner, object_name, object_type
  from DBA_USED_OBJPRIVS 
  where capture = 'All Database Capture'
    and username in ('EMPLOYEESEARCH','DBA_DEBRA','DBA_HARVEY','PU_PETE')
  order by username, used_role;
     
prompt
prompt . Used Public Privileges  
select username, obj_priv, os_user, userhost, module, object_owner, object_name, object_type
  from DBA_USED_PUBPRIVS
 where capture = 'All Database Capture'
   and username in ('EMPLOYEESEARCH','DBA_DEBRA','DBA_HARVEY','PU_PETE')
 order by username, obj_priv;
 
prompt
prompt . Unused Sys Privileges
select username, used_role, os_user, userhost, module, sys_priv, admin_option
   from DBA_USED_SYSPRIVS
  where capture = 'All Database Capture'
   and username in ('EMPLOYEESEARCH','DBA_DEBRA','DBA_HARVEY','PU_PETE')
 order by username, used_role; 

prompt
prompt . Used User Privileges 
select username, used_role, os_user, userhost, module, user_priv, onuser, grant_option
  from DBA_USED_USERPRIVS
 where capture = 'All Database Capture'
 order by username, used_role; 
