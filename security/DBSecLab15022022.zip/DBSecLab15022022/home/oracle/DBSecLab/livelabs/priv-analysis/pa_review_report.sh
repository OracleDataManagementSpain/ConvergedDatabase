#!/bin/bash

# =========================================================================================
# Script Name : pa_review_report.sh
#
# Parameter   : None
#
# Notes       : Show the report results by querying the views associated with the capture output
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           18/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Review the report from the PA capture run..."
echo "=============================================================================="

sqlplus -s ${DBUSR_PA}/${DBUSR_PWD}@${PDB_NAME} <<EOF

show con_name
show user;

-- -------------------------------------------------------------------------------------------------------------------
-- How Privilege Analysis Works with Pre-Compiled Database Objects
-- Privilege analysis can be used to capture the privileges that have been exercised on pre-compiled database objects.
-- 
-- Examples of these objects are PL/SQL packages, procedures, functions, views, triggers, and Java classes and data.
-- 
-- Because these privileges may not be exercised during run time when a stored procedure is called, 
-- these privileges are collected when you generate the results for any database-wide capture, along with run-time captured privileges. 
-- A privilege is treated as an unused privilege when it is not used in either pre-compiled database objects or run-time capture, 
-- and it is saved under the run-time capture name. If a privilege is used for pre-compiled database objects, 
-- then it is saved under the capture name ORA$DEPENDENCY. 
-- If a privilege is captured during run time, then it is saved under the run-time capture name. 
-- If you want to know what the used privileges are for both pre-compiled database objects and run-time usage, 
-- then you must query both the ORA$DEPENDENCY and run-time captures. 
-- For unused privileges, you only need to query with the run-time capture name.
-- 
-- To find a full list of the pre-compiled objects on which privilege analysis can be used
--  query the TYPE column of the ALL_DEPENDENCIES data dictionary view
--
--
-- Privilege analysis can be used to capture the privileges that have been exercised on pre-compiled database objects.
-- 
-- Examples of these objects are PL/SQL packages, procedures, functions, views, triggers, and Java classes and data.
-- -------------------------------------------------------------------------------------------------------------------
@pa_review_report.sql

exit;
EOF

echo
