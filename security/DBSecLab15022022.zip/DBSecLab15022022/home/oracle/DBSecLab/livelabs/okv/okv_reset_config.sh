#!/bin/bash

# =========================================================================================
# Script Name : okv_reset_config.sh
#
# Parameter   : None
#
# Notes       : Drop Endpoint and Wallet in OKV
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           10/04/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Reset the OKV config..."
echo "=============================================================================="

echo "cd ${OKV_RESTHOME}"
cd $OKV_RESTHOME

echo
echo ". Clean OKV config"
./okv-clean.sh

echo
