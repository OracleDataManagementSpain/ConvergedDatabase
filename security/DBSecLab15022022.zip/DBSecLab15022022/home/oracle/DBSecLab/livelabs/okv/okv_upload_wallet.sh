#!/bin/bash

# =========================================================================================
# Script Name : okv_upload_wallet.sh
#
# Parameter   : None
#
# Notes       : Upload the Wallet to Oracle Key Vault
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Upload the Wallet to Oracle Key Vault..."
echo "=============================================================================="

echo
echo ". Upload the Wallet (as reminder: Wallet and Endpoint password is '${DBUSR_PWD}')"
echo
okvutil upload -t wallet -l ${TDE_HOME} -g ${ORACLE_SID^^} -v4

echo
