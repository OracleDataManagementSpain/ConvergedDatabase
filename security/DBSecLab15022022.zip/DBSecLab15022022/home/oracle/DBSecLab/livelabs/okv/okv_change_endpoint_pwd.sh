#!/bin/bash

# =========================================================================================
# Script Name : okv_change_endpoint_pwd.sh
#
# Parameter   : None
#
# Notes       : Change the Endpoint password
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2 (OKV 18.4)
# HLO           18/03/2021      Updates for Livelabs-v3 (OKV 21.1)
# HLO           10/12/2021      Replace "by" by "to"
# =========================================================================================

echo
echo "=============================================================================="	
echo " Change the Endpoint password..."
echo "=============================================================================="

echo
echo ". Replace the current password 'change-on-install' to '${DBUSR_PWD}'"
okvutil changepwd -t wallet -l $OKV_HOME/ssl/

echo
