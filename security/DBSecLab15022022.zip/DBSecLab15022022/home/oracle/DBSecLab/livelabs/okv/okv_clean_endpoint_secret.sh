#!/bin/bash

# =========================================================================================
# Script Name : okv_clean_endpoint_secret.sh
#
# Parameter   : $1	Display the outfile file (Default "show")
#
# Notes       : Clean a secret as Endpoint
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           11/12/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Clean a Secret as Endpoint..."
echo "=============================================================================="

cd $OKV_RESTHOME

secret_wallet_dir="${WALLET_DIR}/okv/Secrets_EP"

echo
echo ". Delete the secret files and directory"
rm -rf ${secret_wallet_dir}
rm *.json

echo
echo ". Delete the secret EndPoint"
okv admin endpoint delete --profile ADMIN --endpoint SECRETS_MANAGEMENT

echo
echo ". Change the Client Config to point the original Wallet directory"
sudo sed -i -e "s|okv_client_config="${secret_wallet_dir}"/|okv_client_config=./|g" ${OKV_RESTHOME}/conf/okvrestcli.ini

if [ "$1" = "show" ]
 then
   echo
   echo ". Content of the conf file '${OKV_RESTHOME}/conf/okvrestcli.ini'"
   echo
   echo "-------------------"
   more ${OKV_RESTHOME}/conf/okvrestcli.ini
   echo "-------------------"
   echo
fi
    
echo
