#!/bin/bash

# =========================================================================================
# Script Name : tde_view_wallet_in_db.sh
#
# Parameter   : None
#
# Notes       : Displays the Wallet info in the DB
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# HLO           12/04/2021      Updates for Livelabs-v3
# =========================================================================================

echo
echo "==================================================================================="
echo " Display the Wallet info in the DB..."
echo "==================================================================================="

sqlplus -s / as sysdba <<EOF

set lines 120
set pages 9999
col wrl_type        format a12
col wrl_parameter   format a35
col activation_time format a36
col key_use         format a14
col tag             format a44
col name            format a10
col wallet_type     format a12

prompt
prompt . Display the keystore status
select a.con_id, b.name, a.wrl_type, a.wrl_parameter, a.status, a.wallet_type from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.wrl_type, a.con_id;

prompt
prompt . Display the keys in the DB
select con_id, activation_time, key_use, tag from v\$encryption_keys order by con_id;

exit;
EOF

echo
