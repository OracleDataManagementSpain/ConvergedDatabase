#!/bin/bash

# =========================================================================================
# Script Name : okv_add_endpoint.sh
#
# Parameter   : None
#
# Notes       : Add a container database as Endpoint
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2 (OKV 18.4)
# HLO           18/03/2021      Updates for Livelabs-v3 (OKV 21.1)
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add the container database ${ORACLE_SID} as Endpoint..."
echo "=============================================================================="

if [[ -z $OKV_HOME ]]; then
 echo
 echo "-------------------------------------------------------------------"
 echo "!!! ERROR !!!"
 echo "The OKV_HOME variable is empty. Your profile is not setup properly!"
 echo "The easiest fix is to exit and execute 'sudo su - oracle' again"
 echo "to resource the environment variables"
 echo "-------------------------------------------------------------------"
 echo
 exit 1
fi

echo
echo ". Create Endpoint with okvrestservices utility"
cd $OKV_RESTHOME
./okv-ep.sh > deploy.out

# Deployment error management
result=`grep ERROR deploy.out | wc -l`
if [[ $result -gt 0 ]]; then

  echo "********************************************************************************************"
  echo "!!! ERROR: There has been an error during deployment !!!"
  echo "********************************************************************************************"
  echo "1. If you have already deployed the OKV client before you may encounter errors"
  echo
  echo "2. Before proceeding, make sure you have a copy of your TDE ewallet.p12 file"
  echo
  echo "3. If you have successfully deployed the OKV client before you can follow the steps"
  echo "   in Wallet_Download to download the full wallet. Then copy the ewallet and cwallet"
  echo "   files to $WALLET_DIR/tde. Once you have re-built OKV, you can follow the steps in"
  echo "   the Wallet_Upload lab and then redo this lab"
  echo
  echo "4. It appears your error message is:"

  result=`grep "Line 1 ERROR" deploy.out | wc -l`
  if [[ $result -gt 0 ]]; then
    echo
    echo "[Line 1 ERROR] [CREATE WALLET] [CDB1]"
    echo "This means your virtual wallet already exists in OKV."
    echo "You have either executed this script previously or created a wallet with the same name"
    echo "You have two choices: comment out line 1 in /u01/app/okvrest/script.txt OR delete your"
    echop "OKV VM and redeploy it as a fresh image"
  fi 

  result=`grep "Line 2 ERROR" deploy.out | wc -l`
  if [[ $result -gt 0 ]]; then
    echo
    echo "[Line 2 ERROR] [CREATE ENDPOINT] [CDB1_on_dbseclab:ORACLE_DB:LINUX64]"
    echo "This means your OKV endpoint already exists. You have either executed this script"
    echo "previously or created an endpoint with the same name. You can comment out this line"
    echo "OR delete your OKV VM and redeploy it as a fresh image"
  fi 

  result=`grep "Line 4 ERROR" deploy.out | wc -l`
  if [[ $result -gt 0 ]]; then
    echo
    echo "[Line 4 ERROR] [GET ENROLLMENT TOKEN] [CDB1_on_dbseclab]"
    echo "This (probably) means you have deployed your endpoint and changed the provisioning"
    echo "password. You can comment out this line OR delete your OKV VM and redeploy it as a"
    echo "fresh image"
  fi 

  echo
  echo "If you are unsure how to proceed, contact us in #database-security on Slack for assistance!"
  echo "********************************************************************************************"
  exit 1

fi

more deploy.out
echo
echo "============="
echo "Success: Endpoint added into OKV!"
echo "You will see the Endpoint, Wallet, and okvclient utility get provisioned."
echo "============="

echo
echo ". Last step: run the root.sh script"
echo "So the OKV related files can be placed on the Operating System"
cd $OKV_HOME/bin
sudo ./root.sh

echo
echo ". Ensure there is a link in ORACLE_BASE"
namei $ORACLE_BASE/okv/$ORACLE_SID/okvclient.ora | grep ' l '

echo
