#!/bin/bash

# =========================================================================================
# Script Name : okv_migrate_wallet_to_kv.sh
#
# Parameter   : None
#
# Notes       : Add the OKV endpoint password to the Secure External Password Store (SEPS) Wallet
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add the OKV endpoint password to the Secure External Password Store (SEPS) Wallet..."
echo "=============================================================================="

echo 
echo ". Show the current contents of the SEPS directory"
ls -al ${SEPS_WALLET_DIR}

echo 
echo ". Add secret for SEPS autologin file"

sqlplus -s / as sysdba <<EOF
administer key management add secret '${DBUSR_PWD}' for client 'OKV_PASSWORD' to local auto_login keystore '${SEPS_WALLET_DIR}';
exit;
EOF

echo 
echo ". Show the contents of the SEPS directory after creating the Wallet"
ls -al ${SEPS_WALLET_DIR}

echo 
echo ". Show the contents of the SEPS Wallet"
orapki wallet display -wallet ${SEPS_WALLET_DIR}

echo
