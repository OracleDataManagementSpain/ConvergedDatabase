#!/bin/bash

# =========================================================================================
# Script Name : okv_online_cdb_rekey.sh
#
# Parameter   : None
#
# Notes       : Perform an Online Master Key rekey for the container database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# HLO           09/04/2021      Replace "DBUSR_PWD" by "EXTERNAL STORE"
# =========================================================================================

echo
echo "=============================================================================="	
echo " Perform an Online Master Key rekey for the container database..."
echo "=============================================================================="

CURDATE="`date +%Y%m%d_%H%M`"
TAG_DATA="${ORACLE_SID}: OKV Online Master Key rekey on ${CURDATE}"

sqlplus -s / as sysdba <<EOF

set lines 140
set pages 9999
col wrl_type format a12
col wrl_parameter format a40
col activation_time format a36
col pdb_name format a10
col tag format a50
col key_id format a35

show con_name;

prompt
prompt . Display the current keys in the DB
select con_id, activation_time, key_use, tag from v\$encryption_keys order by con_id;

prompt
prompt . Rekey the Online Master Key
prompt SQL> ADMINISTER KEY MANAGEMENT SET KEY USING TAG '${TAG_DATA}' FORCE KEYSTORE IDENTIFIED BY EXTERNAL STORE WITH BACKUP container=current;
ADMINISTER KEY MANAGEMENT SET KEY USING TAG '${TAG_DATA}' FORCE KEYSTORE IDENTIFIED BY EXTERNAL STORE WITH BACKUP container=current;

prompt
prompt . Display the new keys in the DB
select con_id, activation_time, key_use, tag from v\$encryption_keys order by con_id;

exit;
EOF

echo
