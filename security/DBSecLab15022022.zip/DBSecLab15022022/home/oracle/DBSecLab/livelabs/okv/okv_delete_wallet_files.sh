#!/bin/bash

# =========================================================================================
# Script Name : okv_migrate_wallet_to_kv.sh
#
# Parameter   : None
#
# Notes       : Delete the Wallet files from the OS
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Delete the Wallet files from the OS..."
echo "=============================================================================="

echo
echo ". View the current contents of Wallet directory"
ls -al ${TDE_HOME}

echo
echo ". Move the files"
mkdir -vp ${TDE_HOME}/backup
mv ${TDE_HOME}/*wallet* ${TDE_HOME}/backup

echo
echo ". View the new contents of Wallet directory"
ls -al ${TDE_HOME}

echo
