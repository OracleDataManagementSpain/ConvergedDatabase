#!/bin/bash

# =========================================================================================
# Script Name : okv_add_secret_attributes.sh
#
# Parameter   : $1	PWD_ID
#
# Notes       : Add username and connect string as custom attributes to the password
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           11/12/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add username and connect string as custom attributes to the password..."
echo "=============================================================================="

cd $OKV_RESTHOME

PWD_ID=$1

echo
echo ". Add the username"
echo "... Generate the JSON file"
okv managed-object custom-attribute add --generate-json-input | jq '.service.options.customAttribute |= (.name="x-NAME" | .value="REFRESH_DWH" | .type = "TEXT")' > add-cust-attrib.json
echo "... Execute the JSON file"
okv managed-object custom-attribute add --from-json ./add-cust-attrib.json --uuid $PWD_ID

echo
echo ". Add the connect string"
echo "... Generate the JSON file"
okv managed-object custom-attribute add --generate-json-input | jq '.service.options.customAttribute |= (.name="x-CONNECT-STRING" | .value = "dbsec-lab:1521/pdb1" | .type = "TEXT")' > add-cust-attrib.json
echo "... Execute the JSON file"
okv managed-object custom-attribute add --from-json ./add-cust-attrib.json --uuid $PWD_ID

echo
echo ". Confirm that all the custom attribute are correct"
okv managed-object attribute get-all --uuid $PWD_ID

echo
