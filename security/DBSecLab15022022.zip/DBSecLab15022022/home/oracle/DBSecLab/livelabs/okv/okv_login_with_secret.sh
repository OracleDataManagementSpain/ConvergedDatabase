#!/bin/bash
set +x

# =========================================================================================
# Script Name : okv_log_with_secret.sh
#
# Parameter   : $1	DB User
#				$2  Connect String
#
# Notes       : Log to the database with the secret password
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           11/12/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Log to the database with the secret password..."
echo "=============================================================================="

cd $OKV_RESTHOME

# ************************************************
# ** Read user name and connect string from ******
# ** command line into variables *****************
# ************************************************

dbuser="${1}"
export TWO_TASK="${2}"

echo
echo ". Generate the json file that contains the username and password to find the unique ID of the secret"
echo "  Get it from OKV, pass through jq filter, write to file locate-pwd.json"
okv managed-object object locate --generate-json-input | jq --arg NAME $dbuser --arg twotask $TWO_TASK '.service.options |= (del(.max, .objectGroupMember, .attributes) | .customAttributes[0] |= (.name="x-NAME" | .value=$NAME | .type="TEXT") | .customAttributes[1] |= (.name="x-CONNECT-STRING" | .value=$twotask | .type="TEXT"))' > ./locate-pwd.json

echo
echo ". Execute the JSON file to find the unique ID of the secret"
KMIP_ID=$(okv managed-object object locate --from-json ./locate-pwd.json | jq -r '.value.uuids[0]')

echo
echo ". Get the secret password by specifying the unique ID"
pwd=$(okv managed-object secret get --uuid ${KMIP_ID} | jq '.value.object')

echo
echo ". Login to the DB and exit after 3 seconds"
sqlplus /nolog << _EOF

connect ${dbuser}/${pwd}

exec dbms_session.sleep(3);

_EOF

echo
