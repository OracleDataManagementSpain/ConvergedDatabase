#!/bin/bash

# =========================================================================================
# Script Name : okv_add_endpoint_secret.sh
#
# Parameter   : $1	Display the outfile file (Default "show")
#
# Notes       : Add a secret as Endpoint
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           11/12/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add a Secret as Endpoint..."
echo "=============================================================================="

cd $OKV_RESTHOME

secret_wallet_dir="${WALLET_DIR}/okv/Secrets_EP"

echo
echo ". Create a directory for the new EndPoint"
mkdir -pv ${secret_wallet_dir}

echo
echo ". Create Endpoint for DB account"
okv admin endpoint create --endpoint SECRETS_MANAGEMENT --description "DB Account Passwords" --type ORACLE_NON_DB --platform LINUX64 --subgroup "USE CREATOR SUBGROUP" --unique FALSE

echo
echo ". Provision the EndPoint without password"
okv admin endpoint provision --endpoint SECRETS_MANAGEMENT --location ${secret_wallet_dir} --auto-login TRUE

echo
echo ". Change the Client Config in conf/okvrestcli.ini to point to the secret EndPoint wallet directory"
sudo sed -i -e "s|okv_client_config=./|okv_client_config=${secret_wallet_dir}/|g" ${OKV_RESTHOME}/conf/okvrestcli.ini

if [ "$1" = "show" ]
 then
   echo
   echo ". Content of the conf file '${OKV_RESTHOME}/conf/okvrestcli.ini'"
   echo
   echo "-------------------"
   more ${OKV_RESTHOME}/conf/okvrestcli.ini
   echo "-------------------"
   echo
fi
    
echo
