#!/bin/bash

# =========================================================================================
# Script Name : okv_migrate_wallet_to_kv.sh
#
# Parameter   : None
#
# Notes       : Migrate the virtual Wallet to Key Vault
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# HLO           09/12/2021      Updates for Livelabs-v4 (OKV_PASSWORD instead of HSM_PASSWORD)
# =========================================================================================

echo
echo "=============================================================================="	
echo " Migrate the virtual Wallet to Key Vault..."
echo "=============================================================================="

sqlplus -s / as sysdba <<EOF

set echo on;
set lines 120
set pages 9999

prompt
prompt . Add secret for OKV connection
--administer key management add secret '${DBUSR_PWD}' for client 'HSM_PASSWORD' force keystore identified by "${DBUSR_PWD}" with backup;
administer key management add secret '${DBUSR_PWD}' for client 'OKV_PASSWORD' force keystore identified by "${DBUSR_PWD}" with backup;

prompt
prompt . Change the tde_configuration initialization parameters to 'keystore_configuration=OKV|FILE'
show parameter tde_configuration
alter system set tde_configuration = "keystore_configuration=OKV|FILE" scope=BOTH;
show parameter tde_configuration

prompt
prompt . Migrate the Keystore to KV
administer key management set KEYSTORE OPEN force keystore IDENTIFIED BY "${DBUSR_PWD}" container=all;
administer key management set encryption key identified by "${DBUSR_PWD}" force keystore migrate using "${DBUSR_PWD}";

exit;
EOF

echo
