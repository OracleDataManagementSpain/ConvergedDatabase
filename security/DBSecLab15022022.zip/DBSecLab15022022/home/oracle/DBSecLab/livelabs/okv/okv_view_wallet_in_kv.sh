#!/bin/bash

# =========================================================================================
# Script Name : okv_view_wallet_in_kv.sh
#
# Parameter   : None
#
# Notes       : View the virtual Wallet contents in Key Vault
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " View the virtual Wallet contents in Key Vault..."
echo "=============================================================================="

echo
echo ". View the virtual Wallet contents in Key Vault"
echo
echo $DBUSR_PWD | okvutil list

echo
