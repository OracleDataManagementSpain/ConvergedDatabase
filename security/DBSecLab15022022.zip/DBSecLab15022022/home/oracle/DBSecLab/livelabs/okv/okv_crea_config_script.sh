#!/bin/bash

# =========================================================================================
# Script Name : okv_crea_config_script.sh
#
# Parameter   : None
#
# Notes       : Create the script to create the Endpoint, Wallet and deploy the OKV software
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2 (OKV 18.4)
# HLO           18/03/2021      Updates for Livelabs-v3 (OKV 21.1)
# HLO           08/12/2021      Updates for Livelabs-v4 (comment "Add user")
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create the script to create the Endpoint, Wallet and deploy the OKV software..."
echo "=============================================================================="

echo "cd ${OKV_RESTHOME}"
cd $OKV_RESTHOME

echo
echo ". Look at the okvrestcli.ini file that holds OKV server and connection info"
echo
echo "--- okvrestcli.ini ---"
cat conf/okvrestcli.ini
echo "------------------"

echo
echo ". Download okvrestcli.jar and create the okv-ep.sh script"
echo
echo "--- okv-ep.sh ---"
./run-me.sh
echo "------------------"

#echo
#echo ". Add user $OKV_USRADM to the OKV config"
#okv admin client-wallet add --client-wallet $OKV_RESTHOME --wallet-user $OKV_USRADM
#./okv-clean.sh

echo
