#!/bin/bash

# =========================================================================================
# Script Name : okv_unpack_restservice.sh
#
# Parameter   : None
#
# Notes       : Unpack the okvrestclipackage utility
#               All of these steps can be performed manually instead
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2 (OKV 18.4)
# HLO           18/03/2021      Updates for Livelabs-v3 (OKV 21.1)
# =========================================================================================

echo
echo "=============================================================================="	
echo " Unpack the okvrestclipackage utility..."
echo "=============================================================================="

echo "cd ${OKV_RESTHOME}"
cd $OKV_RESTHOME

echo
echo ". View the current okvrest directory contents"
ls -l 

echo
echo ". Unpack OKVdeploy.tgz file"
tar -xzvf OKVdeploy.tgz

echo
echo ". View the new okvrest directory contents"
ls -l 

echo
