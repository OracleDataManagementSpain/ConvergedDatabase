#!/bin/bash

# =========================================================================================
# Script Name : okv_setup_external_store.sh
#
# Parameter   : None
#
# Notes       : Add the OKV password for the auto_login keystore
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# HLO           12/04/2021      Display SQL command
# HLO           09/12/2021      Updates for Livelabs-v4 (replace HSM_PASSWORD to OKV_PASSWORD)
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add the OKV password for the auto_login keystore..."
echo "=============================================================================="

echo 
echo ". Add secret for OKV autologin keystore"

sqlplus -s / as sysdba <<EOF

--prompt SQL> administer key management add secret '${DBUSR_PWD}' for client 'HSM_PASSWORD' to local auto_login keystore '${TDE_HOME}';
--administer key management add secret '${DBUSR_PWD}' for client 'HSM_PASSWORD' to local auto_login keystore '${TDE_HOME}';

prompt SQL> administer key management add secret '${DBUSR_PWD}' for client 'OKV_PASSWORD' to local auto_login keystore '${TDE_HOME}';
administer key management add secret '${DBUSR_PWD}' for client 'OKV_PASSWORD' to local auto_login keystore '${TDE_HOME}';

exit;
EOF

echo
echo ". View the new contents of Wallet directory"
ls -al ${TDE_HOME}

echo
