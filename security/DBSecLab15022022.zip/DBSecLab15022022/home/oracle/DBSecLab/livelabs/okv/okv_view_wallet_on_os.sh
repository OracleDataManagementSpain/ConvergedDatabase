#!/bin/bash

# =========================================================================================
# Script Name : okv_view_wallet_in_kv.sh
#
# Parameter   : None
#
# Notes       : Displays the Wallet info on the Operating System
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           16/09/2020      Creation
# HLO           23/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Display the Wallet info on the OS..."
echo "==================================================================================="

echo
echo ". Wallet location and files"
find $WALLET_DIR

echo
echo ". Display the keystore from the OS"
echo "  -------------------------"
echo "  Note:"
echo "  To view it, run the following OS command:"
echo "  $ orapki wallet display -wallet ${TDE_HOME} -pwd ${DBUSR_PWD}"
echo "  -------------------------"
echo
orapki wallet display -wallet ${TDE_HOME} -pwd ${DBUSR_PWD}

echo
