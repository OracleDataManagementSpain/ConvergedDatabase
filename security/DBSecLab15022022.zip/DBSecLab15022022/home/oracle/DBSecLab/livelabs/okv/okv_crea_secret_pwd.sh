#!/bin/bash

# =========================================================================================
# Script Name : okv_crea_secret_pwd.sh
#
# Parameter   : $1	Display the outfile file (Default "show")
#
# Notes       : Create the secret password
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           11/12/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create the secret password..."
echo "=============================================================================="

cd $OKV_RESTHOME

echo
echo ". Create a temporary file on RAM disk"
secretfile="$(mktemp -p /dev/shm)"

echo
echo ". Create a secret (a random password) into the temporary file"
#openssl rand -base64 18 -out $secretfile; more $secretfile
openssl rand -base64 18 -out $secretfile
secretpwd=`echo $(more $secretfile)`

echo
echo ". Create the DB user 'REFRESH_DWH' with the secret generated"
sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

GRANT CREATE SESSION TO refresh_dwh IDENTIFIED BY "$secretpwd";

exit
EOF

echo
echo ". Generate the JSON file (sec-reg.json) to register the secret into OKV"
okv managed-object secret register --generate-json-input | sed 's|mask" : #|mask" : |' | jq --arg pswd $secretfile '.service.options |= ((del(.wallet, .mask[]) | .attributes |= {activationDate}) | (.object = $pswd | .type = "PASSWORD" | .mask[0] = "DERIVE_KEY" | .attributes.activationDate = (now | strftime ("%F %T"))))' > sec-reg.json

if [ "$1" = "show" ]
 then
   echo
   echo ". Content of the secret registration file (sec-reg.json)"
   echo
   echo "-------------------"
   more sec-reg.json
   echo "-------------------"
   echo
fi

echo
echo ". Upload the secret into OKV"
echo ". IMPORTANT: OKV will respond with the unique ID of the secret, please copy it for later!"
PWD_ID=$(okv managed-object secret register --from-json ./sec-reg.json | jq -r '.value.uuid')
echo
echo "  Secret Unique ID (to copy): "$PWD_ID

echo
echo ". Delete the temporary file which contains the secret to avoid any risk of exposure"
shred -xuz $secretfile

echo
