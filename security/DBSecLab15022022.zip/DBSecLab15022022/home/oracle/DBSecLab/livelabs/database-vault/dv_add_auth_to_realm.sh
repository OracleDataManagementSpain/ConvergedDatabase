#!/bin/bash

# =========================================================================================
# Script Name : dv_add_auth_to_realm.sh
#
# Parameter   : None
#
# Notes       : Add an owner participant to the Database Vault realm
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add EMPLOYEESEARCH_PROD as a real authorized owner..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col realm_name      format a28
col grantee         format a22
col auth_options    format a28

show user;
show con_name;

prompt
prompt . Show the owner of the DV realms
select realm_name, grantee, auth_options
  from dvsys.dba_dv_realm_auth
 where realm_name in (select name from dvsys.dv\$realm where id# >= 5000);

prompt
prompt . Add EMPLOYEESEARCH_PROD as authorized owner of the DV realm "PROTECT_EMPLOYEESEARCH_PROD"
begin
 DVSYS.DBMS_MACADM.ADD_AUTH_TO_REALM(
   realm_name => 'PROTECT_EMPLOYEESEARCH_PROD'
  ,grantee => 'EMPLOYEESEARCH_PROD'
  ,rule_set_name => '' 
  ,auth_options => '1' ); 
end;
/

prompt
prompt . Show the owner of the DV realms
select realm_name, grantee, auth_options
  from dvsys.dba_dv_realm_auth
 where realm_name in (select name from dvsys.dv\$realm where id# >= 5000);

exit;
EOF

echo
