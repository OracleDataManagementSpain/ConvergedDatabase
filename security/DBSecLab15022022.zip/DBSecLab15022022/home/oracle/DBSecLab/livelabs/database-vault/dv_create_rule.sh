#!/bin/bash

# =========================================================================================
# Script Name : dv_create_rule.sh
#
# Parameter   : None
#
# Notes       : Create DV rule
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create a Database Vault Rule..."
echo "=============================================================================="	

FQDN_HOST=`hostname --fqdn`

echo
echo ". We must update the script to have the fully-qualified hostname for your VM"
echo "  Your machine is: ${FQDN_HOST}"
echo
echo ". The default rule looks like this:"
echo "SYS_CONTEXT('USERENV','SESSION_USER') = 'EMPLOYEESEARCH_PROD'
AND SYS_CONTEXT('USERENV','OS_USER') = 'oracle'
AND SYS_CONTEXT('USERENV','MODULE') = 'JDBC Thin Client'
AND SYS_CONTEXT('USERENV','HOST') = 'dbsec-lab.dbsecvcn.oraclevcn.com'"

RULE_EXPR="'SYS_CONTEXT(''USERENV'',''SESSION_USER'') = ''EMPLOYEESEARCH_PROD'' AND SYS_CONTEXT(''USERENV'',''OS_USER'') = ''oracle'' AND SYS_CONTEXT(''USERENV'',''MODULE'') = ''JDBC Thin Client'' AND SYS_CONTEXT(''USERENV'',''HOST'') = ''${FQDN_HOST}'''"

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set serveroutput on;
set echo on;
set lines 140
set pages 9999
col name format a30
col rule_expr format a90

prompt
prompt . Create the rule "Application Connection"
begin
 DVSYS.DBMS_MACADM.CREATE_RULE(
  rule_name => 'Application Connection'
, rule_expr => ${RULE_EXPR});
end;
/

prompt
prompt . Show the DV rule "Application Connection"
SELECT name, rule_expr FROM DBA_DV_RULE where name = 'Application Connection';

exit;
EOF

echo
