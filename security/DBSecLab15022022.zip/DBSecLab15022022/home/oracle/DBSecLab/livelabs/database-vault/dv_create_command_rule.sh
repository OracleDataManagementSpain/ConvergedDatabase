#!/bin/bash

# =========================================================================================
# Script Name : dv_create_command_rule.sh
#
# Parameter   : None
#
# Notes       : Create a Command Rule on Connect to protect the EMPLOYEESEARCH_PROD user
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create a Command Rule on Connect to protect the EMPLOYEESEARCH_PROD user..."
echo "=============================================================================="	
echo

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set serveroutput on;
set echo on;
set lines 140
set pages 9999
col command       format a20
col object_owner  format a24
col object_name   format a24
col rule_set_name format a40

prompt
prompt . Create the Command Rule on Connect for "Application Connection"
begin
 DVSYS.DBMS_MACADM.CREATE_CONNECT_COMMAND_RULE(
   user_name	=> 'EMPLOYEESEARCH_PROD'
  ,rule_set_name => 'Trusted Application Path'
  ,enabled => DBMS_MACUTL.G_YES);
end;
/
 
prompt
prompt . Show the Command Rule on Connect for "Application Connection"
select command, object_owner, object_name, rule_set_name from dba_dv_command_rule where command = 'CONNECT';

exit;
EOF

echo
