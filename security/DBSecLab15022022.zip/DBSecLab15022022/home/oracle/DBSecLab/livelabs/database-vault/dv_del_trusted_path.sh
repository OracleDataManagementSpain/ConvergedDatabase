#!/bin/bash

# =========================================================================================
# Script Name : dv_create_command_rule.sh
#
# Parameter   : None
#
# Notes       : Delete the Command Rule, Rule Set, and Rule from Database Vault
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Remove Command Rule, Rule Set, and Rule..."
echo "=============================================================================="	
echo

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set serveroutput on;
set echo on;

prompt
prompt . Delete the Command Rule
begin
 DVSYS.DBMS_MACADM.DELETE_CONNECT_COMMAND_RULE(
  user_name => 'EMPLOYEESEARCH_PROD');
end;
/

prompt
prompt . Delete the Rule Set
begin
 DVSYS.DBMS_MACADM.DELETE_RULE_SET(
  rule_set_name => 'Trusted Application Path');
end;
/

prompt
prompt . Delete the Rule
begin
 DVSYS.DBMS_MACADM.DELETE_RULE(
  rule_name => 'Application Connection');
end;
/

exit;
EOF

echo
