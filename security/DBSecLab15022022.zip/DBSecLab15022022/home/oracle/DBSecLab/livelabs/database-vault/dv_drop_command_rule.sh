#!/bin/bash

# =========================================================================================
# Script Name : dv_drop_command_rule.sh
#
# Parameter   : None
#
# Notes       : Remove the Command Rule
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Remove the Command Rule..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

prompt
prompt . Delete the Command Rule
BEGIN
 DBMS_MACADM.DELETE_COMMAND_RULE(
  command        => 'CONNECT', 
  object_owner   => '%', 
  object_name    => '%',
  scope          => DBMS_MACUTL.G_SCOPE_LOCAL);
END;
/

exit;
EOF

echo
