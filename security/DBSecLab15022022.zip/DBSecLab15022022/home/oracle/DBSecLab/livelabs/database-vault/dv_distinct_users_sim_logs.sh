#!/bin/bash

# =========================================================================================
# Script Name : dv_distinct_users_sim_logs.sh
#
# Parameter   : None
#
# Notes       : Get a list of distinct usernames present in the simulation logs
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Get a list of distinct usernames present in the DV simulation logs..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col VIOLATION_TYPE  format a24
col username        format a20
col machine         format a49
col command         format a12
col dv\$_module     format a17
col sqltext         format a60

prompt
prompt . Display the current simulation logs
SELECT distinct USERNAME FROM DBA_DV_SIMULATION_LOG order by 1;

exit;
EOF

echo
