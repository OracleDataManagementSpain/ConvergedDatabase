#!/bin/bash

# =========================================================================================
# Script Name : dv_disable_on_cdb.sh
#
# Parameter   : None
#
# Notes       : Disable Database Vault in the container database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Disable Database Vault for the container database CDB..."	
echo "=============================================================================="	

sqlplus -s / as sysdba <<EOF

set echo on

show con_name

prompt
prompt . Show the DB Vault status
@dv_status.sql

prompt
prompt . Disable DB Vault
connect ${DBUSR_DBV_OWNER}/${DBUSR_PWD}
show con_name
show user
exec dvsys.dbms_macadm.disable_dv;

prompt
prompt . Reboot the Database
connect / as sysdba
show con_name
shutdown immediate;
startup;

prompt
prompt . Show the DB Vault status
@dv_status.sql

exit;
EOF

echo
