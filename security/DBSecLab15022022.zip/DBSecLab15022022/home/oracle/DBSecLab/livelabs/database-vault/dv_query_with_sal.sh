#!/bin/bash

# =========================================================================================
# Script Name : dv_query_with_debra.sh
#
# Parameter   : None
#
# Notes       : Run the same queries as both pluggable database as ADMIN SAL
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Run the same queries as both pluggable database as ${DBUSR_DBV_SAL}..."
echo "=============================================================================="

sqlplus -s /nolog <<EOF

set lines 110
set pages 999
col owner           format a24
col table_name      format a24
col tablespace_name format a26

prompt
prompt . Select "EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES" table on PDB1 as ${DBUSR_DBV_SAL}
connect ${DBUSR_DBV_SAL}/${DBUSR_PWD}@pdb1
show con_name
show user
select owner, table_name, tablespace_name from dba_tables where table_name = 'DEMO_HR_EMPLOYEES' and owner = 'EMPLOYEESEARCH_PROD';
select count(*) from employeesearch_prod.demo_hr_employees;

prompt
prompt . Select "EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES" table on PDB2 as ${DBUSR_DBV_SAL}
connect ${DBUSR_DBV_SAL}/${DBUSR_PWD}@pdb2
show con_name
show user
select owner, table_name, tablespace_name from dba_tables where table_name = 'DEMO_HR_EMPLOYEES' and owner = 'EMPLOYEESEARCH_PROD';
select count(*) from employeesearch_prod.demo_hr_employees;

exit;
EOF

echo
