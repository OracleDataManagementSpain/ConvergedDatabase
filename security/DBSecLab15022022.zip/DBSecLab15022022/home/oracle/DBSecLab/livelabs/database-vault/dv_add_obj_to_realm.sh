#!/bin/bash

# =========================================================================================
# Script Name : dv_add_obj_to_realm.sh
#
# Parameter   : None
#
# Notes       : Add an object to protect to the Database Vault realm
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add an object to protect to the realm..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col realm_name     format a28
col grantee        format a22
col auth_options   format a28
col owner          format a28
col object_name    format a18
col object_type    format a18

show user;
show con_name;

prompt
prompt . Show the objects protected by the DV realm
select realm_name, owner, object_name, object_type
  from dvsys.dba_dv_realm_object
 where realm_name in (select name from dvsys.dv\$realm where id# >= 5000);

prompt
prompt . Set all EMPLOYEESEARCH_PROD objects as protected by the DV realm "PROTECT_EMPLOYEESEARCH_PROD"
begin
 DVSYS.DBMS_MACADM.ADD_OBJECT_TO_REALM(
   realm_name => 'PROTECT_EMPLOYEESEARCH_PROD'
  ,object_owner => 'EMPLOYEESEARCH_PROD'
  ,object_name => '%'
  ,object_type => '%'); 
end;
/

prompt
prompt . Show the objects protected by the DV realm
select realm_name, owner, object_name, object_type
  from dvsys.dba_dv_realm_object
 where realm_name in (select name from dvsys.dv\$realm where id# >= 5000);

exit;
EOF

echo
