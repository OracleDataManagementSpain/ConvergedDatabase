#!/bin/bash

# =========================================================================================
# Script Name : dv_purge_sim_logs.sh
#
# Parameter   : None
#
# Notes       : Purge the simulation logs
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Purge the simulation logs..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

prompt
prompt . Current simulation logs before pruging
 select count(*) from dba_dv_simulation_log;

prompt
prompt . Purge simulation logs
DELETE FROM DVSYS.SIMULATION_LOG$;

prompt
prompt . Current simulation logs after pruging
select count(*) from dba_dv_simulation_log;

exit;
EOF

echo
