#!/bin/bash

# =========================================================================================
# Script Name : dv_command_rule_sim_mode.sh
#
# Parameter   : None
#
# Notes       : Create a Command Rule that will simulate blocking all connections to the DB
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create a Command Rule that will simulate blocking all connections to the DB..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

prompt
prompt . Create the Command Rule
BEGIN
DBMS_MACADM.CREATE_COMMAND_RULE(
 command 	 => 'CONNECT',
 rule_set_name   => 'Disabled',
 object_name       => '%',
 object_owner       => '%',
 enabled         => DBMS_MACUTL.G_SIMULATION);
END;
/

exit;
EOF

echo
