#!/bin/bash

# =========================================================================================
# Script Name : dv_run_queries
#
# Parameter   : None
#
# Notes       : Execute some db connections and generate some log entries
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Execute some db connections and generate some log entries..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba <<EOF

set lines 110
set pages 999

col owner           format a24
col table_name      format a24
col tablespace_name format a26

show con_name

prompt
prompt . Count EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES rows as "SYS"
select count(*) from employeesearch_prod.demo_hr_employees;

prompt
prompt . Count EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES rows as "SYSTEM"
connect ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME}
select count(*) from employeesearch_prod.demo_hr_employees;

prompt
prompt . Count EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES rows as "DBA_DEBRA"
connect ${DBUSR_DBA2}/${DBUSR_PWD}@${PDB_NAME}
select count(*) from employeesearch_prod.demo_hr_employees;

exit;
EOF

echo
