#!/bin/bash

# =========================================================================================
# Script Name : dv_enable_on_pdb.sh
#
# Parameter   : $1  PDB_NAME
#
# Notes       : Enable Database Vault in the pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Configure and Enable Database Vault for the pluggable database ${pdbname}..."	
echo "=============================================================================="	

if [ -z "$1" ]; then	
 echo
 echo	"!!! ERROR !!!"
 echo "You did not include a PDB name!"	
 echo	
 exit 1	
else	
 pdbname=$1	
fi	

sqlplus -s / as sysdba <<EOF

set echo on

show con_name

prompt
prompt . Show the DB Vault status
@dv_status.sql

prompt
prompt . Connect to the pluggable database ${pdbname}
alter session set container=${pdbname};
show con_name

prompt
prompt . Configure DB Vault
BEGIN
 DVSYS.CONFIGURE_DV (
   dvowner_uname         => 'C##DVOWNER',
   dvacctmgr_uname       => 'c##DVACCTMGR');
 END;
/

prompt
prompt . Enable DB Vault
connect ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${pdbname}
show user
exec dvsys.dbms_macadm.enable_dv;

prompt
prompt . Reboot the pluggable database
connect / as sysdba
show con_name
alter pluggable database ${pdbname} close immediate;
alter pluggable database ${pdbname} open;

prompt
prompt . Show the DB Vault status
@dv_status.sql

exit;
EOF

echo
