#!/bin/bash

# =========================================================================================
# Script Name : dv_enable_ops_control.sh
#
# Parameter   : None
#
# Notes       : Enable Database Vault 19c Operations Control
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Enable Database Vault 19c Operations Control..."
echo "=============================================================================="

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD} <<EOF

set lines 90

prompt
prompt . Enable DB Vault Ops Control
exec dbms_macadm.enable_app_protection;

exit;
EOF

echo
