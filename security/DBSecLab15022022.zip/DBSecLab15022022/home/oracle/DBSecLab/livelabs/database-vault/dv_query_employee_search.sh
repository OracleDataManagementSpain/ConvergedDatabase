#!/bin/bash

# =========================================================================================
# Script Name : dv_query_employee_search.sh
#
# Parameter   : None
#
# Notes       : View sample data for table EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Query on EMPLOYEESEARCH_PROD data..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}<<EOF

set trimspool on;
set lines 150
set pages 999
set echo on;
col firstname     format a10
col lastname      format a10
col emptype       format a9
col position      format a16
col ssn           format a11
col sin           format a11
col nino          format a13

show user;

prompt
prompt . Describe EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES from SYS user
desc employeesearch_prod.demo_hr_employees;

prompt
prompt . Query EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES from SYS user
select userid, firstname, lastname, emptype, position, ssn, sin, nino
  from employeesearch_prod.demo_hr_employees
 where rownum < 10;

exit;
EOF

echo
