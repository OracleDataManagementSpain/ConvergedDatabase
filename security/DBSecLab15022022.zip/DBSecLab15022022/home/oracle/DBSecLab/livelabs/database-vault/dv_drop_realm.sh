#!/bin/bash

# =========================================================================================
# Script Name : dv_add_auth_to_realm.sh
#
# Parameter   : None
#
# Notes       : Drop the Database Vault realm
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Drop the realm..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col name          format a31
col description   format a65
col enabled       format a8

show user;
show con_name;

prompt
prompt . Show the current DV realm
select name, description, enabled from dba_dv_realm where id# >= 5000 order by 1;

prompt
prompt . Drop the "PROTECT_EMPLOYEESEARCH_PROD" DV realm
begin 
 DVSYS.DBMS_MACADM.DELETE_REALM_CASCADE(
   realm_name => 'PROTECT_EMPLOYEESEARCH_PROD');
END;
/

prompt
prompt . Show the current DV realm
select name, description, enabled from dba_dv_realm where id# >= 5000 order by 1;

exit;
EOF

echo
