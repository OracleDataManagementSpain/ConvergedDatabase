#!/bin/bash

# =========================================================================================
# Script Name : dv_status.sh
#
# Parameter   : None
#
# Notes       : Check the status of Database Vault
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Check the status of Database Vault..."
echo "=============================================================================="	

sqlplus -s / as sysdba <<EOF

set echo on

show con_name

prompt
prompt . Show the DB Vault status
@dv_status.sql

exit;
EOF

echo
