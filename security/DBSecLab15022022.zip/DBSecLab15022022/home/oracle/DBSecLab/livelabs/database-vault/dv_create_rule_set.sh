#!/bin/bash

# =========================================================================================
# Script Name : dv_create_rule_set.sh
#
# Parameter   : None
#
# Notes       : Create DV rule set
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create a Rule Set from the Rule we created..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set serveroutput on;
set echo on;
set lines 140
set pages 9999
col rule_set_name           format a30
col eval_options_meaning    format a20
col fail_message            format a45

prompt
prompt . Create the rule set "Trusted Application Path"
begin
 DVSYS.DBMS_MACADM.CREATE_RULE_SET(
  rule_set_name => 'Trusted Application Path'
 ,description   => 'Protecting the App User'
 ,enabled       => DBMS_MACUTL.G_YES
 ,eval_options  => DBMS_MACUTL.G_RULESET_EVAL_ALL
 ,audit_options => DBMS_MACUTL.G_RULESET_AUDIT_FAIL
 ,fail_options  => DBMS_MACUTL.G_RULESET_FAIL_SHOW
 ,fail_message  => 'You cannot use the app account this way.'
 ,fail_code     => -20000
 ,handler_options => null
 ,handler         => null
 ,is_static     => TRUE);
end;
/

prompt
prompt . Associate the rule set "Trusted Application Path" to the rule "Application Connection"
begin
 DVSYS.DBMS_MACADM.ADD_RULE_TO_RULE_SET(
  rule_set_name  => 'Trusted Application Path'
 ,rule_name      => 'Application Connection'
 ,rule_order     => 1
 ,enabled        => DBMS_MACUTL.G_YES);
end;
/

prompt
prompt . Show the rule set "Trusted Application Path"
SELECT rule_set_name, enabled, eval_options_meaning, audit_options, fail_message, fail_code, is_static
  FROM DBA_DV_RULE_SET
 where rule_set_name = 'Trusted Application Path';

exit;
EOF

echo
