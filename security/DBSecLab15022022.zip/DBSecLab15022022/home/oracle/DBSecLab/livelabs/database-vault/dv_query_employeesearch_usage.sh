#!/bin/bash

# =========================================================================================
# Script Name : dv_query_employeesearh_usage.sh
#
# Parameter   : None
#
# Notes       : View the session information associated with the Glassfish application
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Display the session associated to your Glassfish App"
echo " available here http://${PUBLIC_IP}:8080/hr_prod_${PDB_NAME} ..."
echo "=============================================================================="	

if [ `ps -ef | grep $GLASSFISH_HOME | grep -v grep | wc -l` -eq 0 ]; then

 echo
 echo "!!! WARNING !!!"
 echo "Glassfish is not starting so we will start it for you..."
 echo
 nohup $DBSEC_ADMIN/start_Glassfish.sh &
 sleep 6
 echo " Done!"

fi

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba<<EOF

set trimspool on
set echo on
set termout on
set lines 120
set pages 999
set feedback on
col osuser format a18
col machine format a55
col module format a35

show user;

prompt
prompt . Session information associated with your Glassfish App
SELECT osuser, machine, module FROM v\$session WHERE username = 'EMPLOYEESEARCH_PROD';

exit;
EOF

echo
