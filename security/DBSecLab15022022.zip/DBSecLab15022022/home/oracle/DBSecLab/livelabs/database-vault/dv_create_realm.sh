#!/bin/bash

# =========================================================================================
# Script Name : dv_create_realm.sh
#
# Parameter   : None
#
# Notes       : Create the Database Vault realm
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           12/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create the realm..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_DBV_OWNER}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col name        format a31
col description format a65
col enabled     format a8

show user;
show con_name;

prompt
prompt . Show the current DV realm
select name, description, enabled from dba_dv_realm where id# >= 5000 order by 1;

prompt
prompt . Create the "PROTECT_EMPLOYEESEARCH_PROD" DV realm
begin 
 DVSYS.DBMS_MACADM.CREATE_REALM(
   realm_name => 'PROTECT_EMPLOYEESEARCH_PROD'
  ,description => 'A mandatory realm to protect the EMPLOYEESEARCH_PROD schema.'
  ,enabled => DBMS_MACUTL.G_YES
  ,audit_options => DBMS_MACUTL.G_REALM_AUDIT_FAIL
  ,realm_type => 1); 
END;
/

prompt
prompt . Show the current DV realm
select name, description, enabled from dba_dv_realm where id# >= 5000 order by 1;

exit;
EOF

echo
