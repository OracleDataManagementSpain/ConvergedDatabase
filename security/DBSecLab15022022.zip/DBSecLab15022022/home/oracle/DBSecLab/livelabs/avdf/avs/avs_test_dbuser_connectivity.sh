#!/bin/bash

# =========================================================================================
# Script Name : avs_test_dbuser_connectivity.sh
#
# Parameter   : None
#
# Notes       : Test the connectivity as Golden Gate Admin user to the database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Test the connectivity as Golden Gate Admin user '${DBUSR_OGGADMIN}' to ${ORACLE_SID}..."
echo "=============================================================================="

echo
echo ". The connection string looks like this: "
echo "sqlplus ${DBUSR_OGGADMIN}/${DBUSR_PWD}@\"(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=10.0.0.150)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=${ORACLE_SID})))\""

sqlplus -s ${DBUSR_OGGADMIN}/${DBUSR_PWD}@"(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=10.0.0.150)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=${ORACLE_SID})))" <<EOF

prompt
prompt Connection is established successfully!

show con_name;
show user;

exit;
EOF

echo
