# =========================================================================================
# Script Name : avs_register_audit_trail.sh
#
# Parameter   : None
#
# Notes       : Register the Unified Audit Trail for a pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Register the Unified Audit Trail for the pluggable database ${PDB_NAME}..."
echo "=============================================================================="	

echo 
echo "------ View the registration script ------"
cat avs_register_audit_trail.av
echo "------------------------------------------"

echo
echo ". Run the avcli utility to register the UNIFIED_AUDIT_TRAIL to collect audit data"
${AVCLI_HOME}/bin/avcli -f avs_register_audit_trail.av

echo
