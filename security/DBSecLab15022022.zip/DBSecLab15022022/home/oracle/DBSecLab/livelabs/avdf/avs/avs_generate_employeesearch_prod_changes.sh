#!/bin/bash

# =========================================================================================
# Script Name : avs_generate_employeesearch_prod_changes.sh
#
# Parameter   : None
#
# Notes       : Generate some workload on EMPLOYEESEARCH_PROD for GoldenGate to extract
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Generate some workload on EMPLOYEESEARCH_PROD for GoldenGate to extract..."
echo "=============================================================================="

sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME} <<EOF

prompt
prompt . Run some queries as ${DBUSR_EMPPROD}
show user;
select count(*) from demo_hr_employees;
select firstname, lastname, salary from demo_hr_employees where userid = 195;
update demo_hr_employees set salary = salary * 1.19 where userid = 195;
select firstname, lastname, salary from demo_hr_employees where userid = 195;
create table demo_hr_employees_bkup as select * from demo_hr_employees;
select count(*) from demo_hr_employees_bkup;
drop table demo_hr_employees_bkup;

prompt
prompt . Run some queries as ${DBUSR_DBA2}
connect ${DBUSR_DBA2}/${DBUSR_PWD}@${PDB_NAME}
show user;
select firstname, lastname, salary from employeesearch_prod.demo_hr_employees where userid = 203;
update employeesearch_prod.demo_hr_employees set lastname = 'Rich' , firstname='Evil' where userid =203;
select firstname, lastname, salary from employeesearch_prod.demo_hr_employees where userid = 203;

exit;
EOF

echo
