#!/bin/bash

# =========================================================================================
# Script Name : adv_linux_setup_auditing.sh
#
# Parameter   : None
#
# Notes       : Setup the audit collection to R/W data with the 'oinstall' Linux OS group
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Setup the audit collection to R/W data with the 'oinstall' Linux OS group..."
echo "=============================================================================="

# We need to make sure the 'oinstall' OS group can read the Linux audit data
if [ `sudo grep log_group /etc/audit/auditd.conf  | grep root | wc -l` -eq 1 ]; then

  echo 
  echo ". Update the log group from 'root' to 'oinstall'"
  sudo sed -i.orig 's/log_group = root/log_group = oinstall/g' /etc/audit/auditd.conf
  sudo grep log_group /etc/audit/auditd.conf

  echo
  echo ". Restart the audit daemon"
  sudo service auditd restart

  echo
  echo ". Update old log files to the 'oinstall' group"
  sudo chgrp oinstall /var/log/audit/audit.log.*

else

  echo 
  echo ". Log group already set to 'oinstall'"
  sudo grep log_group /etc/audit/auditd.conf

fi

echo
echo ". Verify 'oinstall' can access the log files"
sudo ls -al /var/log/audit

echo
