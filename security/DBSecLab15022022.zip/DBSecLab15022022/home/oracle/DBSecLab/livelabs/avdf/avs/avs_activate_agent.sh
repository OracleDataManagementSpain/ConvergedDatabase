#!/bin/bash

# =========================================================================================
# Script Name : avs_activate_agent.sh
#
# Parameter   : None
#
# Notes       : Activate the Audit Vault agent
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Activate the Audit Vault agent..."
echo "=============================================================================="

echo
echo ". Activate the AV agent"
echo "... when prompted, paste the Activation Key displayed when you registered the host"
echo "... and press return"
${AV_HOME}/bin/agentctl start -k

echo
