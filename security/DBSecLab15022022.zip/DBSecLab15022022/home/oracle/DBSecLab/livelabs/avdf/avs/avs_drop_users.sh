#!/bin/bash

# =========================================================================================
# Script Name : avs_drop_users.sh
#
# Parameter   : None
#
# Notes       : Drop users created on pluggable database for testing the Audit Vault alert policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Drop users created on ${PDB_NAME} for testing the Audit Vault alert policy..."
echo "=============================================================================="

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

prompt
prompt . Drop users
drop user new_user_ted;
drop user new_user_fred;
drop user new_user_ned;

exit;
EOF

echo
