#!/bin/bash

# =========================================================================================
# Script Name : avs_show_host.sh
#
# Parameter   : None
#
# Notes       : Verify that the host has been properly registered and activated with Audit Vault
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Verify that the host has been properly registered and activated with Audit Vault..."
echo "=============================================================================="

export avcli_home=/u01/app/avcli

echo 
echo " ------- View the info script -------"
cat avs_show_host.av
echo " ------------------------------------"

echo
echo ". Run the avcli utility to show the host registered"
${AVCLI_HOME}/bin/avcli -f avs_show_host.av

echo
