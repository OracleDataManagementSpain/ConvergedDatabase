#!/bin/bash

# =========================================================================================
# Script Name : dbf_sqlplus_without_dbfw.sh
#
# Parameter   : None
#
# Notes       : Verify connectivity to the pluggable database without the Database Firewall
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Verify connectivity to ${PDB_NAME} without the Database Firewall..."
echo "=============================================================================="

echo
echo ". Connect directly to the pluggable database without the DB Firewall"
echo
echo "$ sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME}"
sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

col ip_address format a30

show con_name;
show user;

prompt
prompt . Which IP address we are connecting from 
select SYS_CONTEXT('USERENV', 'IP_ADDRESS') IP_ADDRESS from dual;

exit;
EOF

echo
