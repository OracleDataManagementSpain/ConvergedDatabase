#!/bin/bash

# =========================================================================================
# Script Name : adv_pgsql_cleanup.sh
#
# Parameter   : None
#
# Notes       : Cleanup the PostgreSQL database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Cleanup the PostgreSQL database..."
echo "=============================================================================="

if [ "$USER" != "postgres" ]; then
        echo
        echo "You forgot to run it as: sudo -u postgres $0"
        exit
fi

echo
echo ". Source PostgreSQL user"
cd /tmp
source /var/lib/pgsql/.bash_profile

echo
echo ". Drop table DEMO_HR_EMPLOYEES"
psql -d employeesearch_prod -c "DROP TABLE demo_hr_employees;"

echo
echo ". Drop Users"
psql -d employeesearch_prod -c "DROP USER evil_rich;"
psql -c "ALTER USER oracle WITH NOSUPERUSER;"
psql -c "DROP USER oracle"

echo
echo ". Stop PostgreSQL database"
/usr/pgsql-11/bin/pg_ctl stop

echo
