#!/bin/bash

# =========================================================================================
# Script Name : dbf_query_fw_policy.sh
#
# Parameter   : None
#
# Notes       : Demonstrate connectivity through the DB Firewall and the ability to query
#               the EMPLOYEESEARCH_PROD tables
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Demonstrate connectivity through the DB Firewall and the ability to query"
echo " the EMPLOYEESEARCH_PROD tables..."
echo "=============================================================================="

echo
echo ". Connect to the pluggable database through the DB Firewall (proxy)"
echo
echo "$ sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME}.proxy"
sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}.proxy <<EOF

set lines 180
set pages 999
set trimspool on
set echo on
set serveroutput on
set termout on
col firstname format a10
col lastname format a10
col emptype format a9
col position format a16
col city format a11
col ssn format a11
col sin format a11
col nino format a13

show user;

prompt
prompt . Query EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES
select userid, firstname, lastname, emptype, position, city, ssn, sin, nino
  from employeesearch_prod.demo_hr_employees
 where rownum < 10;

exit;
EOF

echo
