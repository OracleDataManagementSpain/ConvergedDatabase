#!/bin/bash

# =========================================================================================
# Script Name : dbf_exfiltrate_with_dbfw.sh
#
# Parameter   : None
#
# Notes       : Generate activity on data to capture row count number with the DBF policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           08/04/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Verify connectivity to ${PDB_NAME} with the Database Firewall..."
echo "=============================================================================="

echo
echo ". Generate activity through the DB Firewall (proxy)"
echo
echo "$ sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}.proxy"
sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}.proxy <<EOF

col ip_address format a30

show con_name;
show user;

prompt
prompt . select count(*) from DEMO_HR_EMPLOYEES;
select count(*) from DEMO_HR_EMPLOYEES;

prompt
prompt . select * from DEMO_HR_EMPLOYEES where rownum < 100;
select * from DEMO_HR_EMPLOYEES where rownum < 100;

prompt
prompt . select member_id, bonus_amount from DEMO_HR_SUPPLEMENTAL_DATA;
select member_id, bonus_amount from DEMO_HR_SUPPLEMENTAL_DATA;

prompt
prompt . Employee sensitive data
select a.USERID, a.FIRSTNAME, a.LASTNAME, a.EMAIL, a.PHONEMOBILE
  from DEMO_HR_EMPLOYEES a left outer join DEMO_HR_EMPLOYEES b on a.MANAGERID = b.USERID
 where 1=1 and upper(a.CITY) like 'LONDON%'
 order by a.LASTNAME, a.FIRSTNAME;

exit;
EOF

echo
