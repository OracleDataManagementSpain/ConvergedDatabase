#!/bin/bash

# =========================================================================================
# Script Name : adv_pgsql_generate_traffic.sh
#
# Parameter   : None
#
# Notes       : Generate traffic into PostgreSQL database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Generate traffic into PostgreSQL database..."
echo "=============================================================================="

echo
echo ". Load EMPLOYEESEARCH_PROD Data"
psql -d employeesearch_prod -f adv_pgsql_load_data.sql
psql -d employeesearch_prod -c "select * from demo_hr_employees;"
psql -d employeesearch_prod -c "Insert into DEMO_HR_EMPLOYEES (USERID,FIRSTNAME,LASTNAME,EMAIL,PHONEMOBILE,PHONEFIX,PHONEFAX,EMPTYPE,POSITION,ISMANAGER,MANAGERID,DEPARTMENT,LOCATION,STARTDATE,ENDDATE,ACTIVE,ORGANIZATION,CREATIONDATE,MODIFICATIONDATE,COSTCENTER,ISHEADOFDEPARTMENT,DOB,SSN,SIN,NINO,ADDRESS_1,ADDRESS_2,STATE,COUNTRY,POSTAL_CODE,CORPORATE_CARD,CC_PIN,CC_EXPIRE) values (146,'Diana','Morales','Diana.Morales@oracledemo.com','1-(901)379-3156',null,null,'Full-time','Clerk',0,null,'Marketing','Costa Mesa',to_date('05-MAY-12','DD-MON-RR'),null,'1','Xellerate Users',to_date('27-DEC-14','DD-MON-RR'),null,102,null,to_date('07-SEP-88','DD-MON-RR'),'890-81-3057',null,null,'33 Mandrake Parkway',null,'TN','US','38136','3434 150969 14912',1954,to_date('01-JUL-16','DD-MON-RR'));"
psql -d employeesearch_prod -c "Insert into DEMO_HR_EMPLOYEES (USERID,FIRSTNAME,LASTNAME,EMAIL,PHONEMOBILE,PHONEFIX,PHONEFAX,EMPTYPE,POSITION,ISMANAGER,MANAGERID,DEPARTMENT,LOCATION,STARTDATE,ENDDATE,ACTIVE,ORGANIZATION,CREATIONDATE,MODIFICATIONDATE,COSTCENTER,ISHEADOFDEPARTMENT,DOB,SSN,SIN,NINO,ADDRESS_1,ADDRESS_2,STATE,COUNTRY,POSTAL_CODE,CORPORATE_CARD,CC_PIN,CC_EXPIRE) values (146,'Diana','Morales','Diana.Morales@oracledemo.com','1-(901)379-3156',null,null,'Full-time','Clerk',0,null,'Marketing','Costa Mesa',to_date('05-MAY-12','DD-MON-RR'),null,'1','Xellerate Users',to_date('27-DEC-14','DD-MON-RR'),null,102,null,to_date('07-SEP-88','DD-MON-RR'),'890-81-3057',null,null,'33 Mandrake Parkway',null,'TN','US','38136','3434 150969 14912',1954,to_date('01-JUL-16','DD-MON-RR'));"
psql -d employeesearch_prod -c "Insert into DEMO_HR_EMPLOYEES (USERID,FIRSTNAME,LASTNAME,EMAIL,PHONEMOBILE,PHONEFIX,PHONEFAX,EMPTYPE,POSITION,ISMANAGER,MANAGERID,DEPARTMENT,LOCATION,STARTDATE,ENDDATE,ACTIVE,ORGANIZATION,CREATIONDATE,MODIFICATIONDATE,COSTCENTER,ISHEADOFDEPARTMENT,DOB,SSN,SIN,NINO,ADDRESS_1,ADDRESS_2,STATE,COUNTRY,POSTAL_CODE,CORPORATE_CARD,CC_PIN,CC_EXPIRE) values (786,'Bruce','Lane','Bruce.Lane@oracledemo.com','1-(334)396-6507',null,null,'Full-time','End-User',1,null,'Finance','New York',to_date('26-JAN-14','DD-MON-RR'),null,'1','Xellerate Users',to_date('10-MAR-13','DD-MON-RR'),null,102,null,to_date('09-JUN-85','DD-MON-RR'),'287-25-2298',null,null,'45 Del Sol Avenue',null,'AL','US','36119','6391972374646600',2005,to_date('01-MAR-23','DD-MON-RR'));"
psql -d employeesearch_prod -c "UPDATE DEMO_HR_EMPLOYEES SET salary = floor(random() * 100141 + 4132)::int WHERE salary IS NULL;"

echo
echo ". Create user EVIL_RICH"
psql -d employeesearch_prod -c "drop user evil_rich;"
psql -d employeesearch_prod -c "create user evil_rich;"
psql -d employeesearch_prod -c "grant postgres to evil_rich;"

echo
