#!/bin/bash

# =========================================================================================
# Script Name : adv_linux_reset_auditing.sh
#
# Parameter   : None
#
# Notes       : Reset the audit collection to the 'root' Linux OS group only
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Reset the audit collection to the 'root' Linux OS group only..."
echo "=============================================================================="

# We need to make sure the 'root' OS group is the only auditing group
if [ `sudo grep log_group /etc/audit/auditd.conf  | grep oinstall | wc -l` -eq 1 ]; then

  echo 
  echo ". Update the log group from 'oinstall' to 'root'"
  sudo sed -i.orig 's/log_group = oinstall/log_group = root/g' /etc/audit/auditd.conf
  sudo grep log_group /etc/audit/auditd.conf

  echo
  echo ". Restart the audit daemon"
  sudo service auditd restart

else

  echo 
  echo ". Log group already set to 'root'"
  sudo grep log_group /etc/audit/auditd.conf

fi

echo
