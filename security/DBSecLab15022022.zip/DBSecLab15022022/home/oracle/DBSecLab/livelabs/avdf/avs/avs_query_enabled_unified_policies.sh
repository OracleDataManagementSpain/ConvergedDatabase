# =========================================================================================
# Script Name : avs_query_all_unified_policies.sh
#
# Parameter   : None
#
# Notes       : List the ENABLED Unified Audit Policies in the pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " List the ENABLED Unified Audit Policies in the pluggable database ${PDB_NAME}..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_AVAUDIT}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 140
set pages 9999
col policy_name format a45
col ENABLED_OPTION format a15
col ENTITY_NAME format a35
col ENTITY_TYPE format a12
col SUCCESS format a8
col FAILURE format a8

prompt
prompt . List the enabled Unified Audit policies
SELECT POLICY_NAME,ENABLED_OPTION,ENTITY_NAME,ENTITY_TYPE,SUCCESS,FAILURE
  FROM AUDIT_UNIFIED_ENABLED_POLICIES
 ORDER BY policy_name desc;

exit;
EOF

echo
