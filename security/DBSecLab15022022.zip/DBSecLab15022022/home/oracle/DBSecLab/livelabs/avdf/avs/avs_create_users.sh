#!/bin/bash

# =========================================================================================
# Script Name : avs_create_users.sh
#
# Parameter   : None
#
# Notes       : Created users on pluggable database for testing the Audit Vault alert policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Created users on ${PDB_NAME} for testing the Audit Vault alert policy..."
echo "=============================================================================="

sqlplus -s /nolog <<EOF

prompt
prompt . Create user "new_user_fred" as ${DBUSR_SYS}
connect ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba
show user;
create user new_user_fred identified by ${DBUSR_PWD};

prompt
prompt . Create user "new_user_ted" as ${DBUSR_SYSTEM}
connect ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME}
show user;
create user new_user_ted identified by ${DBUSR_PWD};

prompt
prompt . Create user "new_user_ned" as ${DBUSR_DBA2}
connect ${DBUSR_DBA2}/${DBUSR_PWD}@${PDB_NAME}
show user;
create user new_user_ned identified by ${DBUSR_PWD};

exit;
EOF

echo
