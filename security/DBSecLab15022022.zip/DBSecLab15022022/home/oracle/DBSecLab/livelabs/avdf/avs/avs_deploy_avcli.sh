#!/bin/bash

# =========================================================================================
# Script Name : avs_deploy_avcli.sh
#
# Parameter   : None
#
# Notes       : Deploy the Audit Vault Command Line Interface (AVCLI)
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# HLO           11/12/2021      Updates for Livelabs-v4 (Add -d AVCLI_HOME path)
# =========================================================================================

echo
echo "=============================================================================="	
echo " Deploy the Audit Vault Command Line Interface (avcli)..."
echo "=============================================================================="	

echo
echo ". View the AVCLI directory contents"
cd ${AVCLI_HOME}
ls -l 

echo
echo ". Unpack the avcli.jar utility"
java -jar avcli.jar -d ${AVCLI_HOME}

echo
echo ". View the new directory contents"
ls -l

echo
