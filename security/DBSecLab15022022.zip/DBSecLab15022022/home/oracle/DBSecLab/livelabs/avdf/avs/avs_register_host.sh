#!/bin/bash

# =========================================================================================
# Script Name : avs_register_host.sh
#
# Parameter   : None
#
# Notes       : Register the host (dbsec-lab) with Audit Vault Command Line Interface (AVCLI)
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Register the host (dbsec-lab) with avcli..."
echo "=============================================================================="	

echo 
echo " --- View the registration script ---"
cat avs_register_host.av
echo " ------------------------------------"

echo
echo ". Run the avcli utility to register the host..."
${AVCLI_HOME}/bin/avcli -f avs_register_host.av

echo
