# =========================================================================================
# Script Name : avs_query_all_unified_policies.sh
#
# Parameter   : None
#
# Notes       : List all of the Unified Audit Policies in the pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " List all of the Unified Audit Policies in the pluggable database ${PDB_NAME}..."
echo " This includes enabled and disabled policies!"
echo "=============================================================================="	

sqlplus -s ${DBUSR_AVAUDIT}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 140
set pages 9999
col policy_name format a45

prompt
prompt . List all the Unified Audit policies
select distinct policy_name from audit_unified_policies order by 1;

exit;
EOF

echo
