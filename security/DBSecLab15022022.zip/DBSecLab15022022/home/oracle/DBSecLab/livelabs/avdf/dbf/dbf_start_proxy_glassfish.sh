#!/bin/bash

# =========================================================================================
# Script Name : dbf_start_proxy_glassfish.sh
#
# Parameter   : None
#
# Notes       : Migrate the Glassfish App connection string to proxy through the DB Firewall
#               The connection string will be changed to 'jdbc:oracle:thin:@//dbf:15223/pdb1'
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Migrate the Glassfish App connection string to proxy through the DB Firewall..."
echo "=============================================================================="

# Stop Glassfish Application
${DBSEC_ADMIN}/stop_Glassfish.sh

echo 
echo ". Copy the config file to change the connection string to proxy through the DB Firewall"
cp hr_prod_pdb1_dbfw.properties ${GLASSFISH_HOME}/hr_prod_pdb1/WEB-INF/classes/hr.properties

# Restart Glassfish App
${DBSEC_ADMIN}/start_Glassfish.sh

echo
echo ". The Glassfish App is now running with the following configuration"
echo "---------------------------------------------"
cat ${GLASSFISH_HOME}/hr_prod_pdb1/WEB-INF/classes/hr.properties
echo "---------------------------------------------"

echo
