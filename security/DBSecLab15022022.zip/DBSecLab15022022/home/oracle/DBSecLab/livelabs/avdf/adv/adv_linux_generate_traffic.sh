#!/bin/bash

# =========================================================================================
# Script Name : adv_linux_generate_traffic.sh
#
# Parameter   : None
#
# Notes       : Generate traffic into Linux OS
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Generate traffic into Linux OS..."
echo "=============================================================================="

echo
echo ". Add OS user"
sudo useradd evilrich
sudo cat /etc/passwd | grep evilrich

echo
echo ". Drop OS user"
sudo userdel evilrich

echo
