#!/bin/bash

# =========================================================================================
# Script Name : adv_pgsql_init.sh
#
# Parameter   : None
#
# Notes       : Setup PostgreSQL database for auditing
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           19/11/2020      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Setup PostgreSQL database for auditing..."
echo "=============================================================================="

if [ "$USER" != "postgres" ]; then
        echo
        echo "!!! ERROR !!!"
        echo "You forgot to run it as: sudo -u postgres $0"
        exit
fi

echo
echo ". Source PostgreSQL user"
cd /tmp
source /var/lib/pgsql/.bash_profile

echo
echo ". Start PostgreSQL database"
/usr/pgsql-11/bin/pg_ctl start

echo
echo ". Create oracle user on PostgreSQL database"
psql -c "CREATE USER oracle"
psql -c "ALTER USER oracle WITH SUPERUSER;"

echo
echo ". Set log_destination = 'csvlog'"
sed -i -e "s|log_destination = 'stderr'|log_destination = 'csvlog'|g" /var/lib/pgsql/11/data/postgresql.conf
cd /tmp

echo
echo ". Reboot PostgreSQL database..."
/usr/pgsql-11/bin/pg_ctl stop
/usr/pgsql-11/bin/pg_ctl start

echo
