#!/bin/bash

# =========================================================================================
# Script Name : avs_deploy_agent.sh
#
# Parameter   : None
#
# Notes       : Deploy the Audit Vault agent
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Deploy the Audit Vault agent..."
echo "=============================================================================="

echo
echo ". View the AV agent directory contents"
cd ${AV_HOME}
ls -l 

echo
echo ". Unpack the avagent utility"
java -jar agent.jar

echo
echo ". View the new directory contents"
ls -l

echo
