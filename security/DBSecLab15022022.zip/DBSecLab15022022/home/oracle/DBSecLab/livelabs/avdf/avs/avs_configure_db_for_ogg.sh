#!/bin/bash

# =========================================================================================
# Script Name : avs_configure_db_for_ogg.sh
#
# Parameter   : None
#
# Notes       : Configure the database to be ready for Golden Gate
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Configure the database to be ready for Golden Gate..."
echo "=============================================================================="

sqlplus -s / as sysdba <<EOF

prompt
prompt . Alter SYSTEM parameters
alter system set sga_target=3500M scope=spfile;
alter system set streams_pool_size=1250M scope=spfile;
alter system set enable_goldengate_replication=true scope=spfile;

prompt
prompt . Enable ARCHIVELOG mode
shutdown immediate
startup mount
alter database archivelog;
alter database open;
alter pluggable database all open;
select name,log_mode from v\$database;

prompt
prompt . Enable Force Logging mode
alter database force logging;
alter database add supplemental log data;
select force_logging, supplemental_log_data_min from v\$database;

prompt
prompt . Show parameter Compatible
show parameter compatible;

exit;
EOF

echo
