# =========================================================================================
# Script Name : avs_list_audit_trails.sh
#
# Parameter   : None
#
# Notes       : List the Audit Trails for the pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " List the Audit Trails for the pluggable database ${PDB_NAME}..."
echo "=============================================================================="	

echo 
echo "---------- View the list script ----------"
cat avs_list_audit_trails.av
echo "------------------------------------------"

sleep 5

echo
echo ". Run the avcli utility to verify the UNIFIED_AUDIT_TRAIL is running (or idle)"
${AVCLI_HOME}/bin/avcli -f avs_list_audit_trails.av

echo
