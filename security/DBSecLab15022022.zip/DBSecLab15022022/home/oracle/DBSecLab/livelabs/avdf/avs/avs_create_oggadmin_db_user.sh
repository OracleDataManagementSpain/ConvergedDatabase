#!/bin/bash

# =========================================================================================
# Script Name : avs_create_oggadmin_db_user.sh
#
# Parameter   : None
#
# Notes       : Create the Golden Gate Database Administration user in the container database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create the Golden Gate DB Admin user '${DBUSR_OGGADMIN}' in ${ORACLE_SID}..."
echo "=============================================================================="	

sqlplus -s / as sysdba <<EOF

prompt
prompt . Create the user
create user ${DBUSR_OGGADMIN} identified by ${DBUSR_PWD} container=all;

prompt
prompt . Grant the appropriate privileges
-- ----------------------------------------------
grant connect to ${DBUSR_OGGADMIN} container=all;
grant create session, resource, create view, create table to ${DBUSR_OGGADMIN} container=all;
grant alter any table to ${DBUSR_OGGADMIN} container=all;
grant alter system to ${DBUSR_OGGADMIN} container=all;
grant dba to ${DBUSR_OGGADMIN} container=all;
grant unlimited tablespace to  ${DBUSR_OGGADMIN} container=all;
grant create any materialized view to ${DBUSR_OGGADMIN}  container=all;

BEGIN
  dbms_goldengate_auth.grant_admin_privilege('${DBUSR_OGGADMIN}','*',TRUE,TRUE,NULL,NULL,NULL,'ALL');
END;
/

exit;
EOF

echo
