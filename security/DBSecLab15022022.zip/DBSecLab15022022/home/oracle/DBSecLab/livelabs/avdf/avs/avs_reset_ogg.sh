#!/bin/bash

# =========================================================================================
# Script Name : avs_reset_ogg.sh
#
# Parameter   : None
#
# Notes       : Reset Oracle Golden Gate configuration
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           22/11/2021      Creation
# =========================================================================================


#echo
#echo " Stop Oracle Golden Gate Services..."
${DBSEC_ADMIN}/stop_ogg.sh

echo
echo "=============================================================================="	
echo " Reset Golden Gate configuration in Database..."
echo "=============================================================================="

sqlplus -s / as sysdba <<EOF

prompt
prompt . Alter SYSTEM parameters
alter system set sga_target=3500M scope=spfile;
alter system set streams_pool_size=1250M scope=spfile;
alter system set enable_goldengate_replication=false scope=spfile;

prompt
prompt . Disable ARCHIVELOG mode
shutdown immediate
startup mount
alter database noarchivelog;
alter database open;
alter pluggable database all open;
select name,log_mode from v\$database;

prompt
prompt . Disable Force Logging mode
alter database no force logging;
alter database add supplemental log data;
select force_logging, supplemental_log_data_min from v\$database;

prompt
prompt . Show parameter Compatible
show parameter compatible;

prompt
prompt . Drop the OGG user
drop user ${DBUSR_OGGADMIN} cascade;

exit;
EOF

echo

