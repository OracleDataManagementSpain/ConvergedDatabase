# =========================================================================================
# Script Name : avs_register_pdb.sh
#
# Parameter   : None
#
# Notes       : Register the pluggable database as an AV Target
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Register the pluggable database ${PDB_NAME} as an AV Target..."
echo "=============================================================================="	

echo 
echo "------ View the registration script ------"
cat avs_register_pdb.av
echo "------------------------------------------"

echo
echo ". Run the avcli utility to register the pluggable database"
${AVCLI_HOME}/bin/avcli -f avs_register_pdb.av

echo
