#!/bin/bash

# =========================================================================================
# Script Name : dbf_sqlplus_with_dbfw.sh
#
# Parameter   : None
#
# Notes       : Verify connectivity to the pluggable database with the Database Firewall
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           02/08/2020      Creation
# HLO           19/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Verify connectivity to ${PDB_NAME} with the Database Firewall..."
echo "=============================================================================="

echo
echo ". Connect to the pluggable database through the DB Firewall (proxy)"
echo
echo "$ sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME}.proxy"
sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME}.proxy <<EOF

col ip_address format a30

show con_name;
show user;

prompt
prompt . Which IP address we are connecting from 
select SYS_CONTEXT('USERENV', 'IP_ADDRESS') IP_ADDRESS from dual;

exit;
EOF

echo
