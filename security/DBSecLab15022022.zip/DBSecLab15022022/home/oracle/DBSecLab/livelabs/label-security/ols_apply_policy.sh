#!/bin/bash

# =========================================================================================
# Script Name : ols_apply_policy.sh
#
# Parameter   : None
#
# Notes       : Apply the policy to EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Apply the policy to EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES..."
echo "=============================================================================="

sqlplus -s ${DBUSR_OLS_LBAC}/${DBUSR_PWD}@${PDB_NAME} << EOF

set trimspool on;
set lines 180
set pages 999
set echo on;

show user;

prompt
prompt . Apply the policy
begin
 SA_POLICY_ADMIN.APPLY_TABLE_POLICY(
   policy_name => 'OLS_DEMO_HR_APP'
 , schema_name =>'EMPLOYEESEARCH_PROD'
 , table_name =>'DEMO_HR_EMPLOYEES');
end;
/

exit;
EOF

echo
