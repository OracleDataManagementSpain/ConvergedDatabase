#!/bin/bash

# =========================================================================================
# Script Name : ols_setup_glassfish_policy.sh
#
# Parameter   : None
#
# Notes       : Setup the OLS policy for Glassfish
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Setup the OLS policy for Glassfish..."
echo "=============================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD} as sysdba <<EOF

set trimspool on;
set lines 180
set pages 999
set echo on;
col osuser      format a18
col machine     format a25
col program      format a35
col pdb_name    format a12
col name        format a25
col description format a40
col status      format a12

spool ols_setup_glassfish_policy.out

prompt
prompt . Configure OLS for CDB
-- --------------------------------
show user;
alter user ${DBUSR_OLS_LBAC} identified by ${DBUSR_PWD} account unlock container=all;
select a.name pdb_name, b.name, b.status, b.description from v\$containers a, cdb_ols_status b where a.con_id = b.con_id;
EXEC ${DBUSR_OLS_LBAC}.CONFIGURE_OLS;
EXEC ${DBUSR_OLS_LBAC}.OLS_ENFORCEMENT.ENABLE_OLS;

prompt
prompt . Reboot DB
-- --------------------------------
shutdown immediate;
startup;
alter pluggable database all open;
select a.name pdb_name, b.name, b.status, b.description from v\$containers a, cdb_ols_status b where a.con_id = b.con_id

prompt
prompt . Configure OLS for PDB
-- --------------------------------
connect ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba
show con_name;
show user;
grant select_catalog_role to ${DBUSR_OLS_LBAC};
EXEC ${DBUSR_OLS_LBAC}.CONFIGURE_OLS;
EXEC ${DBUSR_OLS_LBAC}.OLS_ENFORCEMENT.ENABLE_OLS;

prompt
prompt . Reboot PDB
-- --------------------------------
connect / as sysdba
alter pluggable database pdb1 close immediate;
alter pluggable database pdb1 open;
show pdbs

prompt
prompt . Configure OLS Policy
-- --------------------------------
connect ${DBUSR_OLS_LBAC}/${DBUSR_PWD}@${PDB_NAME}

show con_name;
show user;

-- ==============================================
prompt ... Create OLS Policy "OLS_DEMO_HR_APP" on "DEMO_HR_EMPLOYEES" table
-- ==============================================
prompt ... ... Drop existing OLS Policy
begin 
 ${DBUSR_OLS_LBAC}.SA_SYSDBA.DROP_POLICY(
    policy_name => 'OLS_DEMO_HR_APP',
     drop_column => TRUE);
end;
/

prompt ... ... Create the OLS Policy "OLS_DEMO_HR_APP"
-- Protect all DML: READ,INSERT,UPDATE,DELETE
-- Create a hdiden column named OLSLABEL on any table we control with this policy
begin 
 ${DBUSR_OLS_LBAC}.SA_SYSDBA.CREATE_POLICY(
    policy_name => 'OLS_DEMO_HR_APP'
  , column_name => 'OLSLABEL'
  , default_options => 'READ_CONTROL,WRITE_CONTROL,LABEL_DEFAULT,HIDE'); 
end;
/

prompt ... ... Disable OLS Policy
-- Start with our policy disabled so we can label the data that is already in the table
begin
 ${DBUSR_OLS_LBAC}.SA_SYSDBA.DISABLE_POLICY(
    policy_name => 'OLS_DEMO_HR_APP');
end;
/

-- ==============================================
prompt ... Create OLS Levels
-- ==============================================
prompt ... ... Create "Public" OLS Level
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_LEVEL(
    policy_name => 'OLS_DEMO_HR_APP'
  , level_num => 1000
  , short_name => 'P'
   , long_name => 'PUBLIC'); 
end;
/

prompt ... ... Create "Confidential" OLS Level
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_LEVEL(
    policy_name => 'OLS_DEMO_HR_APP'
  , level_num => 3000
  , short_name => 'C'
   , long_name => 'CONFIDENTIAL'); 
end;
/

prompt ... ... Create "Highly Confidential" OLS Level
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_LEVEL(
    policy_name => 'OLS_DEMO_HR_APP'
  , level_num => 5000
  , short_name => 'HC'
   , long_name => 'HIGHLY CONFIDENTIAL'); 
end;
/

-- ==============================================
prompt ... Create OLS Compartments
-- ==============================================
prompt ... ... Create "HR" compartment
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_COMPARTMENT(
    policy_name => 'OLS_DEMO_HR_APP'
  , comp_num => 100
  , short_name => 'HR'
  , long_name => 'HR'); 
end; 
/

prompt ... ... Create "FIN" compartment
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_COMPARTMENT(
    policy_name => 'OLS_DEMO_HR_APP'
  , comp_num => 200
  , short_name => 'FIN'
  , long_name => 'FINANCE'); 
end; 
/

prompt ... ... Create "IP" compartment
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_COMPARTMENT(
    policy_name => 'OLS_DEMO_HR_APP'
  , comp_num => 300
  , short_name => 'IP'
  , long_name => 'INTELLECTUAL_PROPERTY'); 
end; 
/

prompt ... ... Create "IT" compartment
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_COMPARTMENT(
    policy_name => 'OLS_DEMO_HR_APP'
  , comp_num => 400
  , short_name => 'IT'
  , long_name => 'INFORMATION_TECHNOLOGY'); 
end; 
/

-- ==============================================
prompt ... Create OLS Groups
-- ==============================================
-- Our example is a heiararchy of groups
-- GLOBAL
	-- USA
  -- CAN
  -- LATAM
	-- EU
		-- GERMANY
	
prompt ... ... Create "GBL" OLS Group
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_GROUP(
   policy_name => 'OLS_DEMO_HR_APP'
 , group_num => 1000
 , short_name => 'GBL'
 , long_name => 'GLOBAL'
 , parent_name => null); 
end; 
/

prompt ... ... Create "USA" OLS Group
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_GROUP(
   policy_name => 'OLS_DEMO_HR_APP'
 , group_num => 1100
 , short_name => 'USA'
 , long_name => 'USA'
 , parent_name => 'GBL'); 
end;
/

prompt ... ... Create "CAN" OLS Group
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_GROUP(
   policy_name => 'OLS_DEMO_HR_APP'
 , group_num => 1200
 , short_name => 'CAN'
 , long_name => 'CANADA'
 , parent_name => 'GBL'); 
end; 
/

prompt ... ... Create "LTM" OLS Group
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_GROUP(
   policy_name => 'OLS_DEMO_HR_APP'
 , group_num => 1400
 , short_name => 'LTM'
 , long_name => 'LATAM'
 , parent_name => 'GBL'); 
end; 
/

prompt ... ... Create "EU" OLS Group
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_GROUP(
   policy_name => 'OLS_DEMO_HR_APP'
 , group_num => 1300
 , short_name => 'EU'
 , long_name => 'EU'
 , parent_name => 'GBL'); 
end;
/

prompt ... ... Create "GER" OLS Group
begin 
 ${DBUSR_OLS_LBAC}.SA_COMPONENTS.CREATE_GROUP(
   policy_name => 'OLS_DEMO_HR_APP'
 , group_num => 1310
 , short_name => 'GER'
 , long_name => 'GERMANY'
 , parent_name => 'EU'); 
end;
/

-- ==============================================
prompt ... Set EMPLOYEESERCH to have highest level, all compartments, and GBL group
-- ==============================================
BEGIN
   SA_USER_ADMIN.SET_USER_LABELS(
       policy_name => 'OLS_DEMO_HR_APP' 
      ,user_name =>   'EMPLOYEESEARCH_PROD'
      ,max_read_label => 'HC:IT,IP,FIN,HR:GBL'
   );
END;
/

-- ==============================================
prompt ... Create OLS Labels
-- ==============================================

BEGIN
 SA_LABEL_ADMIN.CREATE_LABEL  (
  policy_name     => 'OLS_DEMO_HR_APP',
  label_tag       => '1000',
  label_value     => 'P',
  data_label      => TRUE);
END;
/

BEGIN
 SA_LABEL_ADMIN.CREATE_LABEL  (
  policy_name     => 'OLS_DEMO_HR_APP',
  label_tag       => '3000',
  label_value     => 'C',
  data_label      => TRUE);
END;
/

BEGIN
 SA_LABEL_ADMIN.CREATE_LABEL  (
  policy_name     => 'OLS_DEMO_HR_APP',
  label_tag       => '5000',
  label_value     => 'HC',
  data_label      => TRUE);
END;
/

BEGIN
 SA_LABEL_ADMIN.CREATE_LABEL  (
  policy_name     => 'OLS_DEMO_HR_APP',
  label_tag       => '1100',
  label_value     => 'P::USA',
  data_label      => TRUE);
END;
/

BEGIN
 SA_LABEL_ADMIN.CREATE_LABEL  (
  policy_name     => 'OLS_DEMO_HR_APP',
  label_tag       => '1300',
  label_value     => 'P::EU',
  data_label      => TRUE);
END;
/

-- ==============================================
prompt ... Generate Data Labels for our combinations of Levels, Compartments, or Groups
-- ==============================================
prompt ... ... Generate Data Labels for our combinations
select to_data_label('OLS_DEMO_HR_APP','P') from dual;
select to_data_label('OLS_DEMO_HR_APP','C') from dual;
select to_data_label('OLS_DEMO_HR_APP','HC') from dual;
select to_data_label('OLS_DEMO_HR_APP','P:IT') from dual;
select to_data_label('OLS_DEMO_HR_APP','P:IP') from dual;
select to_data_label('OLS_DEMO_HR_APP','P:HR') from dual;
select to_data_label('OLS_DEMO_HR_APP','P:FIN') from dual;

prompt ... ... Create HC data labels with groups
prompt create HC data labels with groups
select to_data_label('OLS_DEMO_HR_APP','HC::GBL') from dual;
select to_data_label('OLS_DEMO_HR_APP','HC::USA') from dual;
select to_data_label('OLS_DEMO_HR_APP','HC::EU') from dual;
select to_data_label('OLS_DEMO_HR_APP','HC::GER') from dual;
select to_data_label('OLS_DEMO_HR_APP','HC::CAN') from dual;
select to_data_label('OLS_DEMO_HR_APP','HC::LTM') from dual;

prompt ... ... Create Public data labels with groups
prompt create HC data labels with groups
select to_data_label('OLS_DEMO_HR_APP','P::GBL') from dual;
select to_data_label('OLS_DEMO_HR_APP','P::USA') from dual;
select to_data_label('OLS_DEMO_HR_APP','P::EU') from dual;
select to_data_label('OLS_DEMO_HR_APP','P::GER') from dual;
select to_data_label('OLS_DEMO_HR_APP','P::LTM') from dual;
select to_data_label('OLS_DEMO_HR_APP','P::CAN') from dual;

prompt ... ... Create EMPLOYEESEARCH_PROD data labels with everything
select to_data_label('OLS_DEMO_HR_APP','HC:IT,FIN,HR,IP:GBL,USA,EU,GER,LTM,CAN') from dual;

prompt ... ... Create EMPLOYEESEARCH_PROD data labels with everything
select to_data_label('OLS_DEMO_HR_APP','HC:IT,FIN,HR,IP:GBL') from dual;

-- ==============================================
prompt ... Setup User EMPLOYEESEARCH_PROD
-- ==============================================
prompt ... ... Set Levels for User
BEGIN
 SA_USER_ADMIN.SET_LEVELS (
  policy_name   => 'OLS_DEMO_HR_APP',
  user_name     => 'EMPLOYEESEARCH_PROD', 
  max_level     => 'HC',
  min_level     => 'P',
  def_level     => 'HC',
  row_level     => 'HC');
END;
/

prompt ... ... Set Group for User
BEGIN
 SA_USER_ADMIN.SET_GROUPS (
  policy_name   => 'OLS_DEMO_HR_APP',
  user_name     => 'EMPLOYEESEARCH_PROD', 
  READ_GROUPS   => 'GBL',
  WRITE_GROUPS  => 'GBL',
  DEF_GROUPS    => 'GBL',
  ROW_GROUPS    => 'GBL');
END;
/

prompt ... ... Give EMPLOYEESEARCH_PROD NULL privileges on OLS controlled objects
-- Make sure EMPLOYEESEARCH_PROD has NULL privileges on OLS controlled objects
-- Other options include FULL which would bypass OLS but we do not want that here
BEGIN
 SA_USER_ADMIN.SET_USER_PRIVS(
  policy_name   => 'OLS_DEMO_HR_APP',
  user_name     => 'EMPLOYEESEARCH_PROD', 
  privileges    => null);
END;
/

spool off

exit;
EOF

echo
