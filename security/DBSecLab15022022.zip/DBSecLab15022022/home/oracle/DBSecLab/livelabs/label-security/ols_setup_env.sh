#!/bin/bash

# =========================================================================================
# Script Name : ols_setup_env.sh
#
# Parameter   : None
#
# Notes       : Setup the OLS environment
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Setup the OLS environment..."
echo "=============================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD} as sysdba <<EOF

set trimspool on
set lines 180
set pause on
set echo on

show con_name 

spool ols_setup_env.out

show user

prompt
prompt . Creating OLS admin user
drop user ${DBUSR_OLS_OWNER} cascade;
create user ${DBUSR_OLS_OWNER} identified by ${DBUSR_PWD};
set echo on
set pause on

prompt
prompt . Granting OLS admin user roles and privileges
grant create session to ${DBUSR_OLS_OWNER} container=all;
GRANT EXECUTE ON sa_components TO ${DBUSR_OLS_OWNER} WITH GRANT OPTION container=all;
GRANT EXECUTE ON sa_user_admin TO ${DBUSR_OLS_OWNER} WITH GRANT OPTION container=all;
GRANT EXECUTE ON sa_label_admin TO ${DBUSR_OLS_OWNER} WITH GRANT OPTION container=all;
GRANT EXECUTE ON sa_policy_admin TO ${DBUSR_OLS_OWNER} WITH GRANT OPTION container=all;
GRANT EXECUTE ON sa_audit_admin  TO ${DBUSR_OLS_OWNER} WITH GRANT OPTION container=all;
GRANT EXECUTE ON sa_sysdba TO ${DBUSR_OLS_OWNER} container=all;
GRANT EXECUTE ON to_lbac_data_label TO ${DBUSR_OLS_OWNER} container=all;
GRANT lbac_dba TO ${DBUSR_OLS_OWNER} container=all;

prompt
prompt . Connect to PDB1
alter session set container=pdb1;

prompt
prompt . Load data
@load_crm_customer_data.sql

prompt
prompt . Creating Users for the labs in the pdb

prompt
prompt ...Creating User: APPFORGET - App user that processes records marked to be forgotten
drop user APPFORGET cascade;
create user APPFORGET identified by ${DBUSR_PWD};
grant create session to APPFORGET;
grant select, insert, delete, update on APPCRM.CRM_CUSTOMER to APPFORGET;
grant create table to APPFORGET;
grant create procedure to APPFORGET;

prompt
prompt ...Creating User: APPMKT - MKT App user that processes records marked CONSENT::EMAIL
drop user APPMKT cascade;
create user APPMKT identified by ${DBUSR_PWD};

prompt
prompt ...Creating User: APPBI - BI App user that processes records marked CONSENT::ANALYTICS
drop user APPBI cascade;
create user APPBI identified by ${DBUSR_PWD};

prompt
prompt ...Creating User: APP3RD - 3rd Party App user that processes records marked CONSENT::THIRDPARTY
drop user APP3RD cascade;
create user APP3RD identified by ${DBUSR_PWD};

prompt
prompt ...Creating User: AppPreference - Preference setting App user that can process all records
drop user AppPreference cascade;
create user AppPreference identified by ${DBUSR_PWD};
grant create procedure to AppPreference;

prompt
prompt . Grant privileges to these new users
grant create session to APPMKT, APPBI, APPFORGET, APP3RD, AppPreference;
grant insert, update, select on APPCRM.CRM_CUSTOMER to APPMKT, APPBI, APPFORGET, APP3RD, AppPreference;
set pause "Press [Enter] to continue"

prompt
prompt . Configure and Enable Label Security in the pdb
EXEC LBACSYS.CONFIGURE_OLS;
EXEC LBACSYS.OLS_ENFORCEMENT.ENABLE_OLS;

spool off

exit;
EOF

echo
