#!/bin/bash

# =========================================================================================
# Script Name : ols_verify_our_policy.sh
#
# Parameter   : None
#
# Notes       : Verify the impact of the OLS Policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Verify the impact of the OLS Policy..."
echo "=============================================================================="

sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME} << EOF

set trimspool on;
set lines 180
set pages 999
set echo on;
col OLS_READ_LABEL format a40
col city           format a30
col char_label     format a40

spool ols_verify_our_policy.out

show user

prompt
prompt . First we will clean up the DEMO_HR_ERROR_LOG table so we can see errors if we have them
truncate table EMPLOYEESEARCH_PROD.demo_hr_error_log;
select * from EMPLOYEESEARCH_PROD.demo_hr_error_log;

prompt
prompt . Before we query based on OLS, lets get an overview of the data we will work with
prompt   (This is all of the rows in DEMO_HR_EMPLOYEES)
select count(*) from EMPLOYEESEARCH_PROD.demo_hr_employees;

prompt
prompt  . Here is the distribution of city data
select city, count(city) count_city
  from EMPLOYEESEARCH_PROD.demo_hr_employees
 group by city
 order by city;

prompt
prompt . Enable our Policy now that we have labeled data into DEMO_HR_EMPLOYEES
connect ${DBUSR_OLS_LBAC}/${DBUSR_PWD}@${PDB_NAME}
show user
begin
 ${DBUSR_OLS_LBAC}.SA_SYSDBA.ENABLE_POLICY(
    policy_name => 'OLS_DEMO_HR_APP');
end;
/

connect ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}

prompt
-- =====================================================
prompt . This is what EMPLOYEESEARCH_PROD sees:
-- =====================================================
prompt ... This is what our DB user, and schema owner, EMPLOYEESEARCH_PROD has for a label
prompt     He should have everything because we want him to be able to see every combination of labels
select sa_session.read_label('OLS_DEMO_HR_APP') OLS_READ_LABEL from dual;

prompt
-- =====================================================
prompt . This is what HRADMIN sees:
-- =====================================================
prompt ... This is what app user HRADMIN sees when we use our procedure to set his label 
prompt     His label is set based on his row value in DEMO_HR_USER_LABELS
prompt
exec EMPLOYEESEARCH_PROD.set_app_user_label('hradmin');

prompt
prompt ... This is what our app user HRADMIN has for a label
prompt     He should have everything because we want him to be able to see every combination of labels
prompt
select sa_session.read_label('OLS_DEMO_HR_APP') OLS_READ_LABEL from dual;

prompt 
prompt ... How many rows get returned? It should be every row in the table
select count(*) from EMPLOYEESEARCH_PROD.demo_hr_employees;

prompt
prompt ... How many cities can be seen by app user HRADMIN
select city, count(city) count_city
  from EMPLOYEESEARCH_PROD.demo_hr_employees
 group by city
 order by city;

prompt 
prompt ... How many distinct OLSLABELS, and the varchar translation, are accessible
select distinct olslabel, label_to_char(olslabel) char_label from EMPLOYEESEARCH_PROD.demo_hr_employees;

prompt
-- =====================================================
prompt . This is what App User EU_EVAN sees:
-- =====================================================
prompt ... When we use our procedure to set his label 
prompt     His label is set based on his row value in DEMO_HR_USER_LABELS
exec EMPLOYEESEARCH_PROD.set_app_user_label('eu_evan');
select sa_session.read_label('OLS_DEMO_HR_APP') OLS_READ_LABEL from dual;
select count(*) from EMPLOYEESEARCH_PROD.demo_hr_employees;

prompt
prompt ... How many cities can be seen by app user EU_EVAN
select city, count(city) count_city
  from EMPLOYEESEARCH_PROD.demo_hr_employees
 group by city
 order by city;

prompt 
prompt ... How many distinct OLSLABELS, and the varchar translation, are accessible by app user EU_EVAN
prompt   His label is set based on his row value in DEMO_HR_USER_LABELS
select distinct olslabel, label_to_char(olslabel) char_label from EMPLOYEESEARCH_PROD.demo_hr_employees;


prompt
-- =====================================================
prompt . This is what App User CAN_CANDY sees:
-- =====================================================
prompt ... This is what app user CAN_CANDY sees when we use our procedure to set her label 
prompt     Her label is set based on his row value in DEMO_HR_USER_LABELS
exec EMPLOYEESEARCH_PROD.set_app_user_label('can_candy');
select sa_session.read_label('OLS_DEMO_HR_APP') OLS_READ_LABEL from dual;
select count(*) from EMPLOYEESEARCH_PROD.demo_hr_employees;

prompt
prompt ... How many cities can be seen by app user CAN_CANDY
select city, count(city) count_city
  from EMPLOYEESEARCH_PROD.demo_hr_employees
 group by city
 order by city;

prompt 
prompt ... How many distinct OLSLABELS, and the varchar translation, are accessible by app user CAN_CANDY
select distinct olslabel, label_to_char(olslabel) char_label from EMPLOYEESEARCH_PROD.demo_hr_employees;

spool off

exit;
EOF

echo
