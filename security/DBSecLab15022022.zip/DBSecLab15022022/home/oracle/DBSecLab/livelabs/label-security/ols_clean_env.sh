#!/bin/bash

# =========================================================================================
# Script Name : ols_clean_env.sh
#
# Parameter   : None
#
# Notes       : Clean the OLS environment
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Clean the OLS environment..."
echo "=============================================================================="

sqlplus -s ${DBUSR_OLS_OWNER}/${DBUSR_PWD}@${PDB_NAME} << EOF

set echo on
set feedback on
col policy_name format a20
col column_name format a20
col status format a15
col short_name format a15

spool ols_clean_env.out

show con_name
show user

prompt
prompt . List the current OLS objects
prompt ... OLS Policies
select policy_name, column_name, status from all_sa_policies;

prompt ... OLS Levels
select policy_name, level_num, short_name from ALL_SA_LEVELS;

prompt ... OLS Groups
select policy_name, group_num, short_name from ALL_SA_GROUPS;

prompt
prompt . Delete the OLS policy "OLS_DEMO_GDPR"
EXEC SA_SYSDBA.DROP_POLICY(policy_name => 'OLS_DEMO_GDPR');
/

prompt
prompt . List the OLS objects after deleting
prompt ... OLS Policies
select policy_name, column_name, status from all_sa_policies;

prompt ... OLS Levels
select policy_name, level_num, short_name from ALL_SA_LEVELS;

prompt ... OLS Groups
select policy_name, group_num, short_name from ALL_SA_GROUPS;

conn ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba

prompt
prompt . Dropping OLS Lab users
drop user appcrm cascade;
drop user appmkt cascade;
drop user appbi cascade;
drop user appforget cascade;
drop user app3rd cascade;
drop user AppPreference cascade;

prompt
prompt . Disable OLS
EXEC LBACSYS.OLS_ENFORCEMENT.DISABLE_OLS;

conn ${DBUSR_SYS}/${DBUSR_PWD} as sysdba

prompt
prompt . Drop OLS Admin user
drop user ${DBUSR_OLS_OWNER} cascade;

spool off

exit;
EOF

echo
