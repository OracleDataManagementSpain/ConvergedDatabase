#!/bin/bash

# =========================================================================================
# Script Name : ols_to_be_forgotten.sh
#
# Parameter   : None
#
# Notes       : Change users status to be forgotten
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Change users status to be forgotten..."
echo "=============================================================================="

sqlplus -s APPFORGET/${DBUSR_PWD}@${PDB_NAME} << EOF

set trimspool on
set lines 180
set pages 999
set echo on
set serverout on
col label format a25
col count format 999999

spool ols_to_be_forgotten.out

show con_name
show user

prompt
prompt . Create the procedure "PROCESS_DATA" to process requests to be forgotten for anonymization purposes
-- Run as APPFORGET (def_level: FRGT)
-- ------------------------------------------------------
CREATE OR REPLACE PROCEDURE process_data 
AS
  v_session_label VARCHAR2(4000);
  v_cnt   number;

  CURSOR c1 IS
    SELECT customerid, first_name, last_name, email
      FROM APPCRM.CRM_CUSTOMER
     WHERE gdpr_col = CHAR_TO_LABEL('OLS_DEMO_GDPR','FRGT::')
     ORDER BY 1;

  BEGIN

    SELECT label 
      INTO v_session_label
      FROM user_sa_session
     WHERE label = 'FRGT';

    DBMS_OUTPUT.PUT_LINE('... User Session Label = ' || v_session_label);

    FOR item IN c1
      LOOP
        DBMS_OUTPUT.PUT_LINE('... ... Processing Data for User_ID (' || item.customerid||'): '|| item.first_name||' '||item.last_name|| ' (' ||item.email||')');
        v_cnt:=c1%ROWCOUNT;
      END LOOP;

    DBMS_OUTPUT.PUT_LINE('... Customers Processed = ' ||v_cnt);
  END;
/

prompt
prompt . These would be the records to be anonimized
exec process_data;

conn APPPREFERENCE/${DBUSR_PWD}@${PDB_NAME}

prompt
prompt . Create the procedure "FORGET_ME" to forget customers
-- ------------------------------------------------------
create or replace procedure forget_me (p_customerid number) 
as
BEGIN
  UPDATE APPCRM.CRM_CUSTOMER
     SET GDPR_COL = CHAR_TO_LABEL('OLS_DEMO_GDPR','FRGT::')
   WHERE customerid = p_customerid;

COMMIT;

DBMS_OUTPUT.PUT_LINE('User ' || p_customerid||' is now forgotten.' );
END;
/
-- ------------------------------------------------------

prompt
prompt . How many records are currently marked "FRGT"
SELECT LABEL_TO_CHAR (GDPR_COL) label, COUNT(*) count 
  FROM APPCRM.CRM_CUSTOMER GROUP BY GDPR_COL
 ORDER BY 1;

prompt
prompt . The User ID "100" asked to be forgotten
prompt $ exec forget_me(100);
exec forget_me(100);

prompt
prompt . Now, let's check how many records are marked "FRGT"
SELECT LABEL_TO_CHAR (GDPR_COL) label, COUNT(*) count 
  FROM APPCRM.CRM_CUSTOMER GROUP BY GDPR_COL
 ORDER BY 1;

conn APPFORGET/${DBUSR_PWD}@${PDB_NAME}

set serverout on

prompt
prompt . These would be the records to be anonimized
exec process_data;

spool off

exit;
EOF

echo
