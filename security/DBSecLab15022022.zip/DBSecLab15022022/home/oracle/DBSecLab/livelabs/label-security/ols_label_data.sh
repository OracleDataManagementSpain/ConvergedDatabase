#!/bin/bash

# =========================================================================================
# Script Name : ols_label_data.sh
#
# Parameter   : None
#
# Notes       : Label the data
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Label the data..."
echo "=============================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba <<EOF

set trimspool on
set lines 180
set pages 999
set echo on
col label format a50
col count format 9999999

spool ols_label_data.out

show con_name
show user

-----------------------------------------------------------------------
-- Mass Update the labels to get some diversity (Total records: 389) --
-- In real life, we could have created a labelling function to label -- 
-- records based on other column values                              --
-----------------------------------------------------------------------
prompt
prompt . ANON - Already anonymized: 10 records
UPDATE APPCRM.CRM_CUSTOMER
SET gdpr_col = CHAR_TO_LABEL('OLS_DEMO_GDPR','ANON')
where customerid between 51 and 60;

prompt
prompt . CNST::ANALYTICS - Consented to be processed for analytics: 200 records
UPDATE APPCRM.CRM_CUSTOMER
SET gdpr_col = CHAR_TO_LABEL('OLS_DEMO_GDPR','CNST::ANALYTICS')
where customerid between 66 and 265;

prompt
prompt . CNST::EMAIL - Consented to be processed for email: 123 records
UPDATE APPCRM.CRM_CUSTOMER
SET gdpr_col = CHAR_TO_LABEL('OLS_DEMO_GDPR','CNST::EMAIL')
where customerid between 266 and 388;

prompt
prompt . CNST::EMAIL,ANALYTICS - Consented to be processed for email and bi: 3 records
UPDATE APPCRM.CRM_CUSTOMER
SET gdpr_col = CHAR_TO_LABEL('OLS_DEMO_GDPR','CNST::EMAIL,ANALYTICS')
where customerid >= 389;

prompt
prompt . FRGT - Asked to be forgotten: 5 records
UPDATE APPCRM.CRM_CUSTOMER
SET gdpr_col = CHAR_TO_LABEL('OLS_DEMO_GDPR','FRGT')
where customerid between 61 and 65;

prompt
prompt . NCNST - Did not consent or revoked consent: 50 records
UPDATE APPCRM.CRM_CUSTOMER
SET GDPR_COL = CHAR_TO_LABEL('OLS_DEMO_GDPR','NCNST')
where customerid between 1 and 50;

commit;

prompt
prompt . Show the count per Label
SELECT LABEL_TO_CHAR (GDPR_COL) label, count(*) count
  FROM APPCRM.CRM_CUSTOMER
 GROUP BY GDPR_COL
 ORDER BY label;

spool off

exit;
EOF

echo
