#!/bin/bash

# =========================================================================================
# Script Name : ols_restore_glassfish_env.sh
#
# Parameter   : None
#
# Notes       : Restore the Glassfish environment with no OLS policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Restore the Glassfish environment with no OLS policy..."
echo "=============================================================================="

sqlplus -s ${DBUSR_OLS_LBAC}/${DBUSR_PWD}@${PDB_NAME} << EOF

set echo on;

show con_name;
show user;

prompt
prompt . Drop the OLS Policy
begin 
 ${DBUSR_OLS_LBAC}.SA_SYSDBA.DROP_POLICY(
    policy_name => 'OLS_DEMO_HR_APP',
     drop_column => TRUE);
end;
/

prompt
prompt . Drop DEMO_HR_ERROR_LOG table
connect ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME}
show user;
drop table employeesearch_prod.demo_hr_error_log;

exit;
EOF

echo 
echo ". Restore the original Glassfish conf files"
cd ${GLASSFISH_HOME}
tar zxvf ${GLASSFISH_HOME}/hr_prod_pdb1_orig.tar.gz

echo
echo ". Reboot Glassfish"
${DBSEC_ADMIN}/stop_Glassfish.sh
${DBSEC_ADMIN}/start_Glassfish.sh

echo 
echo ". Delete the OLS .out files"
cd ${DBSEC_LABS}/label-security
find ./ -type f -name "*.out" 
find ./ -type f -name "*.out" -exec rm {} \;
find ./ -type f -name "*.out" 

echo
echo "Your Glassfish App environment (hr_prod_pdb1) is restored as it was before OLS activation!"

echo
