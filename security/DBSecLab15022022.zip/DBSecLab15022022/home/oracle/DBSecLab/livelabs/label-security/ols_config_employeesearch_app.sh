#!/bin/bash

# =========================================================================================
# Script Name : ols_config_employeesearch_app.sh
#
# Parameter   : None
#
# Notes       : Create EMPLOYEESEARCH App
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Create EMPLOYEESEARCH App..."
echo "=============================================================================="

sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME} << EOF

set trimspool on;
set lines 180
set pages 999
set echo on;

show con_name;
show user;

prompt
prompt . Make sure we remove our demo users so we can start fresh
delete from employeesearch_prod.demo_hr_users where userid in ('revans','eu_evan','can_candy');
delete from employeesearch_prod.demo_hr_user_labels where userid in ('revans','eu_evan','can_candy');

prompt
prompt . Create our User Labels table so we can set the label for our app users when they login
-- --------------------------------
drop table employeesearch_prod.demo_hr_user_labels;
create table employeesearch_prod.demo_hr_user_labels
(userid    VARCHAR2(128) NOT NULL
,olslabel   VARCHAR2(128) NOT NULL);
alter table employeesearch_prod.demo_hr_user_labels add primary key (userid);

prompt
prompt . Insert all users from DEMO_HR_USERS into our DEMO_HR_USER_LABELS table and give them 'P' as their label
insert into employeesearch_prod.demo_hr_user_labels (userid,olslabel) select distinct userid, 'P' from employeesearch_prod.demo_hr_users order by 1;

prompt
prompt . Create our demo users 
prompt Create our demo users within the HR APP table

prompt
prompt . Insert values
prompt ... Canadian Lady
insert into employeesearch_prod.demo_hr_users values ('can_candy','Oracle123','CAN','Candy','can.candy@oracle.com','ENABLE',sysdate-30,sysdate);
insert into employeesearch_prod.demo_hr_roles	values ('can_candy','SELECT');
insert into DEMO_HR_USER_LABELS values ('can_candy','P::CAN');

prompt ... Insert our EU Gentleman
insert into employeesearch_prod.demo_hr_users values ('eu_evan','Oracle123','EU','Evan','eu.evan@oracle.com','ENABLE',sysdate-30,sysdate);
insert into employeesearch_prod.demo_hr_roles	values ('eu_evan','SELECT');
insert into employeesearch_prod.demo_hr_roles	values ('eu_evan','CORPORATE');
insert into employeesearch_prod.demo_hr_roles	values ('eu_evan','INSERT');
delete from demo_hr_roles where userid = 'eu_evan' and roleid = 'ENGINEERING';
insert into employeesearch_prod.DEMO_HR_USER_LABELS values ('eu_evan','P::EU');

prompt
prompt . Make all of our HR App Users have "Public" access level
update employeesearch_prod.demo_hr_user_labels set olslabel = 'P';

prompt
prompt . Set the OLSLABEL for hradmin, eu_evan, and can_candy in our DEMO_HR_USER_LABELS table
update employeesearch_prod.demo_hr_user_labels set olslabel = 'HC::GBL' where userid = 'hradmin';
update employeesearch_prod.demo_hr_user_labels set olslabel = 'P::EU' where userid = 'eu_evan';
update employeesearch_prod.demo_hr_user_labels set olslabel = 'P::CAN' where userid = 'can_candy';

commit;

prompt
prompt . Create our error log table
drop table employeesearch_prod.demo_hr_error_log;
create table employeesearch_prod.demo_hr_error_log (userid varchar2(128) not null, olslabel  varchar2(120), login_timestamp timestamp);

prompt
prompt . Create our "EMPLOYEESEARCH_PROD.SET_APP_USER_LABEL" procedure
prompt   This should be updated to accept p_policy_name too so we can pass the policy name dynamically
create or replace procedure set_app_user_label(p_username VARCHAR2)
  is
    v_username          VARCHAR2(30);
    v_olslabel          VARCHAR2(120) := 'P';
    v_ols_policy_name   VARCHAR2(60) := 'OLS_DEMO_HR_APP';
    v_code              NUMBER;
    v_errm              VARCHAR2(128);

  begin

    select upper(SYS.DBMS_ASSERT.simple_sql_name(p_username))
      into v_username
      from dual;

    DBMS_APPLICATION_INFO.SET_CLIENT_INFO('DEMO_HR_APP');
    DBMS_SESSION.SET_IDENTIFIER(v_username);
    
    select olslabel
      into v_olslabel
      from employeesearch_prod.demo_hr_user_labels
     where upper(userid) = v_username;

    BEGIN
      SA_SESSION.SET_LABEL (
        policy_name => 'OLS_DEMO_HR_APP',
        label       => v_olslabel);
    END;

    BEGIN
      SA_SESSION.SET_ROW_LABEL (
        policy_name => 'OLS_DEMO_HR_APP',
        label       => v_olslabel);
    END;

    --insert into employeesearch_prod.demo_hr_error_log (userid, olslabel, login_timestamp) values (v_username, v_olslabel, systimestamp);

    commit;

  end;
/

show errors;

exit;
EOF

echo
