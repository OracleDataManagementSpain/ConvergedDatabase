#!/bin/bash

# =========================================================================================
# Script Name : ols_set_row_labels.sh
#
# Parameter   : None
#
# Notes       : Update "EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES" table to populate the
#               "OLSLABEL" column with the appropriate OLS numeric label
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Update EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES table to populate the"
echo " OLSLABEL column with the appropriate OLS numeric label..."
echo "=============================================================================="

sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME} << EOF

set trimspool on;
set lines 180
set pages 999
set echo on;

show user

prompt
prompt . Set the row labels in EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES
update EMPLOYEESEARCH_PROD.demo_hr_employees set city = 'Berlin' where city is null;
update EMPLOYEESEARCH_PROD.demo_hr_employees set olslabel = char_to_label('OLS_DEMO_HR_APP','P::GER') where city = 'Berlin';
update EMPLOYEESEARCH_PROD.demo_hr_employees set olslabel = char_to_label('OLS_DEMO_HR_APP','P::USA') where city in ('Costa Mesa','New York','Santa Clara','Sunnyvale');
update EMPLOYEESEARCH_PROD.demo_hr_employees set olslabel = char_to_label('OLS_DEMO_HR_APP','P::EU') where city in ('Paris','London');
update EMPLOYEESEARCH_PROD.demo_hr_employees set olslabel = char_to_label('OLS_DEMO_HR_APP','P::CAN') where city in ('Toronto');

commit;

exit;
EOF

echo
