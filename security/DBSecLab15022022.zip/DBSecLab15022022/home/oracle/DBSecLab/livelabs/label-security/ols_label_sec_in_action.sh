#!/bin/bash

# =========================================================================================
# Script Name : ols_label_sec_in_action.sh
#
# Parameter   : None
#
# Notes       : Connects as different apps would be connecting to see records that they would be able to process
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Connects as different apps would be connecting to see records that they would be able to process..."
echo "=============================================================================="

sqlplus -s /nolog <<EOF

set trimspool on
set lines 180
set pages 999
set echo on

spool ols_label_sec_in_action.out

prompt
prompt . Marketing App would only show 126 records
prompt   (Can process data labeled: CNST::EMAIL and CNST::ANALYTICS, EMAIL)
conn APPMKT/${DBUSR_PWD}@${PDB_NAME}
select count(*) from APPCRM.CRM_CUSTOMER;

prompt
prompt . BI App would only show 213 records
prompt   (Can process data labeled: ANON, CNST::ANALYTICS, CNST::ANALYTICS, EMAIL)
conn APPBI/${DBUSR_PWD}@${PDB_NAME}
select count(*) from APPCRM.CRM_CUSTOMER;

prompt
prompt . FORGET App would only show 15 records
prompt   (Can process data labeled: FRGT and ANON)
conn APPFORGET/${DBUSR_PWD}@${PDB_NAME}
select count(*) from APPCRM.CRM_CUSTOMER;

prompt
prompt . APPPREFERENCE App can be used to set consent
prompt   (Can process ALL records - 391)
conn  APPPREFERENCE/${DBUSR_PWD}@${PDB_NAME}
select count(*) from APPCRM.CRM_CUSTOMER;

prompt
prompt . What labels are currently in session?
select label from user_sa_session;

prompt
prompt . What is the session row label?
select SA_SESSION.ROW_LABEL('OLS_DEMO_GDPR') from DUAL;

spool off

exit;
EOF

echo
