#!/bin/bash

# =========================================================================================
# Script Name : ols_setup_glassfish_env.sh
#
# Parameter   : None
#
# Notes       : Setup the Glassfish environment
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Setup the Glassfish environment..."
echo "=============================================================================="

echo
echo ". Check Glassfish environment"
if [ `ps -ef | grep $GLASSFISH_HOME | grep -v grep | wc -l` -eq 0 ]; then

 echo
 echo "--------------------------------------------------------"
 echo "!!! WARNING !!!"
 echo "Glassfish is not starting so we will start it for you!"
 echo "--------------------------------------------------------"
 echo
 ${DBSEC_ADMIN}/start_Glassfish.sh
 echo " Done!"
 
fi

# Make sure the files are original and not OLS enabled
#  - if it is, we will use our original backup file
#  - if it is not, we will continue as expected
cd ${GLASSFISH_HOME}
if [ "`grep -il set_app_user_label hr_prod_pdb1/*.jsp* | wc -l`" -gt "0" ]
 then
  echo 
  echo "--------------------------------------------------------"
  echo "!!! WARNING !!!"
  echo " OLS hr_prod_pdb1 files are already in place"
  echo "--------------------------------------------------------"
  echo ". We must restore the original hr_prod_pdb1 files first!"
  echo
  tar zxvf ${GLASSFISH_HOME}/hr_prod_pdb1_orig.tar.gz
  echo "..."
  sleep 2
  echo ". And reboot Glassfish"
  ${DBSEC_ADMIN}/stop_Glassfish.sh
  ${DBSEC_ADMIN}/start_Glassfish.sh
  echo "Done!"
fi

echo
echo "Glassfish App (hr_prod_pdb1) is ready for the labs!"

echo
