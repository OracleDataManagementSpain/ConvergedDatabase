#!/bin/bash

# =========================================================================================
# Script Name : ols_udp_glassfish.sh
#
# Parameter   : None
#
# Notes       : Update Glassfish environment to protect the app with OLS policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           09/06/2020      Creation
# HLO           13/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Update Glassfish environment to protect the app with OLS policy..."
echo "=============================================================================="

#export CURR_DIR=`dirname "$(readlink -f "$0")"`
export CURR_DIR=$DBSEC_LABS/label-security/hr_prod_pdb1_ols
export HRAPP_PROD1_DIR=${GLASSFISH_HOME}/hr_prod_pdb1

echo
echo ". These are the updated .jsp files we will be using"
ls -al ${CURR_DIR}/*.jsp

echo
echo ". We have added an additional call to the DB to execute our set_app_user_label procedure"
sed -n '191,201p' ${CURR_DIR}/search.jsp

echo 
echo ". Changing the Glassfish conf files to embbed OLS policy"
cp ${CURR_DIR}/controller.jsp ${HRAPP_PROD1_DIR}/controller.jsp
cp ${CURR_DIR}/employee_create.jsp ${HRAPP_PROD1_DIR}/employee_create.jsp
cp ${CURR_DIR}/employee_view.jsp ${HRAPP_PROD1_DIR}/employee_view.jsp
cp ${CURR_DIR}/search.jsp ${HRAPP_PROD1_DIR}/search.jsp
cp ${CURR_DIR}/session_data.jsp ${HRAPP_PROD1_DIR}/session_data.jsp

ls -alrt ${HRAPP_PROD1_DIR}/*.jsp | tail -6

echo
echo ". Reboot the Glassfish App to enable the new settings"
echo
${GLASSFISH_HOME}/stopGlassfish.sh
${GLASSFISH_HOME}/startGlassfish.sh

echo 
echo ". Now you should be able to login and see how we have updated our application to prevent application users from seeing data"
echo
echo ". If you would like to follow along with the Glassfish log file"
echo "  you can do so by opening a terminal and executing:"
echo "  $ tail -f ${GLASSFISH_HOME}/glassfish/domains/domain1/logs/server.log"

echo
