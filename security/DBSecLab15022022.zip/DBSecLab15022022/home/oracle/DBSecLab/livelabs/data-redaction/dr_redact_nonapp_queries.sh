#!/bin/bash

# =========================================================================================
# Script Name : dr_redact_nonapp_queries.sh
#
# Parameter   : None
#
# Notes       : Modify the redaction policy to only redact non-Glassfish queries
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=========================================================================="
echo " Modify the redaction policy to only redact non-Glassfish queries"
echo "=========================================================================="

FQDN_HOST=`hostname --fqdn`

echo ". We must update the script to have the fully-qualified hostname for your VM"
echo "  Your machine is: ${FQDN_HOST}"

RULE_EXPR="'NOT (SYS_CONTEXT(''USERENV'',''SESSION_USER'') = ''EMPLOYEESEARCH_PROD'' AND SYS_CONTEXT(''USERENV'',''OS_USER'') = ''oracle'' AND SYS_CONTEXT(''USERENV'',''MODULE'') = ''JDBC Thin Client'' AND SYS_CONTEXT(''USERENV'',''HOST'') = ''$FQDN_HOST'')'"

echo ". Your Rule Set will look like this:"
echo ${RULE_EXPR}

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col policy_name   format a30
col expression    format a40
col enable        format a8
col object_owner  format a19
col object_name   format a20
col column_name   format a15
col function_type format a25

prompt
prompt . Current Data Redaction policies
select policy_name, expression, enable from redaction_policies;

prompt
prompt . Current Objects redacted by a Data Redaction policy
select object_owner, object_name, column_name, function_type from redaction_columns;

prompt
prompt . Add the Rule Set to the Data Redaction policy "PROTECT_EMPLOYEES"
BEGIN  
  DBMS_REDACT.ALTER_POLICY  (
     OBJECT_SCHEMA => 'EMPLOYEESEARCH_PROD'
    ,object_name => 'DEMO_HR_EMPLOYEES'
    ,policy_name => 'PROTECT_EMPLOYEES'
    ,action => DBMS_REDACT.MODIFY_EXPRESSION
    ,expression => ${RULE_EXPR});
END; 
/

prompt
prompt . Current Data Redaction policies
select policy_name, expression, enable from redaction_policies;

prompt
prompt . Current Objects redacted by a Data Redaction policy
select object_owner, object_name, column_name, function_type from redaction_columns;

exit;
EOF

echo
