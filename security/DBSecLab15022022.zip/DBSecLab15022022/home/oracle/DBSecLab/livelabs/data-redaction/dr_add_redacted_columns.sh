#!/bin/bash

# =========================================================================================
# Script Name : dr_add_redacted_columns.sh
#
# Parameter   : None
#
# Notes       : Add additional columns to the redaction policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Add additional columns to the redaction policy..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col policy_name   format a30
col expression    format a40
col enable        format a8
col object_owner  format a19
col object_name   format a20
col column_name   format a15
col function_type format a25

prompt
prompt . Current Data Redaction policies
select policy_name, expression, enable from redaction_policies;

prompt
prompt . Current Objects redacted by a Data Redaction policy
select object_owner, object_name, column_name, function_type from redaction_columns;

prompt
prompt . Add the column "SSN" to redact by the Data Redaction policy "PROTECT_EMPLOYEES"
BEGIN  
 DBMS_REDACT.ALTER_POLICY  (
    OBJECT_SCHEMA => 'EMPLOYEESEARCH_PROD'
   ,object_name => 'DEMO_HR_EMPLOYEES'
   ,policy_name => 'PROTECT_EMPLOYEES'
   ,action => DBMS_REDACT.ADD_COLUMN
   ,column_name => 'SSN'
   ,function_type => DBMS_REDACT.FULL );  
END; 
/

prompt
prompt . Add the column "NINO" to redact by the Data Redaction policy "PROTECT_EMPLOYEES"
BEGIN  
 DBMS_REDACT.ALTER_POLICY  (
    OBJECT_SCHEMA => 'EMPLOYEESEARCH_PROD'
   ,object_name => 'DEMO_HR_EMPLOYEES'
   ,policy_name => 'PROTECT_EMPLOYEES'
   ,action => DBMS_REDACT.ADD_COLUMN
   ,column_name => 'NINO'
   ,function_type => DBMS_REDACT.FULL );  
END; 
/

prompt
prompt . Current Data Redaction policies
select policy_name, expression, enable from redaction_policies;

prompt
prompt . Current Objects redacted by a Data Redaction policy
select object_owner, object_name, column_name, function_type from redaction_columns;

exit;
EOF

echo
