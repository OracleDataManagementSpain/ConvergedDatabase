#!/bin/bash

# =========================================================================================
# Script Name : dr_drop_redaction_policy.sh
#
# Parameter   : None
#
# Notes       : Drop the redaction policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Drop the redaction policy..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col policy_name   format a30
col expression    format a40
col enable        format a8
col object_owner  format a19
col object_name   format a20
col column_name   format a15
col function_type format a25

prompt
prompt . Current Data Redaction policies
select policy_name, expression, enable from redaction_policies;

prompt
prompt . Current Objects redacted by a Data Redaction policy
select object_owner, object_name, column_name, function_type from redaction_columns;

prompt
prompt . Drop the Data Redaction policy "PROTECT_EMPLOYEES"
BEGIN  
 DBMS_REDACT.DROP_POLICY  (
    OBJECT_SCHEMA => 'EMPLOYEESEARCH_PROD'
   ,object_name => 'DEMO_HR_EMPLOYEES'
   ,policy_name => 'PROTECT_EMPLOYEES');
END; 
/

prompt
prompt . Current Objects redacted by a Data Redaction policy
select object_owner, object_name, column_name, function_type from redaction_columns;

prompt
prompt . Current Data Redaction policies
select policy_name, expression, enable from redaction_policies;

exit;
EOF

echo
