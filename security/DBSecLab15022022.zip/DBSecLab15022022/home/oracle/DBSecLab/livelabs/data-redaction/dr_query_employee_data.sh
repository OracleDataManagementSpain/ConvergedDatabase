#!/bin/bash

# =========================================================================================
# Script Name : dr_query_employee_data.sh
#
# Parameter   : None
#
# Notes       : View sample data for table EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           28/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " View sample data for table EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col firstname       format a20
col corporate_card  format a20

select userid, firstname, sin, ssn, nino, corporate_card from demo_hr_employees where sin is not null and rownum < 6
union all
select userid, firstname, sin, ssn, nino, corporate_card from demo_hr_employees where ssn is not null and rownum < 6
union all
select userid, firstname, sin, ssn, nino, corporate_card from demo_hr_employees where nino is not null and rownum < 6;

exit;
EOF

echo
