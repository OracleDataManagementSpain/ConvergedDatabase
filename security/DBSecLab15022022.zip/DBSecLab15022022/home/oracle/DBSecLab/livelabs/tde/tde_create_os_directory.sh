#!/bin/bash

# =========================================================================================
# Script Name : tde_create_os_directory.sh
#
# Parameter   : None
#
# Notes       : Create the Keystore directories on the Operating System
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the Operating System directories for our TDE keystore..."
echo "==================================================================================="

echo
echo ". Create the TDE directories"
sudo mkdir -vp ${WALLET_DIR}/tde
sudo mkdir -vp ${WALLET_DIR}/tde_seps
sudo mkdir -vp ${WALLET_DIR}/okv
sudo chown oracle:oinstall -R /etc/ORACLE/

echo
echo ". List the directories created"
find /etc/ORACLE

echo
