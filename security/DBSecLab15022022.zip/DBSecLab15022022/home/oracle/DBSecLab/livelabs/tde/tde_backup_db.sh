#!/bin/bash

# =========================================================================================
# Script Name : tde_backup_db.sh
#
# Parameter   : None
#
# Notes       : Make a Cold Backup of the DB
#               The easiest way to ensure we have a copy of the database is to make a cold backup
#               We do this because we aren't in archive log mode
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="
echo " Make a Cold Backup of the DB..."
echo "=============================================================================="

if [[ -f "${BACKUP_FILE}" ]]; then
   echo "${BACKUP_FILE} exists... will not backup again!"
   exit 1
fi

sqlplus -s / as sysdba <<EOF

prompt
prompt . First, backup the spfile to a pfile
create pfile='$ORACLE_HOME/dbs/pfile_pre-tde.ora' from spfile;

prompt
prompt . Shutdown the DB
shutdown immediate;

exit;
EOF

echo 
echo ". Create a copy of the data files directory"
tar cvf ${BACKUP_FILE} ${DATA_DIR}

echo
echo ". Check the tar size"
du -sh ${BACKUP_FILE}

echo 
echo ". Restart the DB"
sqlplus -s / as sysdba <<EOF
startup;
exit;
EOF

echo
