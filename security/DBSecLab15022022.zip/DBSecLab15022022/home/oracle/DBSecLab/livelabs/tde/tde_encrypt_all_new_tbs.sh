#!/bin/bash

# =========================================================================================
# Script Name : tde_encrypt_all_new_tbs.sh
#
# Parameter   : None
#
# Notes       : Change the init parameter 'encrypt_new_tablespaces' to be 'ALWAYS'
#               so all new tablespaces will be encrypted
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Encrypt all new tablespaces..."
echo "==================================================================================="

sqlplus -s / as sysdba <<EOF

prompt
prompt . Show parameters like ENCRYPT
show parameter %encrypt%

prompt
prompt . Set "ALWAYS" to the hidden parameter "encrypt_new_tablespaces"
alter system set encrypt_new_tablespaces = 'ALWAYS' scope=both;

prompt
prompt . Set "AES256" to the hidden parameter "_tablespace_encryption_default_algorithm"
alter system set "_tablespace_encryption_default_algorithm" = 'AES256' scope = both;

prompt
prompt . Show parameters like ENCRYPT
show parameter %encrypt%

exit;
EOF

echo
