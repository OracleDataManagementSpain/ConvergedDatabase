#!/bin/bash

# =========================================================================================
# Script Name : tde_create_mek_cdb.sh
#
# Parameter   : None
#
# Notes       : Create the Master Key (MEK) for the container database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the master key for the container database..."
echo "==================================================================================="

sqlplus -s / as sysdba <<EOF

set lines 110
set pages 9999
col wrl_type        format a12
col wrl_parameter   format a40
col activation_time format a36
col key_use         format a14
col tag             format a36
col name            format a10

show con_name;

prompt
prompt . Show the status of the current Master Key (MEK) 
select a.con_id, b.name, a.wrl_type, a.wrl_parameter, a.status from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.con_id;

prompt
prompt . Create the CDB Master Key (MEK)
ADMINISTER KEY MANAGEMENT SET KEY USING TAG 'CDB1: Initial Master Key' IDENTIFIED BY ${DBUSR_PWD} WITH BACKUP container=current;

prompt
prompt . Show the status of the current Master Key (MEK) 
select a.con_id, b.name, a.wrl_type, a.wrl_parameter, a.status from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.con_id;

exit;
EOF

echo
