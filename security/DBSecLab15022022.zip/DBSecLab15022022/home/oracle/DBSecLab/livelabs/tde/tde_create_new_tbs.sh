#!/bin/bash

# =========================================================================================
# Script Name : tde_create_new_tbs.sh
#
# Parameter   : None
#
# Notes       : Create a new tablspace
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create a new tablespace to show it was encrypted..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 140
set pages 9999
col algorithm       format a10
col creation_time   format a29
col encrypted       format a10
col key_id          format a35
col pdb_name        format a12
col tablespace_name format a25
col tag             format a45

prompt 
prompt . Display all the encrypted tablespaces in the DB
select a.name pdb_name, b.name tablespace_name, c.ENCRYPTIONALG algorithm 
  from v\$containers a, v\$tablespace b, v\$encrypted_tablespaces c
  where a.con_id = b.con_id
    and b.con_id = c.con_id
    and b.ts# = c.ts#;

prompt 
prompt . Create a new tablespace TEST without encryption syntax
create tablespace TEST datafile '${DATA_DIR}/test.dbf' size 15m;

prompt 
prompt . Create a table TEST in this new tablespace
create table test_objects tablespace TEST as select * from dba_objects;

prompt 
prompt . Verify that this table is correctly located on this tablespace and check if it's encrypted
select tablespace_name, encrypted from dba_tablespaces where tablespace_name = 'TEST';

prompt 
prompt . Display all the encrypted tablespaces in the DB
select a.name pdb_name, b.name tablespace_name, c.ENCRYPTIONALG algorithm 
  from v\$containers a, v\$tablespace b, v\$encrypted_tablespaces c
  where a.con_id = b.con_id
    and b.con_id = c.con_id
    and b.ts# = c.ts#;

prompt 
prompt . Display the keys in the DB
select a.name pdb_name, b.key_id, substr(b.CREATION_TIME,1,29) creation_time, b.tag
  from v\$containers a, v\$encryption_keys b
  where a.con_id = b.con_id;

prompt
prompt . View the output of strings against test.dbf data file
!ls -al ${DATA_DIR}/test.dbf
!strings ${DATA_DIR}/test.dbf | head -20

prompt
prompt . Drop the tablespace TEST
drop tablespace TEST including contents and datafiles;

exit;
EOF

echo
