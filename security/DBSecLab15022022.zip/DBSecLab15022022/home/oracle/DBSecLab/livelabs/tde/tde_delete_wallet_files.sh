#!/bin/bash

# =========================================================================================
# Script Name : tde_delete_wallet_files.sh
#
# Parameter   : None
#
# Notes       : Delete the associated wallet files
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Clean up the wallet..."
echo "==================================================================================="

echo
echo ". List the files in the Wallet directory before deleting"
find ${WALLET_DIR}

echo
echo ". Delete the files"
rm -rf ${WALLET_DIR}/*

echo
echo ". and now after deleting:"
find ${WALLET_DIR}

echo
