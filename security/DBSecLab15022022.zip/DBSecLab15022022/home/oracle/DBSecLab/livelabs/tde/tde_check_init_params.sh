#!/bin/bash

# =========================================================================================
# Script Name : tde_check_init_params.sh
#
# Parameter   : None
#
# Notes       : View the TDE initialization parameters
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " View TDE-related init parameters..."
echo "==================================================================================="

sqlplus -s / as sysdba <<EOF

set lines 110
set pages 999
col name  format a40
col value format a40

prompt
prompt . View TDE-related init parameters
select name, value 
  from v\$parameter
 where name in ('encrypt_new_tablespaces'
               ,'tde_configuration'
               ,'external_keystore_credential_location'
               ,'wallet_root'
               ,'one_step_plugin_for_pdb_with_tde');

exit;
EOF

echo
