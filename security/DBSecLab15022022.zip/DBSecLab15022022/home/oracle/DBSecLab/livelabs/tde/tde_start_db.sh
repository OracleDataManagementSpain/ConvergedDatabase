#!/bin/bash

# =========================================================================================
# Script Name : tde_start_db.sh
#
# Parameter   : None
#
# Notes       : Restart the database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Restart the database..."
echo "==================================================================================="

sqlplus -s / as sysdba <<EOF

prompt
prompt . Restart the DB
startup;
show pdbs

exit;
EOF

echo
