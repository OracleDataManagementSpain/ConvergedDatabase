#!/bin/bash

# =========================================================================================
# Script Name : tde_restore_init_parameters.sh
#
# Parameter   : None
#
# Notes       : Restore the pfile
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Restore the init parameters before restoring the DB..."
echo "==================================================================================="

sqlplus -s / as sysdba <<EOF

prompt
prompt . Shudown the DB
shutdown immediate

prompt
prompt . Create SPFILE from PFILE
create spfile from pfile='$ORACLE_HOME/dbs/pfile_pre-tde.ora';

exit;
EOF

echo
