#!/bin/bash

# =========================================================================================
# Script Name : tde_decrypt_tbs.sh
#
# Parameter   : None
#
# Notes       : Decrypt the tablespace EMPDATA_PROD
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Decrypt the tablespace EMPDATA_PROD..."
echo "==================================================================================="

WALLET_FILE=$WALLET_DIR/tde/ewallet.p12

if [ ! -f ${WALLET_FILE} ]; then

 echo
 echo " !!! ERROR !!!"
 echo " You do not have a software keystore!"
 echo " This means one of the following have happened: "
 echo "  - You did not follow the steps to create the keystore and master key"
 echo "  - You have migrated to an Online Master Key and deleted the wallet, so these steps must be performed differently"
 echo "  - You deleted the ewallet.p12 file and the DB no longer has access to it"
 echo
 exit 1
fi

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col algorithm       format a10
col encrypted       format a10
col file_name       format a45
col pdb_name        format a20
col online_status   format a15
col tablespace_name format a30

prompt
prompt . Check if the tablespace EMPDATA_PROD is encrypted or not
select tablespace_name, encrypted from dba_tablespaces where tablespace_name = 'EMPDATA_PROD';

prompt
prompt . Decrypt the tablespace EMPDATA_PROD
ALTER TABLESPACE EMPDATA_PROD ENCRYPTION ONLINE DECRYPT;

prompt
prompt . Check if the tablespace EMPDATA_PROD is encrypted now
select tablespace_name, encrypted from dba_tablespaces where tablespace_name = 'EMPDATA_PROD';

prompt
prompt . Display all the encrypted tablespaces in the DB
select a.name pdb_name, b.name tablespace_name, c.ENCRYPTIONALG algorithm
  from v\$pdbs a, v\$tablespace b, v\$encrypted_tablespaces c
  where a.con_id = b.con_id
    and b.con_id = c.con_id
    and b.ts# = c.ts#;

exit;
EOF

echo
