#!/bin/bash

# =========================================================================================
# Script Name : tde_strings_data_empdataprod.sh
#
# Parameter   : None
#
# Notes       : View the datafile data of the tablespace EMPDATA_PROD
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " View the datafile data of the tablespace EMPDATA_PROD..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 110
set pages 9999
col algorithm       format a10
col encrypted       format a10
col file_name       format a45
col pdb_name        format a20
col online_status   format a15
col tablespace_name format a30

prompt
prompt . Search the datafile path of the tablespaces EMPDATA_PROD
select file_name, online_status from dba_data_files where tablespace_name = 'EMPDATA_PROD';

exit;
EOF

echo
echo ". View the datafile content directly through the OS file"
echo "  ----------------"
echo "  Note:"
echo "  To view the datafile content directly through the OS file, we use the command:"
echo "  $ strings ${DATA_DIR}/${PDB_NAME}/empdata_prod.dbf | tail -40"
echo "  ----------------"
echo
echo "[...]"
strings ${DATA_DIR}/${PDB_NAME}/empdata_prod.dbf | tail -40

echo
