#!/bin/bash

# =========================================================================================
# Script Name : tde_create_wallet.sh
#
# Parameter   : None
#
# Notes       : Create the software keystore (Oracle Wallet) for the container database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the software keystore (Oracle Wallet)..."
echo "==================================================================================="

sqlplus -s / as sysdba <<EOF

set lines 130
set pages 9999
col wrl_type        format a12
col wrl_parameter   format a36
col activation_time format a36
col key_use         format a14
col tag             format a36
col name            format a10
col wallet_type     format a12

prompt
prompt . Display the status of the Keystore
select a.con_id, b.name, a.wrl_type, a.wrl_parameter, a.status, a.wallet_type from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.con_id;

prompt
prompt . Create the Keystore for CDB
administer key management create keystore identified by ${DBUSR_PWD};

prompt
prompt . Create the Keystore for all PDBs
administer key management set keystore open identified by ${DBUSR_PWD} container=all;

prompt
prompt . Display the status of the Keystore
select a.con_id, b.name, a.wrl_type, a.wrl_parameter, a.status, a.wallet_type from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.con_id;

exit;
EOF

echo
