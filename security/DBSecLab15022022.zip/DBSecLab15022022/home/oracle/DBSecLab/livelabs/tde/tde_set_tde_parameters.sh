#!/bin/bash

# =========================================================================================
# Script Name : tde_set_tde_parameters.sh
#
# Parameter   : None
#
# Notes       : Use the TDE parameters to locate the Wallet directory instead of sqlnet.ora
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Use the TDE parameters to locate the Wallet directory instead of sqlnet.ora..."
echo "==================================================================================="

if [[ -z $WALLET_DIR ]]; then

 echo
 echo "==================================================================================="
 echo " The WALLET_DIR variable is empty, so your profile is not setup properly!          "
 echo
 echo " Please, exit and execute 'sudo su - oracle' again to resource the env variables   "
 echo "==================================================================================="
 echo
 exit 1
fi

HAS_WALLET_ENTRY=`grep ENCRYPTION_WALLET_LOCATION ${ORACLE_HOME}/network/admin/sqlnet.ora | wc -l`

if [ $HAS_WALLET_ENTRY -gt 0 ]; then
 
 echo 
 echo ". Copy the old sqlnet.ora"
 cp ${ORACLE_HOME}/network/admin/sqlnet.ora ${ORACLE_HOME}/network/admin/sqlnet.ora.has_wallet_location

 echo 
 echo ". Modify the new one correctly by deleting wrong lines"
 sed -i '/ENCRYPTION_WALLET_LOCATION/d' ${ORACLE_HOME}/network/admin/sqlnet.ora
 sed -i '/METHOD_DATA/d' ${ORACLE_HOME}/network/admin/sqlnet.ora
 sed -i '/\DIRECTORY\=/d' ${ORACLE_HOME}/network/admin/sqlnet.ora

 echo 
 echo ". Let's view the new sqlnet.ora now"
 cat ${ORACLE_HOME}/network/admin/sqlnet.ora

fi

sqlplus -s / as sysdba <<EOF

prompt
prompt . Set "wallet_root" parameter as "${WALLET_DIR}"
alter system set wallet_root = '${WALLET_DIR}' scope= spfile;

prompt
prompt . Reboot the DB
shutdown immediate;
startup;

prompt
prompt . Set the hidden parameter "_tablespace_encryption_default_algorithm" as "AES256"
alter system set "_tablespace_encryption_default_algorithm" = 'AES256' scope = both;

prompt
prompt . Set "tde_configuration" parameter as "keystore_configuration=FILE"
alter system set tde_configuration = "keystore_configuration=FILE" scope=BOTH;

prompt
prompt . Show the modified parameters
show parameter wallet_root;
show parameter tde_configuration;

exit;
EOF

echo
