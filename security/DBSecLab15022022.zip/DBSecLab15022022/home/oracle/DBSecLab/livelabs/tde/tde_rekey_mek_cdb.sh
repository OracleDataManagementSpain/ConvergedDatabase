#!/bin/bash

# =========================================================================================
# Script Name : tde_rekey_mek_cdb.sh
#
# Parameter   : None
#
# Notes       : Rekey the TDE Master Key for the container database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Rekey the master key for the container database..."
echo "==================================================================================="

CURDATE="`date +%Y%m%d_%H%M`"
TAG_DATA="CDB1: Master Key rekey on ${CURDATE}"
echo $TAG_DATA

sqlplus -s / as sysdba <<EOF

show con_name;

set lines 140
set pages 9999
col wrl_type format a12
col wrl_parameter format a40
col activation_time format a36
col key_id format a36
col tag format a52
col pdb_name format a10

prompt 
prompt . Show the keystore
select a.con_id, b.name pdb_name, a.wrl_type, a.wrl_parameter, a.status from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.con_id;

prompt 
prompt . Show the keys before rekeying
select b.name pdb_name, a.key_id, a.activation_time, a.tag from v\$encryption_keys a, v\$containers b where a.con_id=b.con_id order by a.con_id, a.activation_time;

prompt 
prompt . Rekey the CDB key
ADMINISTER KEY MANAGEMENT SET KEY USING TAG '${TAG_DATA}' FORCE KEYSTORE IDENTIFIED BY ${DBUSR_PWD} WITH BACKUP container=current;

prompt 
prompt . Show the keys after rekeying
select b.name pdb_name, a.key_id, a.activation_time, a.tag from v\$encryption_keys a, v\$containers b where a.con_id=b.con_id order by a.con_id, a.activation_time;

exit;
EOF

echo
