#!/bin/bash

# =========================================================================================
# Script Name : tde_create_mek_pdb.sh
#
# Parameter   : $1   PDB_NAME
#
# Notes       : Create the Master Key (MEK) for the pluggable database
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           24/06/2020      Creation
# HLO           10/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the master key for the pluggable database ${pdbname} ..."
echo "==================================================================================="

if [ -z "$1" ]; then
 echo
 echo "ERROR: You did not include a PDB name for Master Key creation!"
 echo
 exit 1
else
 pdbname=$1
fi

sqlplus -s / as sysdba <<EOF

set lines 110
set pages 9999
col wrl_type        format a12
col wrl_parameter   format a40
col activation_time format a36
col key_use         format a14
col tag             format a36
col name            format a10

alter session set container=${pdbname};
show con_name;

prompt
prompt . Show the status of the current Master Key (MEK) 
select a.con_id, b.name, a.wrl_type, a.wrl_parameter, a.status from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.con_id;

prompt
prompt . Creaate the PDB Master Key (MEK)
ADMINISTER KEY MANAGEMENT SET KEY USING TAG '${pdbname}: Initial Master Key' IDENTIFIED BY ${DBUSR_PWD} WITH BACKUP container=current;

prompt
prompt . Show the status of the current Master Key (MEK) 
select a.con_id, b.name, a.wrl_type, a.wrl_parameter, a.status from v\$encryption_wallet a, v\$containers b where a.con_id=b.con_id order by a.con_id;

exit;
EOF

echo
