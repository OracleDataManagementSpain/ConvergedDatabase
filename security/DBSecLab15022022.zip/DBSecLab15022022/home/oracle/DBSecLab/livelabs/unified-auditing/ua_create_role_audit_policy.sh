#!/bin/bash

# =========================================================================================
# Script Name : ua_create_role_audit_policy.sh
#
# Parameter   : None
#
# Notes       : Create the audit policy to audit the use of the role MGR_ROLE
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# HLO           18/10/2021      Updates for Livelabs-v4
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the audit policy to audit the use of the role MGR_ROLE..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user

prompt
prompt . Create the Audit policy "AUD_ROLE_POL" on role "MGR_ROLE"
create audit policy aud_role_pol ROLES mgr_role;

exit;
EOF

echo
