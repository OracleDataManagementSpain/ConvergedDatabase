#!/bin/bash

# =========================================================================================
# Script Name : ua_datapump_export_hr_table.sh
#
# Parameter   : None
#
# Notes       : Export the table EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Export the table EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES..."
echo "==================================================================================="

export current_dir=`pwd`

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba <<EOF

prompt
prompt . Create a DB Directory and grant read,write to SYSTEM
create or replace directory DATA_FILE_DIR as '${current_dir}';

prompt
prompt . Grant R/W privilege on this directory to "SYSTEM"
grant read,write on directory DATA_FILE_DIR to system;

exit;
EOF

echo
echo ". Perform a Data Pump Export as a user authorized (SYSTEM)"
echo "$ expdp ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} dumpfile=HR_table.dmp DIRECTORY=DATA_FILE_DIR tables=EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES reuse_dumpfiles=y"
expdp ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} dumpfile=HR_table.dmp DIRECTORY=DATA_FILE_DIR tables=EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES reuse_dumpfiles=y

echo
echo ". Attempt a Data Pump Export as a user who is not authorized (DBSAT_ADMIN)..."
echo "$ expdp dbsat_admin/${DBUSR_PWD}@${PDB_NAME} dumpfile=steal_data DIRECTORY=DATA_FILE_DIR tables=EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES reuse_dumpfiles=y"
expdp dbsat_admin/${DBUSR_PWD}@${PDB_NAME} dumpfile=steal_data DIRECTORY=DATA_FILE_DIR tables=EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES reuse_dumpfiles=y

echo
