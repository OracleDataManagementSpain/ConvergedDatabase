#!/bin/bash

# =========================================================================================
# Script Name : ua_current_audit_settings.sh
#
# Parameter   : $1   PDB_NAME
#
# Notes       : Display the audit settings
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Display the audit settings..."
echo "==================================================================================="

if [ -z $1 ]; then
  pdb_name=${PDB_NAME}
else
  pdb_name=${1}
fi

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${pdb_name} as sysdba << EOF

set echo on
set pages 9999
set lines 120
col policy_name       format A40
col enabled_policies  format A40
col audit_option      format A40
col parameter         format a50
col value             format a40
col namespace         format a35
col attribute         format a35
col user_name         format a25

show user
show con_name

prompt
prompt . Check if pure Unified Auditing is enabled
select parameter, value from v\$option where PARAMETER = 'Unified Auditing';
select policy_name, count(*) audited_attributes from audit_unified_policies group by policy_name order by policy_name;
select POLICY_NAME as ENABLED_POLICIES from AUDIT_UNIFIED_ENABLED_POLICIES order by 1; 
select NAMESPACE, ATTRIBUTE, USER_NAME from AUDIT_UNIFIED_CONTEXTS order by 1,2,3;

exit;
EOF

echo
