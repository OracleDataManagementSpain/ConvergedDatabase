#!/bin/bash

# =========================================================================================
# Script Name : ua_dbms_audit_mgmt_settings.sh
#
# Parameter   : $1   PDB_NAME
#
# Notes       : Shows some of the details of the DBMS_AUDIT_MGMT package
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Shows some of the details of the DBMS_AUDIT_MGMT package..."
echo "==================================================================================="

if [ -z $1 ]; then
  pdb_name=${PDB_NAME}
else
  pdb_name=${1}
fi

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${pdb_name} as sysdba << EOF

set pages 9999
set lines 120
set echo on
set serveroutput on
col POLICY_NAME       format A40
col ENABLED_POLICIES  format A40
col AUDIT_OPTION      format A40
col parameter         format a50
col value             format a40
col namespace         format a35
col attribute         format a35
col user_name         format a25
col partition_name    format a20
col tablespace_name   format a20
col high_value format a60

show user
show con_name

prompt
prompt . Show "AUD$UNIFIED"
select partition_name, tablespace_name, high_value from dba_tab_partitions where table_name = 'AUD\$UNIFIED';

prompt
prompt . Commit the Unified Audit Trail
select DBMS_AUDIT_MGMT.GET_AUDIT_COMMIT_DELAY from dual;


prompt
prompt . Get the last Unified Audit Trail
DECLARE
 LAT_TS TIMESTAMP;
BEGIN
 LAT_TS := DBMS_AUDIT_MGMT.GET_LAST_ARCHIVE_TIMESTAMP(
      audit_trail_type          => DBMS_AUDIT_MGMT.AUDIT_TRAIL_OS);
 IF LAT_TS is not NULL THEN
  DBMS_OUTPUT.PUT_LINE('The Last Archive Timestamp is: ' || to_char(LAT_TS));
 ELSE 
  DBMS_OUTPUT.PUT_LINE('No reults because the SET_LAST_ARCHIVE_TIMESTAMP Procedure is available only on a READ ONLY database.');
 END IF;
END;
/

prompt
prompt . Set Unified Audit Trail property
DECLARE
 OS_MAX_AGE_VAL NUMBER;
BEGIN
 OS_MAX_AGE_VAL := DBMS_AUDIT_MGMT.GET_AUDIT_TRAIL_PROPERTY_VALUE(
      audit_trail_type          => DBMS_AUDIT_MGMT.AUDIT_TRAIL_OS,
      audit_trail_property      => DBMS_AUDIT_MGMT. OS_FILE_MAX_AGE);
 IF OS_MAX_AGE_VAL is not NULL THEN
  DBMS_OUTPUT.PUT_LINE('The Maximum Age configured for OS Audit files is: ' ||
                       OS_MAX_AGE_VAL);
 END IF;
END;
/

exit;
EOF

echo
