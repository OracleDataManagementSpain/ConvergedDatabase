#!/bin/bash

# =========================================================================================
# Script Name : ua_query_employeesearch_usage.sh
#
# Parameter   : None
#
# Notes       : Identify who is using the EMPLOYEESEARCH_PROD objects outside of the app
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Identify who is using the EMPLOYEESEARCH_PROD objects outside of the app..."
echo "==================================================================================="
echo
echo " You will use the Glassfish application for this script:"
echo " - Open your browser to http://${PUBLIC_IP}:8080/hr_prod_${PDB_NAME}"
echo " - Login as hradmin/Oracle123 and search the employee data at random"
echo "==================================================================================="

if [ `ps -ef | grep $GLASSFISH_HOME | grep -v grep | wc -l` -eq 0 ]; then
 echo 
 echo "WARNING: Glassfish is not starting so we will start it for you..."
 $DBSEC_ADMIN/start_Glassfish.sh
fi

echo
read -p "Press [return] when you have done so"
echo

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

set trimspool on
set echo on
set termout on
set lines 120
set pages 999
set feedback on
col osuser format a18
col machine format a55
col module format a35

show con_name;
show user;

prompt
prompt . List the session for the user "EMPLOYEESEARCH_PROD"
SELECT osuser, machine, module FROM v\$session WHERE username = 'EMPLOYEESEARCH_PROD';

exit;
EOF

echo
