#!/bin/bash

# =========================================================================================
# Script Name : ua_delete_audit_policy.sh
#
# Parameter   : None
#
# Notes       : Remove the Unified Audit Policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Remove the Unified Audit Policy..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba <<EOF

show con_name;
show user;

prompt
prompt . Disable the Audit policy "AUDIT_EMPLOYEESEARCH_USAGE"
NOAUDIT POLICY AUDIT_EMPLOYEESEARCH_USAGE;

prompt
prompt . Delete the Audit policy "AUDIT_EMPLOYEESEARCH_USAGE"
DROP AUDIT POLICY AUDIT_EMPLOYEESEARCH_USAGE;

prompt
prompt . Purge Unified Audit policy records generated
EXEC dbms_audit_mgmt.clean_audit_trail(audit_trail_type=>dbms_audit_mgmt.audit_trail_unified,use_last_arch_timestamp=>FALSE);

exit;
EOF

echo
