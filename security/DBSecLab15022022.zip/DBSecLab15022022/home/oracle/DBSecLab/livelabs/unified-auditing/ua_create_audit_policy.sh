#!/bin/bash

# =========================================================================================
# Script Name : ua_create_audit_policy.sh
#
# Parameter   : None
#
# Notes       : Create the Unified Audit Policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the Unified Audit Policy..."
echo "==================================================================================="

FQDN_HOST=`hostname --fqdn`

echo
echo ". We must update the script to have the fully-qualified hostname for your VM"
echo "  Your machine is: ${FQDN_HOST}"
echo
echo ". The default rule looks like this:"
echo "SYS_CONTEXT('USERENV','SESSION_USER') = 'EMPLOYEESEARCH_PROD'
AND (SYS_CONTEXT('USERENV','OS_USER') != 'oracle'
OR SYS_CONTEXT('USERENV','MODULE') != 'JDBC Thin Client'
OR SYS_CONTEXT('USERENV','HOST') != 'dbsec-lab.dbsecvcn.oraclevcn.com')"

RULE_EXPR="'SYS_CONTEXT(''USERENV'',''SESSION_USER'') = ''EMPLOYEESEARCH_PROD'' AND (SYS_CONTEXT(''USERENV'',''OS_USER'') != ''oracle'' OR SYS_CONTEXT(''USERENV'',''MODULE'') != ''JDBC Thin Client'' OR SYS_CONTEXT(''USERENV'',''HOST'') != ''${FQDN_HOST}'')'"

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba <<EOF

set serveroutput on;
set echo on;
set lines 140
set pages 9999
col audit_option        format A18
col object_schema       format A21
col object_name         format A20
col condition_eval_opt  format a20

show con_name
show user

prompt
prompt . Be sure the Audit policy "AUDIT_EMPLOYEESEARCH_USAGE" doesn't exist before creating it
BEGIN
 EXECUTE IMMEDIATE 'NOAUDIT POLICY AUDIT_EMPLOYEESEARCH_USAGE';
EXCEPTION
 WHEN OTHERS THEN
  NULL;
END;
/

BEGIN
 EXECUTE IMMEDIATE 'DROP AUDIT POLICY AUDIT_EMPLOYEESEARCH_USAGE';
EXCEPTION
 WHEN OTHERS THEN
  NULL;
END;
/

prompt
prompt . Create the Audit policy "AUDIT_EMPLOYEESEARCH_USAGE"
CREATE AUDIT POLICY AUDIT_EMPLOYEESEARCH_USAGE
  ACTIONS ALL ON EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES
        , ALL ON EMPLOYEESEARCH_PROD.DEMO_HR_USERS
  WHEN ${RULE_EXPR}
 EVALUATE PER STATEMENT;

prompt
prompt . Display the info of the Audit policy "AUDIT_EMPLOYEESEARCH_USAGE"
select OBJECT_SCHEMA, OBJECT_NAME, OBJECT_TYPE, AUDIT_OPTION, CONDITION_EVAL_OPT, AUDIT_CONDITION from AUDIT_UNIFIED_POLICIES where POLICY_NAME = 'AUDIT_EMPLOYEESEARCH_USAGE';

exit;
EOF

echo
