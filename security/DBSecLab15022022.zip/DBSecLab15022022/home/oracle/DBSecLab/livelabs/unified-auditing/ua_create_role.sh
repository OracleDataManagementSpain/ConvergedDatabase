#!/bin/bash

# =========================================================================================
# Script Name : ua_create_role.sh
#
# Parameter   : None
#
# Notes       : Create role MGR_ROLE
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create role MGR_ROLE..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user;

prompt
prompt . Create the role "MGR_ROLE"
create role MGR_ROLE;

prompt
prompt . Grant privileges to "MGR_ROLE"
grant create tablespace to MGR_ROLE;

prompt
prompt . Grant "MGR_ROLE" and "create session" to "${DBUSR_DBA3}" user
grant MGR_ROLE, create session to ${DBUSR_DBA3};

exit;
EOF

echo
