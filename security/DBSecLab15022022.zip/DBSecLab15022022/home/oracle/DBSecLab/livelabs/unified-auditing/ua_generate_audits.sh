#!/bin/bash

# =========================================================================================
# Script Name : ua_generate_audits.sh
#
# Parameter   : None
#
# Notes       : Execute SQL statements that will show up in the Unified Audit Trail
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Execute SQL statements that will show up in the Unified Audit Trail..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user

prompt
prompt . Create the tablespace "TEST"
create tablespace test datafile '${DATA_DIR}/${PDB_NAME}/test01.dbf' size 10m;

prompt
prompt . Drop the tablespace "TEST"
drop tablespace test including contents and datafiles;

prompt
prompt . Alter system parameters as ${DBUSR_DBA4} user
connect ${DBUSR_DBA4}/${DBUSR_PWD}@${PDB_NAME}
alter system set job_queue_processes=200;
alter system set job_queue_processes=100;

prompt
prompt . Flush Unified Audit Trail as SYS
connect ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba
exec SYS.DBMS_AUDIT_MGMT.FLUSH_UNIFIED_AUDIT_TRAIL;

exit;
EOF

echo
