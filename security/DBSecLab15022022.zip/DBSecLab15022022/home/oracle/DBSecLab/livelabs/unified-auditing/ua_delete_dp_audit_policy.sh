#!/bin/bash

# =========================================================================================
# Script Name : ua_delete_dp_audit_policy.sh
#
# Parameter   : None
#
# Notes       : Remove the DataPump Unified Auditing policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/10/2021      Creation
# =========================================================================================

echo
echo "==================================================================================="
echo " Remove the DataPump Unified Auditing policy..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user;

prompt
prompt . Disable the Audit policy "DP_POL"
noaudit policy DP_POL;

prompt
prompt . Delete the Audit policy "DP_POL"
drop audit policy DP_POL;

prompt
prompt . Purge Unified Audit policy records generated
EXEC dbms_audit_mgmt.clean_audit_trail(audit_trail_type=>dbms_audit_mgmt.audit_trail_unified,use_last_arch_timestamp=>FALSE);

exit;
EOF

echo
echo ". Drop DataPump export generated"
rm export.log HR_table.dmp

echo
