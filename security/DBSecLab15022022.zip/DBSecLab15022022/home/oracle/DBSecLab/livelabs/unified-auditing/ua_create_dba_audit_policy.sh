#!/bin/bash

# =========================================================================================
# Script Name : ua_create_dba_audit_policy.sh
#
# Parameter   : None
#
# Notes       : Create the policy associated with auditing the use of the DBA role
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# HLO           18/10/2021      Updates for Livelabs-v4
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the policy associated with auditing the use of the DBA role..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user

prompt
prompt . Create the Audit policy "AUD_DBA_POL" on role "DBA"
create audit policy aud_dba_pol ROLES dba;

exit;
EOF

echo
