#!/bin/bash

# =========================================================================================
# Script Name : ua_query_existing_audit_records.sh
#
# Parameter   : $1   PDB_NAME
#
# Notes       : Display the existing audit records for the database you connect to
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Display the existing audit records for the pluggable database..."
echo "==================================================================================="

if [ -z $1 ]; then
  pdbname=${PDB_NAME}
else
  pdbname=${1}
fi

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${pdbname} as sysdba << EOF

set echo on
set pages 9999
set lines 120
col oldest_audit_record format a40
col newest_audit_record format a40
col action_name         format a40

prompt
prompt . View Audit Data for ${pdbname}
select min(event_timestamp) oldest_audit_record, max(event_timestamp) newest_audit_record from unified_audit_trail;
select count(*) total_unified_audit_records from unified_audit_trail;
select action_name, count(*) from unified_audit_trail group by action_name order by action_name;

exit;
EOF

echo
