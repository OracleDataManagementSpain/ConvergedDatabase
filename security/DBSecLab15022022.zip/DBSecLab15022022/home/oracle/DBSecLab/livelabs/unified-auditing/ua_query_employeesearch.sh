#!/bin/bash

# =========================================================================================
# Script Name : ua_query_employeesearch.sh
#
# Parameter   : None
#
# Notes       : Generate SQL traffic from SQL*Plus
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Generate SQL traffic from SQL*Plus..."
echo "==================================================================================="

sqlplus -s ${DBUSR_EMPPROD}/${DBUSR_PWD}@${PDB_NAME} << EOF

set lines 180
set pages 999
set echo on
set serveroutput on
set trimspool on;
set termout on
col firstname format a10
col lastname format a10
col emptype format a9
col position format a16
col ssn format a11
col sin format a11
col nino format a13

show con_name
show user;

prompt
prompt . Describe "EMPLOYEESEARCH_PROD.DEMO_HR_EMPLOYEES" table
DESC employeesearch_prod.demo_hr_employees;


prompt
prompt . List sample data of the table
select userid, firstname, lastname, emptype, position, ssn, sin, nino
  from employeesearch_prod.demo_hr_employees
 where rownum < 10;

exit;
EOF

echo
