#!/bin/bash

# =========================================================================================
# Script Name : ua_review_generated_audits.sh
#
# Parameter   : None
#
# Notes       : View the Unified Audit Trail output associated with the two audit policies
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " View the Unified Audit Trail output associated with the two audit policies..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

set echo on
set lines 180
set pages 9999
col action_name            format a20
col unified_audit_policies format a30
col object_name            format a20
col object_schema          format a10
col audit_type             format a15
col dbusername             format a10
col audit_option           format a30

show con_name
show user

prompt
prompt . View Unified Audit data
select action_name, dbusername, action_name, OBJECT_SCHEMA, object_name, SQL_TEXT 
  from unified_audit_trail 
 where unified_audit_policies like '%AUD_DBA_POL%'
    or unified_audit_policies like '%AUD_ROLE_POL%'
 order by event_timestamp desc;

exit;
EOF

echo
