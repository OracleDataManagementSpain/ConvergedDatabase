#!/bin/bash

# =========================================================================================
# Script Name : ua_delete_role_audit_policy.sh
#
# Parameter   : None
#
# Notes       : Remove the role usage Unified Audit policies
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/10/2021      Creation
# =========================================================================================

echo
echo "==================================================================================="
echo " Remove the role usage Unified Audit Policy..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user;

prompt
prompt . Disable the Audit policy "AUD_ROLE_POL"
noaudit policy aud_role_pol;

prompt
prompt . Disable the Audit policy "AUD_DBA_POL"
noaudit policy aud_dba_pol;

prompt
prompt . Delete the Audit policy "AUD_ROLE_POL"
drop audit policy aud_role_pol;

prompt
prompt . Delete the Audit policy "AUD_DBA_POL"
drop audit policy aud_dba_pol;

prompt
prompt . Drop the user "${DBUSR_DBA4}"
drop user ${DBUSR_DBA4} cascade;

prompt
prompt . Drop the role "MGR_ROLE"
drop role MGR_ROLE;

prompt
prompt . Purge Unified Audit policy records generated
EXEC dbms_audit_mgmt.clean_audit_trail(audit_trail_type=>dbms_audit_mgmt.audit_trail_unified,use_last_arch_timestamp=>FALSE);

exit;
EOF

echo
