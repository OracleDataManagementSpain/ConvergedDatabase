#!/bin/bash

# =========================================================================================
# Script Name : ua_enable_audit_policy.sh
#
# Parameter   : None
#
# Notes       : Enable the Unified Audit Policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Enable the Unified Audit Policy..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba<<EOF

set serveroutput on;
set echo on;
set lines 140
set pages 9999
col policy_name     format A38
col entity_name     format A22
col entity_type     format a12
col enabled_option  format a20

prompt
prompt . Enable Audit policy "audit_employeesearch_usage"
audit policy audit_employeesearch_usage;


prompt
prompt . List the enabled Audit policies
select POLICY_NAME, ENABLED_OPTION, ENTITY_NAME, ENTITY_TYPE, SUCCESS, FAILURE from AUDIT_UNIFIED_ENABLED_POLICIES order by policy_name;

exit;
EOF

echo
