#!/bin/bash

# =========================================================================================
# Script Name : ua_query_audit_records.sh
#
# Parameter   : None
#
# Notes       : View the Unified Audit records generated
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " View the Unified Audit records generated..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba<<EOF

show con_name
show user;

set serveroutput on;
set echo on;
set lines 140
set pages 9999
col event_timestamp format a31
col os_username format a12
col userhost format a20
col dbusername format a20
col client_program_name format a33
col action_name format a12
col object_schema format a20
col object_name format a20
col sql_text format a50 word_wrapped

prompt 
prompt . List the Unified Audit of the Audit policy "AUDIT_EMPLOYEESEARCH_USAGE"
select event_timestamp, os_username, userhost, dbusername, client_program_name, action_name, return_code, object_schema, object_name, sql_text 
  from unified_audit_trail 
 where UNIFIED_AUDIT_POLICIES like '%AUDIT_EMPLOYEESEARCH_USAGE%'
 order by 1;

exit;
EOF

echo
