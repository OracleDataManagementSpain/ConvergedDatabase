#!/bin/bash

# =========================================================================================
# Script Name : ua_view_audit_policies.sh
#
# Parameter   : None
#
# Notes       : View the audit policies that are enabled
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " View the audit policies that are enabled..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

set lines 110
set pages 9999
col audit_option format A20
col policy_name format A38
col entity_name format A28
col entity_type format a14

show con_name
show user

prompt
prompt . Display info of the Audit policies "AUD_ROLE_POL" and "AUD_DBA_POL"
select POLICY_NAME, AUDIT_OPTION, CONDITION_EVAL_OPT from AUDIT_UNIFIED_POLICIES where POLICY_NAME in ('AUD_ROLE_POL','AUD_DBA_POL');
 
prompt
prompt . List all the Audit policies enabled
select POLICY_NAME, ENABLED_OPTION, ENTITY_NAME, ENTITY_TYPE, SUCCESS, FAILURE from AUDIT_UNIFIED_ENABLED_POLICIES order by policy_name;

exit;
EOF

echo
