#!/bin/bash

# =========================================================================================
# Script Name : ua_enable_audit_policies.sh
#
# Parameter   : None
#
# Notes       : Enable the audit policies for MGR_ROLE and DBA role usage
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Enable the audit policies for MGR_ROLE and DBA role usage..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user

prompt
prompt . Enable the Audit policy "AUD_ROLE_POL"
audit policy AUD_ROLE_POL;

prompt
prompt . Enable the Audit policy "AUD_DBA_POL"
audit policy AUD_DBA_POL;

exit;
EOF
 
echo
