#!/bin/bash

# =========================================================================================
# Script Name : ua_audit_datapump_export.sh
#
# Parameter   : None
#
# Notes       : Create a Unified Audit policy to audit Data Pump activities
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Create a Unified Audit policy to audit Data Pump activities..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

set lines 110
set pages 999
col user_name   format A10
col policy_name format A20
col entity_name format a20

show con_name
show user

prompt
prompt . What is auditable for Data Pump
SELECT name FROM auditable_system_actions WHERE component = 'Datapump';

prompt
prompt . List the current Audit policies
select * from AUDIT_UNIFIED_ENABLED_POLICIES where POLICY_NAME like '%DP%';

prompt
prompt . Create the Audit Policy "DP_POL"
create audit policy DP_POL actions component=datapump all; 

prompt
prompt . Enable the Audit policy "DP_POL"
audit policy DP_POL;

prompt
prompt . List the current Audit policies
select * from AUDIT_UNIFIED_ENABLED_POLICIES  where POLICY_NAME like '%DP%';

exit;
EOF

echo
