#!/bin/bash

# =========================================================================================
# Script Name : ua_create_junior_dba.sh
#
# Parameter   : None
#
# Notes       : Create a DBA user who will be granted the DBA role
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# HLO           18/10/2021      Updates for Livelabs-v4
# =========================================================================================

echo
echo "==================================================================================="
echo " Create the ${DBUSR_DBA4} user who will be granted the DBA role..."
echo "==================================================================================="

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba << EOF

show con_name
show user

prompt
prompt . Create user "${DBUSR_DBA4}"
create user ${DBUSR_DBA4} identified by ${DBUSR_PWD};

prompt
prompt . Grant DBA privileges to "${DBUSR_DBA4}"
grant DBA to ${DBUSR_DBA4};

exit;
EOF

echo
