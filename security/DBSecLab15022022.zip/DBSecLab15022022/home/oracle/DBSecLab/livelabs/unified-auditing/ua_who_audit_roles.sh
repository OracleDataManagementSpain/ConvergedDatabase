#!/bin/bash

# =========================================================================================
# Script Name : ua_who_audit_roles.sh
#
# Parameter   : None
#
# Notes       : Display who has the AUDIT_ADMIN and AUDIT_VIEWER roles
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# REV           16/06/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "==================================================================================="
echo " Display who has the AUDIT_ADMIN and AUDIT_VIEWER roles..."
echo "==================================================================================="

sqlplus -s / as sysdba << EOF

set pages 9999
set lines 120
set echo on
col CON_NAME        format A12
col GRANTEE         format A19
col GRANTED_ROLE    format A19
col admin_option    format a12
col delegate_option format a16
col default_role    format a14
col common          format a9
col inherited       format a9

prompt
prompt . Identify who has AUDIT_ADMIN or AUDIT_VIEWER roles
select b.name con_name, a.grantee, a.granted_role, a.admin_option, a.delegate_option, a.default_role, a.common, a.inherited
  from cdb_role_privs a, v\$containers b where a.con_id = b.con_id
   and a.granted_role in ('AUDIT_ADMIN','AUDIT_VIEWER')
 order by 1,2,3;

exit;
EOF

echo
