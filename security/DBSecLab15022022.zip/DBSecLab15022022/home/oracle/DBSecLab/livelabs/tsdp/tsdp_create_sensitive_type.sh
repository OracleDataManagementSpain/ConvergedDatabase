#!/bin/bash

# =========================================================================================
# Script Name : tsdp_create_sensitive_type.sh
#
# Parameter   : None
#
# Notes       : Create a TSDP sensitive type for all credit card numbers
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/03/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create a TSDP sensitive type for all credit card numbers..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_TSDPADMIN}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 210
set pages 999

show con_name
show user;

prompt
prompt . Create the sensitive type "credit_card_type" to classify the types of columns to protect
BEGIN
 DBMS_TSDP_MANAGE.ADD_SENSITIVE_TYPE (
  sensitive_type  => 'credit_card_type',
  user_comment    => 'Type for Credit Card columns using a Varchar2 data type');
END;
/

exit;
EOF

echo
