#!/bin/bash

# =========================================================================================
# Script Name : tsdp_add_sensitive_col.sh
#
# Parameter   : None
#
# Notes       : Identify the sensitive columns to protect
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/03/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Identify the sensitive columns to protect..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_TSDPADMIN}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 210
set pages 999

show con_name
show user;

prompt
prompt . Identify a list of sensitive columns that are associated with the sensitive types
BEGIN
 DBMS_TSDP_MANAGE.ADD_SENSITIVE_COLUMN(
 schema_name        => 'tsdp_labs',
 table_name         => 'TSDP_HR_EMPLOYEES',
 column_name        => 'CORPORATE_CARD',
 sensitive_type     => 'credit_card_type',
 user_comment       => 'Sensitive column addition of credit_card_type');
END;
/

exit;
EOF

echo
