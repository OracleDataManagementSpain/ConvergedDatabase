#!/bin/bash

# =========================================================================================
# Script Name : tsdp_create_policy.sh
#
# Parameter   : None
#
# Notes       : Create the TSDP policy
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/03/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Create the TSDP policy..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_TSDPADMIN}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 210
set pages 999

show con_name
show user;

prompt
prompt . Create the TSDP policy "redact_partial_cc" with Partial redaction
DECLARE
  redact_feature_options DBMS_TSDP_PROTECT.FEATURE_OPTIONS;
  policy_conditions DBMS_TSDP_PROTECT.POLICY_CONDITIONS;
BEGIN
  redact_feature_options ('expression') := 'SYS_CONTEXT(''USERENV'',''SESSION_USER'') =''TSDP_LABS''';
  redact_feature_options ('function_type') := 'DBMS_REDACT.PARTIAL';
  redact_feature_options ('function_parameters') := 'VVVVFVVVVFVVVVFVVVV,VVVV-VVVV-VVVV-VVVV,*,1,8';
  policy_conditions(DBMS_TSDP_PROTECT.DATATYPE) := 'VARCHAR2';
  DBMS_TSDP_PROTECT.ADD_POLICY ('redact_partial_cc', DBMS_TSDP_PROTECT.REDACT,redact_feature_options, policy_conditions);
END;
/

exit;
EOF

echo
