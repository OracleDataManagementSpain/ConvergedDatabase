#!/bin/bash

# =========================================================================================
# Script Name : tsdp_associate_policy.sh
#
# Parameter   : None
#
# Notes       : Associate the TSDP policy with a sensitive type
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/03/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Associate the TSDP policy with a sensitive type..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_TSDPADMIN}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 210
set pages 999

show con_name
show user;

prompt
prompt . Associate the TSDP policy "redact_partial_cc" with the sensitive type "credit_card_type"
BEGIN
   DBMS_TSDP_PROTECT.ASSOCIATE_POLICY(
   policy_name        => 'redact_partial_cc',
   sensitive_type     => 'credit_card_type',
   associate          => true);
  END;
/

exit;
EOF

echo
