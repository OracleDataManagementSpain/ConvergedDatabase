#!/bin/bash

# =========================================================================================
# Script Name : tsdp_reset_env.sh
#
# Parameter   : None
#
# Notes       : Reset the TSDP labs environment
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/03/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Reset the TSDP labs environment..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_TSDPADMIN}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 210
set pages 999

show con_name
show user;

prompt
prompt . Disable the TSDP policy
BEGIN
 DBMS_TSDP_PROTECT.DISABLE_PROTECTION_COLUMN(
  schema_name          => 'tsdp_labs',
  table_name           => 'TSDP_HR_EMPLOYEES',
  column_name          => '%');
END;
/

prompt
prompt . Drop the sensitive column
BEGIN
 DBMS_TSDP_MANAGE.DROP_SENSITIVE_COLUMN (
   schema_name        => 'tsdp_labs',
   table_name         => 'TSDP_HR_EMPLOYEES',
   column_name        => 'CORPORATE_CARD');
END;
/

prompt
prompt . Drop the sensitive type
BEGIN
 DBMS_TSDP_MANAGE.DROP_SENSITIVE_TYPE (
 sensitive_type     => 'credit_card_type');
END;
/

prompt
prompt . Drop the TSDP policy
BEGIN
 DBMS_TSDP_PROTECT.DROP_POLICY(
   policy_name     => 'redact_partial_cc');
END;
/

conn ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba

show user;

prompt
prompt . Drop the TSDP users (Admin and Data Owner)
drop user ${DBUSR_TSDP} cascade;
drop user ${DBUSR_TSDPADMIN} cascade;

exit;
EOF

echo
