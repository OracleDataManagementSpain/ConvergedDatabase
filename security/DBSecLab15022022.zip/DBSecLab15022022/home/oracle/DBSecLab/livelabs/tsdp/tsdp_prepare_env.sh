#!/bin/bash

# =========================================================================================
# Script Name : tsdp_prepare_env.sh
#
# Parameter   : None
#
# Notes       : Prepare the TSDP environment for the labs
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/03/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Prepare the TSDP environment for the labs..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_SYS}/${DBUSR_PWD}@${PDB_NAME} as sysdba <<EOF

set lines 210
set pages 999

show con_name
show user;

prompt
prompt . Create the TSDP Admin user
GRANT CREATE SESSION TO ${DBUSR_TSDPADMIN} IDENTIFIED BY ${DBUSR_PWD};
GRANT CREATE PROCEDURE TO ${DBUSR_TSDPADMIN};
GRANT EXECUTE ON DBMS_TSDP_MANAGE TO ${DBUSR_TSDPADMIN};
GRANT EXECUTE ON DBMS_TSDP_PROTECT TO ${DBUSR_TSDPADMIN}; 
GRANT EXECUTE ON DBMS_RLS to ${DBUSR_TSDPADMIN};
GRANT EXECUTE ON DBMS_REDACT to ${DBUSR_TSDPADMIN};

prompt
prompt . Create the TSDP data owner
GRANT CREATE SESSION, RESOURCE TO ${DBUSR_TSDP} IDENTIFIED BY ${DBUSR_PWD};
GRANT UNLIMITED TABLESPACE TO ${DBUSR_TSDP};
GRANT SELECT ON employeesearch_prod.demo_hr_employees to ${DBUSR_TSDP};

conn ${DBUSR_TSDP}/${DBUSR_PWD}@${PDB_NAME}

show user;

prompt
prompt . Create TSDP labs table
CREATE TABLE tsdp_hr_employees AS SELECT * FROM employeesearch_prod.demo_hr_employees;
COMMIT;

exit;
EOF

echo
