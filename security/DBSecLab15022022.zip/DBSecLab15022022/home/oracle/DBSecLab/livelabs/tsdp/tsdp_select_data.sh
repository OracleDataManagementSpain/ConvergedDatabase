#!/bin/bash

# =========================================================================================
# Script Name : tsdp_select_data.sh
#
# Parameter   : None
#
# Notes       : Display the sensitive data from the TSDP table
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# HLO           18/03/2021      Creation
# =========================================================================================

echo
echo "=============================================================================="	
echo " Display the sensitive data from the TSDP table..."
echo "=============================================================================="	

sqlplus -s ${DBUSR_TSDP}/${DBUSR_PWD}@${PDB_NAME} <<EOF

set lines 1000
set pages 50
col firstname       format a20
col lastname        format a30
col email           format a35
col phonemobile     format a15
col ssn             format a15
col salary          format 99999999
col corporate_card  format a25
col cc_pin          format 9999
col cc_expire       format a12

show con_name
show user;

prompt
prompt SQL> SELECT userid, firstname, lastname, corporate_card FROM tsdp_hr_employees WHERE length(corporate_card)=19 order by 1;
-- SELECT firstname, lastname, email, phonemobile, ssn, salary, corporate_card, cc_pin, cc_expire FROM tsdp_hr_employees;
SELECT userid, firstname, lastname, corporate_card FROM tsdp_hr_employees WHERE length(corporate_card)=19 order by 1;

exit;
EOF

echo
