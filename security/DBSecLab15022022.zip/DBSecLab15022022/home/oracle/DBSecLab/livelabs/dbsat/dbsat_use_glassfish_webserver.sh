#!/bin/bash

# =========================================================================================
# Script Name : dbsat_use_glassfish_webserver.sh
#
# Parameter   : None
#
# Notes       : Set Glassfish to use DBSAT
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# PLO           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# =========================================================================================

echo
echo "=============================================================================="	
echo " Set Glassfish to use DBSAT..."
echo "=============================================================================="	

echo 
echo ". Start Glassfish"
$DBSEC_ADMIN/start_Glassfish.sh

echo
echo ". Make a directory in the Glassfish HR app for the DBSAT HTML file"
mkdir -vp $GLASSFISH_HOME/hr_prod_pdb1/dbsat

echo
echo ". Copy the .html files to our new Glassfish DBSAT directory"
cp *.html $GLASSFISH_HOME/hr_prod_pdb1/dbsat

echo
echo ". Use your local browser to view it on your PUBLIC_IP at:"
for x in `ls *.html`
do 
echo "http://${PUBLIC_IP}:8080/hr_prod_pdb1/dbsat/$x"
done

echo 
