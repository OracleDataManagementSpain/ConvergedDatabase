#!/bin/bash

# =========================================================================================
# Script Name : dbsat_uninstall.sh
#
# Parameter   : None
#
# Notes       : Uninstall DBSAT
# -----------------------------------------------------------------------------------------
# Modified by   DD/MM/YYYY      Change
# PLO           22/05/2020      Creation
# HLO           04/11/2020      Updates for Livelabs-v2
# HLO           19/10/2021      Updates for Livelabs-v4 (Remove DBSAT demo user)
# =========================================================================================

echo
echo "=============================================================================="	
echo " Uninstall DBSAT..."
echo "=============================================================================="	

echo
echo ". Remove DBSAT demo SQL user"
sqlplus -s ${DBUSR_SYSTEM}/${DBUSR_PWD}@${PDB_NAME} <<EOF

drop user finacme cascade;

exit;
EOF

echo
echo ". Remove DBSAT directory from Glassfish home"
rm -Rf $GLASSFISH_HOME/hr_prod_pdb1/dbsat

echo
echo ". Remove DBSAT directory"
rm -Rf dbsat221

echo
