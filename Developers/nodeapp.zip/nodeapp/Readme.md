
Check Dockerfile for ENV variables to connect to a SODA enabled schema

 grant soda_app to user;

Create docker image

 podman build --tag nodeapp-docker-oracle .


Run it!

 podman run -it -d --name nodeapp-soda --network app-tier --ip 10.89.0.21 -p 3000:3000 nodeapp-docker-oracle

Check logs

 podman logs nodeapp-soda

Check using curl (adapt collection name and doc id)

 curl http://localhost:3000/

Remove it 
 podman stop nodeapp-soda && podman rm nodeapp-soda
