module.exports = {
  user          : process.env.NODE_ORACLEDB_USER || "po_node",
  password      : process.env.NODE_ORACLEDB_PASSWORD || "welcome1",
  connectString : process.env.NODE_ORACLEDB_CONNECTIONSTRING || "iaas21c.subnet.vcn.oraclevcn.com/oe_microserv",

  // Setting externalAuth is optional.  It defaults to false.  See:
  // https://oracle.github.io/node-oracledb/doc/api.html#extauth
  externalAuth  : process.env.NODE_ORACLEDB_EXTERNALAUTH ? true : false
};

