'use strict';

const oracledb = require('oracledb');
const dbConfig = require('./dbconfig.js');

oracledb.autoCommit = true; 

    function run(key) {
      return new Promise(async function(resolve, reject) {
        let connection, collection;

        try {
            let content, doc, res;
            connection = await oracledb.getConnection({
                user: dbConfig.user,
                password: dbConfig.password,
                connectString: dbConfig.connectString
            });


            const soda = connection.getSodaDatabase(); // Create the parent object for SODA
              collection = await soda.openCollection("purchase_orders");
              if (collection == null)
              {
                console.log('no existe la colección');
                reject("error");
              }else{

              doc = await collection.find().key(key).getOne(); // A SodaDocument
              content = doc.getContent();                      // A JavaScript object

              content = doc.getContentAsString();              // A JSON string
              resolve(content);
            }
        }
        catch (err) {
          console.error(err);
          reject("error");
        }
        finally {
          if (connection) { try { await connection.close(); }
                      catch (err) { console.error(err); }
          }
        }
});
}

module.exports = {
  run: run
};
