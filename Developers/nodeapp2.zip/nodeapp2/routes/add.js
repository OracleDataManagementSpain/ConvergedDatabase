var express = require('express');
var router = express.Router();


/* add POs */
router.get('/', function(req, res, next) {
    res.render('add', {'title':'Create PO'});
});

module.exports = router;
