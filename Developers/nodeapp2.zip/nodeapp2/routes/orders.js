var express = require('express');
var router = express.Router();
var createService = require('../createService');
var getDataService = require('../getDataService');


/* GET POs listing. */
router.get('/', function(req, res, next) {
   createService.run().then((msg) => {
     console.log("result create service: "+msg);
         getDataService.run().then((msg) => {
           res.render('orders', { title: 'Purchase Orders', userData: msg,insertedkey: "0"});
         }).catch((msg) => {
           console.log(msg)
         });
   }).catch((msg) => {
     console.log(msg);
   });


   getDataService.run().then((msg) => {

     if (req.query.key!=undefined )
     {
       console.log("viene de insert");
       res.render('orders', { title: 'Purchase Orders', userData: msg, insertedkey: req.query.key });
     }else{
       console.log("NO viene de insert");
       res.render('orders', { title: 'Purchase Orders', userData: msg, insertedkey: "0"});
     }
   }).catch((msg) => {
     console.log(msg)
   });
});

process.on('exit', function() {
    router.get('postService').closePool();
    console.log('goodbye...');
});
module.exports = router;
