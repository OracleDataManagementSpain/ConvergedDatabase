var express = require('express');
var router = express.Router();
var getDetailService = require('../getDetailService');

/* GET POs listing. */
router.get('/:id', function(req, res, next) {

  getDetailService.run(req.params.id).then((msg) => {
    //console.log("result: "+msg)
  //  res.render('orders', { title: 'Purchase Orders', userData: msg});
    res.render('detail', { title: 'Detail', id: req.params.id, msg: msg});
  }).catch((msg) => {
    console.log(msg)
  })


});


module.exports = router;
