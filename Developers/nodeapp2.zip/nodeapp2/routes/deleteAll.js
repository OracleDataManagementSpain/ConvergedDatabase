var express = require('express');
var router = express.Router();
var deleteAllService = require('../deleteAllService');

/* DELETE ALL */
router.get('/', function(req, res, next) {
   deleteAllService.run().then((msg) => {
     console.log("delete all service: "+msg);
     res.render('deleteAll', { title: 'Delete All'});
   }).catch((msg) => {
     console.log(msg);
   });
});


module.exports = router;
