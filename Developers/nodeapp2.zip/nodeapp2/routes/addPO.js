var express = require('express');
var router = express.Router();
var createPOService = require('../createPOService');

/* add POs */
router.post('/', function(req, res, next) {
      var name = req.body.customer;
      var address = req.body.address;
      console.log("name: "+name);
      console.log("address: "+address);

      createPOService.run(req.body).then((msg) => {
      //  res.render('addPO', {title:'Creating PO process'});
        res.redirect('/orders?key='+msg);
      }).catch((msg) => {
        console.log(msg)
      })

});

module.exports = router;
