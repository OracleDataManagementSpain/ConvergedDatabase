'use strict';

const oracledb = require('oracledb');
const dbConfig = require('./dbconfig.js');

oracledb.autoCommit = true; // OK for simple operations


    function run() {
return new Promise(async function(resolve, reject) {
        let connection, collection;

        try {
            let content, doc, res;
            connection = await oracledb.getConnection({
                user: dbConfig.user,
                password: dbConfig.password,
                connectString: dbConfig.connectString
            });

            if (oracledb.oracleClientVersion < 1803000000) {
              throw new Error('node-oracledb SODA requires Oracle Client libraries 18.3 or greater');
            }

            if (connection.oracleServerVersion < 1803000000) {
              throw new Error('node-oracledb SODA requires Oracle Database 18.3 or greater');
            }
            const soda = connection.getSodaDatabase(); // Create the parent object for SODA
            // Create a new SODA collection and index
              // This will open an existing collection, if the name is already in use.
              collection = await soda.openCollection(dbConfig.collection);
              if (collection == null)
              {
                console.log('no existe la colección');
                return "";
              }else{
                console.log('YA existe la colección');
                // Find all documents with city names starting with 'S'
              /*  console.log('Cities starting with S');
                const documents = await collection.find()
                  .filter({"address.city": {"$like": "S%"}})
                  .getDocuments();

                for (let i = 0; i < documents.length; i++) {
                  content = documents[i].getContent();
                  console.log('  city is: ', content.address.city);
                }
    */
                // Count all documents
                res = await collection.find().count();
                console.log('Get Service @Collection has ' + res.count + ' documents');

                // Remove documents with cities containing 'o'
              /*  console.log('Removing documents');
                res = await collection.find().filter({"address.city": {"$regex": ".*o.*"}}).remove();
                console.log('Dropped ' + res.count + ' documents');*/



              // Fetch the document back
              let filter = {
               "$query": {},
               "$orderby": [
                   {
                       "path": "id",
                       "order": "desc",
                   }
               ]
           };
           let posts = await collection.find().filter(filter).getDocuments();
           var result=[];
           posts.forEach(function(element) {
               result.push( {
                   id: element.key,
                   document: element.getContentAsString(),
               } );
              // console.log(element.key);
              // console.log(element.getContent());
           });
          // console.log(result);
            /*  doc = await collection.find().key(key).getOne(); // A SodaDocument
              content = doc.getContent();                      // A JavaScript object
              console.log('Retrieved SODA document as an object:');
              console.log(content);
              content = doc.getContentAsString();              // A JSON string
              console.log('Retrieved SODA document as a string:');
              console.log(content);*/

        /*      // Replace document contents
              content = {name: "Matilda", address: {city: "Sydney"}};
              await collection.find().key(key).replaceOne(content);
    */
              // Count all documents
            /*  res = await collection.find().count();
              console.log('Collection has ' + res.count + ' documents');*/
              resolve(result);
               //return result;
            }
        }
        catch (err) {
          console.error(err);
          reject("error");
        }
        finally {
          /*if (collection) {
            // Drop the collection
            let res = await collection.drop();
            if (res.dropped) {
              console.log('Collection was dropped');
            }
          }*/
          if (connection) { try { await connection.close(); }
                      catch (err) { console.error(err); }
          }
        }

});
}

// Exporting check function
module.exports = {
  run: run
};
