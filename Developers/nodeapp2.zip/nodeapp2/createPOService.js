'use strict';

const oracledb = require('oracledb');
const dbConfig = require('./dbconfig.js');

oracledb.autoCommit = true;
    function run(parameters) {
return new Promise(async function(resolve, reject) {
        let connection, collection;

        try {
            let content, doc, res;
            connection = await oracledb.getConnection({
                user: dbConfig.user,
                password: dbConfig.password,
                connectString: dbConfig.connectString
            });


            const soda = connection.getSodaDatabase(); // Create the parent object for SODA
            collection = await soda.openCollection("purchase_orders");
              if (collection == null)
              {
                console.log('no existe la colección');
                reject("error");
              }else{
                let ts = Date.now();
                let date_ob = new Date(ts);
                let date = date_ob.getDate();
                let month = date_ob.getMonth() + 1;
                let year = date_ob.getFullYear();
                let fecha=date + "/" + month + "/" + year;
                console.log(fecha);
                console.log("parameters: "+JSON.stringify(parameters));
                content = {customer: parameters.customer, date:fecha, address:parameters.address, price:parameters.price, status:"pending", order_lines: [{name: parameters.itemname,quantity:parameters.itemquantity, price:parameters.itemprice},{name: parameters.itemname2,quantity:parameters.itemquantity2, price:parameters.itemprice2}]};
                doc = await collection.insertOneAndGet(content);
                const key = doc.key;
                resolve(key);

            }
        }
        catch (err) {
          console.error(err);
          reject("error");
        }
        finally {
          if (connection) { try { await connection.close(); }
                      catch (err) { console.error(err); }
          }
        }

});
}

module.exports = {
  run: run
};
