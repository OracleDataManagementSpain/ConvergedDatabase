'use strict';

const oracledb = require('oracledb');
const dbConfig = require('./dbconfig.js');

oracledb.autoCommit = true;
    function run(parameters) {
return new Promise(async function(resolve, reject) {
        let connection, collection;

        try {
            let content, doc, res;
            connection = await oracledb.getConnection({
                user: dbConfig.user,
                password: dbConfig.password,
                connectString: dbConfig.connectString
            });


            const soda = connection.getSodaDatabase(); // Create the parent object for SODA
            collection = await soda.openCollection(dbConfig.collection);
              if (collection == null)
              {
                console.log('no existe la colección');
                reject("error");
              }else{
                let ts = Date.now();
                let date_ob = new Date(ts);
                let date = date_ob.getDate();
                let month = date_ob.getMonth() + 1;
                let year = date_ob.getFullYear();
                let fecha=date + "/" + month + "/" + year;
		let orderId=Math.floor(Math.random()* 1000) + 2000;
                console.log(fecha);
                console.log("parameters: "+JSON.stringify(parameters));
                content = {ORDER_ID: orderId, ORDER_MODE: 4, CUSTOMER_CLASS: "Ocassional", CUSTOMER_ID: 84, CUSTOMER_NAME: parameters.customer_name, CUSTOMER_SURNAME: parameters.customer_last_name, ORDER_DATE: fecha, STREET_NAME: parameters.address, TOWN: parameters.city, ORDER_TOTAL: parameters.price, ORDER_STATUS: 6, ITEMS: [{ ORDER_ID: orderId, LINE_ITEM_ID: 1, NAME: parameters.itemname, QUANTITY: parameters.itemquantity, UNIT_PRICE: parameters.itemprice, PRODUCT_ID: 589},{ORDER_ID:  orderId, LINE_ITEM_ID:2, NAME: parameters.itemname2, QUANTITY:parameters.itemquantity2, UNIT_PRICE:parameters.itemprice2, PRODUCT_ID: 623}]};
                doc = await collection.insertOneAndGet(content);
                const key = doc.key;
                resolve(key);

            }
        }
        catch (err) {
          console.error(err);
          reject("error");
        }
        finally {
          if (connection) { try { await connection.close(); }
                      catch (err) { console.error(err); }
          }
        }

});
}

module.exports = {
  run: run
};
