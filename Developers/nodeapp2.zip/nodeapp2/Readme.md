IMPORTANT!!!
Check Dockerfile for ENV variables to connect to a SODA enabled schema

 grant soda_app to user;

Create docker image

 podman build --tag nodeapp-container-oracle .


Run it!

 podman run -it -d --name app2 -p 3000:3000 nodeapp-container-oracle

Check logs

 podman logs app2

Check using curl (adapt collection name and doc id)

 curl http://localhost:3000/

Remove it 
 podman stop app2 && podman rm app2
