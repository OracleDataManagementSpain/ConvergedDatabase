'use strict';

const oracledb = require('oracledb');
const dbConfig = require('./dbconfig.js');
oracledb.autoCommit = true; // OK for simple operations


    function run() {
return new Promise(async function(resolve, reject) {
        let connection, collection;

        try {
            let content, doc, res;
            connection = await oracledb.getConnection({
	        user: dbConfig.user,
                password: dbConfig.password,
                connectString: dbConfig.connectString
            });

            if (oracledb.oracleClientVersion < 1803000000) {
              throw new Error('node-oracledb SODA requires Oracle Client libraries 18.3 or greater');
            }

            if (connection.oracleServerVersion < 1803000000) {
              throw new Error('node-oracledb SODA requires Oracle Database 18.3 or greater');
            }
            const soda = connection.getSodaDatabase(); // Create the parent object for SODA
            collection = await soda.openCollection("purchase_orders");
              if (collection)
              {
                let res = await collection.drop();
                if (res.dropped) {
                  console.log('Collection was dropped');
                  resolve('ok');
                }
              }
        }
        catch (err) {
          console.error(err);
          reject("error");
        }
        finally {
          if (connection) {
                try {
                    await connection.close();
                  } catch (err) {
                    console.error(err);
                  }
          }
        }

});
}

// Exporting check function
module.exports = {
  run: run
};
