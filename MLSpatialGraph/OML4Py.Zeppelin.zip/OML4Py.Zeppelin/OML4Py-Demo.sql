--###########################################################################
--##
--## Oracle Machine Learning for Python
--## Demo Script for Embedded Python Execution
--##
--## Copyright (c) 2020 Oracle and/or its affiliates. All rights reserved.
--##
--###########################################################################

--## Random Red Dots

BEGIN
    sys.pyqScriptDrop('RandomRedDots2');
    sys.pyqScriptCreate('RandomRedDots2',
'def RandomRedDots (num_dots_1=100, num_dots_2=10):
    import numpy as np
    import pandas as pd
    import matplotlib.pyplot as plt  

    d = {''id'': range(1,10), ''val'': [x/100 for x in range(1,10)]}
    df = pd.DataFrame(data=d)
    fig = plt.figure(1)
    ax = fig.add_subplot(111)
    ax.scatter(range(0,int(num_dots_1)), np.random.rand(int(num_dots_1)),c=''r'')
    fig.suptitle("Random Red Dots 2")

    fig2 = plt.figure(2)
    ax2 = fig2.add_subplot(111)
    ax2.scatter(range(0,int(num_dots_2)), np.random.rand(int(num_dots_2)),c=''r'')
    fig2.suptitle("Random Red Dots 2")
    return df', NULL, TRUE);
END;
/
--
-- Use function created above using SQL API
--
SELECT * FROM table(pyqEval(NULL,'PNG','RandomRedDots2'));
SELECT * FROM table(pyqEval(NULL,'select 1 id, 1 val from dual','RandomRedDots2'));
SELECT * FROM table(pyqEval(NULL,'XML','RandomRedDots2'));

--
-- Use function created using Python API
--
SELECT * FROM table(pyqEval(NULL,'PNG','RandomRedDots'));
SELECT * FROM table(pyqEval(NULL,'select 1 id, 1 val from dual','RandomRedDots'));
SELECT * FROM table(pyqEval(NULL,'XML','RandomRedDots'));

-- Pass arguments to change number of dots
SELECT * FROM table(pyqEval('select 500 "num_dots_1", 800 "num_dots_2" from dual',
                            'PNG', 'RandomRedDots'));
                            

--#####################################################
--##  End of Script
--#####################################################



