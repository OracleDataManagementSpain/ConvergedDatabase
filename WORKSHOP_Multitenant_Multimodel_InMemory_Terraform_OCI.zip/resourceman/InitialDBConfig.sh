#!/bin/bash

echo
echo -n "****Changing Connection Details....****"
echo

MYHOST=$(hostname)
MYDOMAIN=$(dnsdomainname)
CONTAINER=ORCL
MYPASS=WddFsdf_12_we2

echo
echo
echo -n "****Creating the database...****"
echo

sqlplus -s sys/$MYPASS as sysdba <<EOB

create pluggable database JSON admin user pdbadmin identified by WddFsdf_12_we2;
alter pluggable database JSON open read write;
alter session set container = JSON;
ADMINISTER KEY MANAGEMENT SET KEY FORCE KEYSTORE IDENTIFIED BY WddFsdf_12_we2 WITH BACKUP;

CONN / AS SYSDBA

create pluggable database SOE from JSON keystore identified by "WddFsdf_12_we2";
alter pluggable database soe open read write;

alter session set container= SOE;

create bigfile tablespace TBS_SSB datafile size 8G autoextend on maxsize 50G;
create bigfile tablespace TBS_SOE datafile size 8G autoextend on maxsize 50G;



EOB

echo -n "****Add Tnsnames Entries....****"
echo
#########Add tnsnames
echo "Change connection details"
echo

echo "Add alias to tnsnames"

MYTNS=`sed -n  "/$ORACLE_SID\(_\)[^ ]* =/,+8p" $ORACLE_HOME/network/admin/tnsnames.ora`

echo $MYTNS | sed 's/'$ORACLE_SID'\(_\)[^ ]*/JSON/1' | sed 's/'$ORACLE_SID'\(_\)[^.]*./json./1' >> $ORACLE_HOME/network/admin/tnsnames.ora
echo $MYTNS | sed 's/'$ORACLE_SID'\(_\)[^ ]*/SOE/1' | sed 's/'$ORACLE_SID'\(_\)[^.]*./soe./1' >> $ORACLE_HOME/network/admin/tnsnames.ora

cat $ORACLE_HOME/network/admin/tnsnames.ora

sqlplus -s system/WddFsdf_12_we2@SOE <<EOB2

CREATE DIRECTORY datapump_oracle AS '/home/oracle';

EOB2

echo -n "****Import Data....****"
echo

### importar SSB
wget https://objectstorage.eu-frankfurt-1.oraclecloud.com/p/H17FKhpOFlLwqQcPdLyQcrbpXFwIG0rZiZtuhVSyuzg/n/emeasespainsandbox/b/workshops/o/expdat.dmp
impdp system/WddFsdf_12_we2@SOE SCHEMAS=SSB logfile=IMPDP.SSB.log  PARALLEL=4 table_exists_action=truncate dumpfile=expdat.dmp DIRECTORY=datapump_oracle

rm expdat.dmp

### importar LINEORDER
wget https://objectstorage.eu-frankfurt-1.oraclecloud.com/p/sO4iQwY0hpGWeFCHei1rqZZ9CYAGsF4VOSFbExRRlP8/n/emeasespainsandbox/b/workshops/o/LINEORDER_NO_ACO.zip

unzip LINEORDER_NO_ACO.zip

impdp system/WddFsdf_12_we2@SOE directory=datapump_oracle dumpfile=LINEORDER_NO_ACO.dmp PARALLEL=4 table_exists_action=truncate logfile=LINEORDER_NO_ACO.log 

rm LINEORDER_NO_ACO.dmp 

### otros ficheros
wget https://objectstorage.eu-frankfurt-1.oraclecloud.com/p/lgpFzRMu_LfW826aEsjtKcRrngVrFxijPLtrfUHfV6k/n/emeasespainsandbox/b/workshops/o/FicherosTXTSecureFiles.zip

mkdir -p /home/oracle/sf/docs

mv FicherosTXTSecureFiles.zip /home/oracle/sf/docs
cd /home/oracle/sf/docs
unzip FicherosTXTSecureFiles.zip 


### descomprimir swingbench y crear usuario SOE
cd /home/oracle
wget https://objectstorage.eu-frankfurt-1.oraclecloud.com/p/tW3Z_kSZNza_Rhh83DJNTnumXqkebeS-iGg2pijhW60/n/emeasespainsandbox/b/workshops/o/swingbench.zip
unzip swingbench.zip

swingbench/bin/oewizard -create -scale 0.1 -cs //${MYHOST}:1521/soe.${MYDOMAIN} -dbap WddFsdf_12_we2 -ts USERS  -nopart -u soe -p WddFsdf_12_we2 -cl -allindexes -v

sqlplus -s sys/$MYPASS as sysdba <<EOB3

alter system set "_parallel_cluster_cache_policy"=cached scope=both;

EOB3

# ORDS

[ -f $ORACLE_HOME/ords/ords.war ] || find /u01/app/oracle  -name ords.war -exec cp {} $ORACLE_HOME/ords/ords.war \;

mkdir -p /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/ords/standalone/doc_root

$ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war configdir $ORACLE_HOME/ords/params; $ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war install simple --parameterFile $ORACLE_HOME/ords/params/ords_params.properties -silent

DOMAIN=`dnsdomainname`
DOMAIN=".$DOMAIN"
echo db.serviceNameSuffix=$DOMAIN > snsuffix.properties
$ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war set-properties --conf pool-name snsuffix.properties

$ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war standalone &
