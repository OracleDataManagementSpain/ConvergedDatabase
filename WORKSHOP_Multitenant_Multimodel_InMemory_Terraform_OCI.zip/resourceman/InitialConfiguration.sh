#!/bin/bash

MYHOST=$(hostname)
sed -i "s/myoracledb/${MYHOST}/" ords_params.properties


echo "oracle  ALL=(grid)      NOPASSWD: ALL" | sudo tee -a /etc/sudoers
sudo yum install jq -y

sudo service iptables stop
sudo cp InitialDBConfig.sh /home/oracle
sudo cp SQL2JSON.sql /home/oracle
#sudo cp swingbench.zip /home/oracle
#sudo cp expdat.dmp /home/oracle
sudo chown oracle:oinstall /home/oracle/InitialDBConfig.sh
#sudo chown oracle:oinstall /home/oracle/swingbench.zip
#sudo chown oracle:oinstall /home/oracle/expdat.dmp
sudo chmod +x /home/oracle/InitialDBConfig.sh
sudo rm -rf /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/*
sudo cp ords_params.properties /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/
sudo chown oracle:oinstall /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/ords_params.properties

echo "$@" | sudo tee -a /home/oracle/.ssh/authorized_keys
sudo su - oracle -c "./InitialDBConfig.sh"
