spool off;
set verify off;
Set Heading off
set echo off
set feedback off 

DECLARE
  fHandle  UTL_FILE.FILE_TYPE;
  c integer := 0;
  CURSOR c_order
  IS
        (select JSON_OBJECT (
      'ORDER_ID' value ORDER_ID,
      'ORDER_DATE' value ORDER_DATE,
      'ORDER_MODE' value ORDER_MODE,
      'CUSTOMER_ID' value CUSTOMER_ID,
      'ORDER_STATUS' value ORDER_STATUS,
      'ORDER_TOTAL' value ORDER_TOTAL,
      'SALES_REP_ID' value SALES_REP_ID,
      'PROMOTION_ID' value PROMOTION_ID,
      'WAREHOUSE_ID' value WAREHOUSE_ID,
      'DELIVERY_TYPE' value DELIVERY_TYPE,
      'COST_OF_DELIVERY' value COST_OF_DELIVERY,
      'WAIT_TILL_ALL_AVAILABLE' value WAIT_TILL_ALL_AVAILABLE,
      'DELIVERY_ADDRESS_ID' value DELIVERY_ADDRESS_ID,
      'CUSTOMER_CLASS' value CUSTOMER_CLASS,
      'CARD_ID' value CARD_ID,
      'INVOICE_ADDRESS_ID' value INVOICE_ADDRESS_ID,
      'ORDER_ITEMS' value (
          select JSON_ARRAYAGG(
              JSON_OBJECT (
              'LINE_ITEM_ID' value LINE_ITEM_ID,
              'PRODUCT_ID' value PRODUCT_ID,
              'UNIT_PRICE' value UNIT_PRICE,
              'QUANTITY' value QUANTITY,
              'DISPATCH_DATE' value DISPATCH_DATE,
              'RETURN_DATE' value RETURN_DATE,
              'GIFT_WRAP' value GIFT_WRAP,
              'CONDITION' value CONDITION,
              'SUPPLIER_ID' value SUPPLIER_ID,
              'ESTIMATED_DELIVERY' value ESTIMATED_DELIVERY
              )
            ) from ORDER_ITEMS I where O.ORDER_ID = I.ORDER_ID
        )
  ) as jsonorders from ORDERS O where rownum < 20);
BEGIN
  FOR r_order IN c_order
  LOOP
    fHandle := UTL_FILE.FOPEN('ORDERS', 'order_'||c||'.json', 'w',32767);
    UTL_FILE.PUT_LINE(fHandle, r_order.jsonorders);
    UTL_FILE.FCLOSE(fHandle);
    c := c + 1;
  END LOOP;
END;
/
