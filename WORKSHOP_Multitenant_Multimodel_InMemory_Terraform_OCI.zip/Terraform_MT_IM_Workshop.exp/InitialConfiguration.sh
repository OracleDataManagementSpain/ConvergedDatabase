#!/bin/bash

sudo service iptables stop
sudo cp InitialDBConfig.sh /home/oracle
sudo cp SQL2JSON.sql /home/oracle
sudo chown oracle:oinstall /home/oracle/InitialDBConfig.sh
sudo chmod +x /home/oracle/InitialDBConfig.sh
sudo rm -rf /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/*
sudo cp ords_params.properties /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/
sudo chown oracle:oinstall /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/ords_params.properties
sudo su - oracle -c "./InitialDBConfig.sh"
