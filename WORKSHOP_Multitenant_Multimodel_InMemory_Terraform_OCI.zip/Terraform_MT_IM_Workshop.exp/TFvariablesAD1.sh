
export TF_VAR_tenancy_ocid=ocid1.tenancy.oc1..aaaaaaaaym5r54fkxtse6kw3btbn4bzsvenhq6jquh57l6k256pydkohm5ua
export TF_VAR_compartment_ocid=ocid1.compartment.oc1..aaaaaaaaaebllbateermoav6tdlyfzwrslt2iugzgztd7rtj4ublrjzro52q
export TF_VAR_user_ocid=ocid1.user.oc1..aaaaaaaaaqtyuvrzutpl4psyeulbqwaqhaizwnbeevcf4g4y6vamu6z5g77q
export TF_VAR_fingerprint=66:5b:d0:a3:60:44:59:b8:b0:45:c0:1a:bb:24:ef:0f
export TF_VAR_private_key_path=./privatekey
export TF_VAR_ssh_public_key=$(cat ./publickey.pub)
export TF_VAR_region=eu-frankfurt-1
export TF_VAR_comp_ad_num=1
