#!/bin/bash


echo
echo -n "****Changing Connection Details....****"
echo

MYHOST=myoracledb
CONTAINER=ORCL
MYPASS=WddFsdf_12_we2

echo
echo
echo -n "****Creating the database...****"
echo

sqlplus -s sys/$MYPASS as sysdba <<EOB

create pluggable database JSON admin user pdbadmin identified by WddFsdf_12_we2;
alter pluggable database JSON open read write;
alter session set container = JSON;
ADMINISTER KEY MANAGEMENT SET KEY FORCE KEYSTORE IDENTIFIED BY WddFsdf_12_we2 WITH BACKUP;

CONN / AS SYSDBA        

create pluggable database SOE from JSON keystore identified by "WddFsdf_12_we2";
alter pluggable database soe open read write;

alter session set container= SOE;

-- ### En el caso de workshop IM de Stephane ###

create public database link pdbimc.sub03010825490.devopsvcn.oraclevcn.com connect to system identified by "AaZZ0r_cle#1" using '158.101.164.85:1521/pdbimc.sub03010825490.devopsvcn.oraclevcn.com';

select * from dual@pdbimc.sub03010825490.devopsvcn.oraclevcn.com;

create bigfile tablespace TBS_SH datafile size 8G autoextend on maxsize 50G;
create bigfile tablespace TBS_SSB datafile size 8G autoextend on maxsize 50G;
create bigfile tablespace TBS_SOE datafile size 8G autoextend on maxsize 50G;

-- ### En el caso de workshop IM de Guillermo ###

--create bigfile tablespace USERS datafile size 8G autoextend on maxsize 50G;



EOB

echo -n "****Add Tnsnames Entries....****"
echo
#########Add tnsnames
echo "Change connection details"
echo

echo "Add alias to tnsnames"

MYTNS=`sed -n  "/$ORACLE_SID\(_\)[^ ]* =/,+8p" $ORACLE_HOME/network/admin/tnsnames.ora`

echo $MYTNS | sed 's/'$ORACLE_SID'\(_\)[^ ]*/JSON/1' | sed 's/'$ORACLE_SID'\(_\)[^.]*./json./1' >> $ORACLE_HOME/network/admin/tnsnames.ora
echo $MYTNS | sed 's/'$ORACLE_SID'\(_\)[^ ]*/SOE/1' | sed 's/'$ORACLE_SID'\(_\)[^.]*./soe./1' >> $ORACLE_HOME/network/admin/tnsnames.ora

cat $ORACLE_HOME/network/admin/tnsnames.ora

echo -n "****Import Data....****"
echo

impdp system/WddFsdf_12_we2@SOE SCHEMAS=SH,SSB,SOE logfile=IMPDP.SH.SSB.SOE.log NETWORK_LINK=pdbimc.sub03010825490.devopsvcn.oraclevcn.com PARALLEL=4

## ./oewizard -create -scale 0.6 -cs //158.101.165.176:1521/soe.tfexsubdbsys.tfexvcndbsys.oraclevcn.com -dbap WddFsdf_12_we2 -ts USERS  -nopart -u soe -p WddFsdf_12_we2 -cl -allindexes -v

sqlplus -s sys/$MYPASS as sysdba <<EOB2

alter system set "_parallel_cluster_cache_policy"=cached scope=both;

EOB2

mkdir -p /u01/app/oracle/product/19.0.0.0/dbhome_1/ords/params/ords/standalone/doc_root

$ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war configdir $ORACLE_HOME/ords/params; $ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war install simple --parameterFile $ORACLE_HOME/ords/params/ords_params.properties -silent 

DOMAIN=`dnsdomainname`
DOMAIN=".$DOMAIN"
echo db.serviceNameSuffix=$DOMAIN > snsuffix.properties
$ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war set-properties --conf pool-name snsuffix.properties

$ORACLE_HOME/jdk/bin/java -jar $ORACLE_HOME/ords/ords.war standalone &


mkdir /u01/app/oracle/oradata
