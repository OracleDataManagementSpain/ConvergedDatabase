package com.orcl.graph;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;

/*
 * this is to store this json response, see also Value.java
 * 
 * {
 *  "statements": [
 *   "SELECT v FROM MATCH (v) ON TEST_GRAPH LIMIT 1"
 * ],
 * "driver": "GRAPH_SERVER_PGXE",
 * "formatter": "GVT",
 * "parameters": {
 *   "dynamicSampling": 2,
 *   "parallel": 8,
 *   "start": 0,
 *   "size": 100
 * },
 * "visualize": true
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GraphQuery(List<String> statements, String driver, String formatter, GraphQueryProperties parameters, Boolean visualize) { }

