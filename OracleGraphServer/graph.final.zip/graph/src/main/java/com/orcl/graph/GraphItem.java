package com.orcl.graph;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/*
 * [
 *  {
 *      "schema": <value>,
 *      "graphName": <value>
 *  }
 *]
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public record GraphItem (String schema, String graphName){
    
}
