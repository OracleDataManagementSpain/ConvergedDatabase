package com.orcl.graph;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.HttpClientErrorException;
import java.util.List;
import java.util.ArrayList;


@SpringBootApplication
@RestController
public class GraphApplication {

  private static final Logger log = LoggerFactory.getLogger(GraphApplication.class);
  private String token = null;
  private long token_timestamp = 0L;
  private long token_validity = 0L;

  private String user = "soe";
  private String password = "soe";
  private String pgxURL = "https://localhost:7007/";
  private String driver = "GRAPH_SERVER_PGX";



	public static void main(String[] args) {
		SpringApplication.run(GraphApplication.class, args);
	}

    @GetMapping("/graph")
    public String hello(@RequestParam(value = "name", defaultValue = "Bruce") String name) {
      return String.format("Be graph, my friend %s!", name);
    }

   // curl --location --request GET 'https://localhost:7007/v2/graphs?driver=<driver-value>' \
   // --header 'Authorization: Bearer <token>'
    @GetMapping("/getgraphs")
    public String getGraphs(@RequestParam(value = "name", defaultValue = "Bruce") String name,RestTemplate restTemplate) {
      pgx_login(restTemplate);
      String result = "";
      HttpHeaders requestHeaders = new HttpHeaders();
      requestHeaders.set("Authorization", "Bearer "+token);

      HttpEntity<?> requestEntity = new HttpEntity<Object>(requestHeaders);
      restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
      
      try {
        ResponseEntity<GraphItem[]> responseEntity = restTemplate.exchange(pgxURL+"v2/graphs?driver="+driver, HttpMethod.GET, requestEntity, GraphItem[].class);
        GraphItem[] gis = responseEntity.getBody();

        StringBuffer graphList = new StringBuffer("Availabe graphs: ");
        for (GraphItem gi: gis)
          graphList.append(gi.graphName()+",");

        graphList.deleteCharAt(graphList.length() - 1);
        graphList.append(".");
        result=graphList.toString();
      } catch (HttpClientErrorException e) {
        log.error("Error Status code: " + e.getStatusCode() + "  reason: " + e.getStatusText());
        token = null;
        pgx_login(restTemplate);
      }
      
      return result;
    } 


    @GetMapping("/exeQuery1")
    public String exeQuery1(@RequestParam(value = "source", defaultValue = "380") String source, 
                            @RequestParam(value = "destination", defaultValue = "786") String destination,
                             RestTemplate restTemplate) {

      HttpHeaders requestHeaders = new HttpHeaders();
      String result="";
      pgx_login(restTemplate);

      requestHeaders.set("Authorization", "Bearer " + token);

      // "dynamicSampling": 2,"parallel": 8, "start": 0, "size": 100  
      GraphQueryProperties parameters = new GraphQueryProperties(2,8,0,200);
      
      List<String> statements = new ArrayList<String>();
      String pgql = String.format("SELECT a1, b, a2 FROM MATCH TOP 3 SHORTEST (e1) (-[r]->(v))+ (e2) ONE ROW PER STEP (a1, b, a2) ON bankpv WHERE e1.ID = %s AND e2.ID = %s", source, destination);
      statements.add(pgql);
      //  statements [], "driver": "GRAPH_SERVER_PGXE", "formatter": "GVT", parameters, "visualize": true
      GraphQuery gq = new GraphQuery(statements, driver, "GVT", parameters, true);
      

      log.info("PGQl query: "+ pgql);
      log.info("Query " + gq.toString());

      HttpEntity<?> requestEntity = new HttpEntity<Object>(gq,requestHeaders);
      restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
      
      try {
        ResponseEntity<GraphQueryResponse> responseEntity = restTemplate.exchange(pgxURL+"v2/runQuery", HttpMethod.POST, requestEntity, GraphQueryResponse.class);
        GraphQueryResponse gqr = responseEntity.getBody();
        result = gqr.results().get(0).result();
      } catch (HttpClientErrorException e) {
        log.error("Error Status code: " + e.getStatusCode() + "  reason: " + e.getStatusText());
        token = null;
        pgx_login(restTemplate);
      }
      
      return result;
    } 



    @Bean
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
      return builder.build();
    }
  
    @Bean
    @Profile("!test")
    public CommandLineRunner run(RestTemplate restTemplate) throws Exception {
      return args -> {
        pgx_login(restTemplate);
      };
    }


    private void pgx_login(RestTemplate restTemplate){

      if (token ==null){
        GraphUser gu = new GraphUser(user,password,"true");
        GraphLoginResponse glr = restTemplate.postForObject(
          pgxURL+"auth/token", gu, GraphLoginResponse.class);
        token = glr.access_token();
        log.info("Token (partial): "+ token.substring(0, 80) + "...");
      } else {
        log.info("Reusing existing token");
      }

    }


}
