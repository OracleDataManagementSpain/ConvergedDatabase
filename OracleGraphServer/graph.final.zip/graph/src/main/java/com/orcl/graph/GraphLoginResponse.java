package com.orcl.graph;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * {
 *   "access_token": "<token>"
 *   "token_type": "bearer",
 *   "expires_in": 3600
 *}
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GraphLoginResponse (String access_token, String token_type, Long expires_in){}

