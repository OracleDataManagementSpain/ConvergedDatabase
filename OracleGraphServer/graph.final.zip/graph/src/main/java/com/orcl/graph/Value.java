package com.orcl.graph;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * this is to store this json response, see also Quote.java
 * 
 * {
 *  type: "success",
 *  value: {
 *    id: 10,
 *     quote: "Really loving Spring Boot, makes stand alone Spring apps easy."
 *  }
 * }
 * 
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public record Value(Long id, String quote) { }