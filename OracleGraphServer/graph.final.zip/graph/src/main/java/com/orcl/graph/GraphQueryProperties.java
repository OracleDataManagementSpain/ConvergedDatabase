package com.orcl.graph;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * this is to store this json response, see also Value.java
 * 
 * "parameters": {
 *   "dynamicSampling": 2,
 *   "parallel": 8,
 *   "start": 0,
 *   "size": 100  
 * }
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GraphQueryProperties(Integer dynamicSampling, Integer parallel, Integer start, Integer size) { }

