package com.orcl.graph;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*

        {
            "pgqlStatement": "SELECT v FROM MATCH (v) ON TEST_GRAPH LIMIT 1",
            "result": "{\"schema\":\"GRAPHUSER\",\"name\":\"TEST_GRAPH\",\"resultSetId\":\"\",\"graph\":{\"vertices\":[{\"id\":\"MALE(0)\",\"properties\":{\"AGE\":\"40\",\"BVAL\":\"Y\",\"LNAME\":\"Brown\",\"FNAME\":\"Bill\",\"PREFERENCES\":\"{ \\\"color\\\": \\\"blue\\\", \\\"number\\\": \\\"5\\\" }\",\"ID\":\"0\",\"TEXT\":\"the cat sat on the mat\",\"MVAL\":\"y\"}}],\"edges\":[],\"numResults\":1},\"table\":\"V\\nMALE(0)\"}",
   
  
 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GraphGVTResult (String schema, String name, String resultSetId, String graph, String table){}

