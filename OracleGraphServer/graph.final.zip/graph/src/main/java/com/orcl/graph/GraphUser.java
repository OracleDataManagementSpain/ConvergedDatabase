package com.orcl.graph;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/*
 * this is to store this json response, see also Value.java
 * 
 * {
 *   "username": "graphuser",
 *   "password": "<password_for_graphuser>",
 *   "createSession": true 
 *}
 * 
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record GraphUser(String username, String password, String createSession) { }
