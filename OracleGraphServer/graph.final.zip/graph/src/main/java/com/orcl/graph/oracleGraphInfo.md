
# REST request for PGX 23.4 api v2


## Request for login


curl --location 'https://localhost:7007/auth/token' \
--header 'Content-Type: application/json' \
--data '{ 
    "username": "graphuser",
    "password": "<password_for_graphuser>",
    "createSession": true 
}'

{
    "username": "graphuser",
    "password": "<password_for_graphuser>",
    "createSession": true 
}


## Response for login

{
    "access_token": "<token>"
    "token_type": "bearer",
    "expires_in": 3600
}

## Request for graph listing

curl --location --request GET 'https://localhost:7007/v2/graphs?driver=GRAPH_SERVER_PGX' \
--header 'Authorization: Bearer <token>'

## Response for graph listing

[
    {
        "schema": <value>,
        "graphName": <value>
    }
]

## Request for query

curl --location --request POST 'https://localhost:7007/v2/runQuery' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer <token>' \
--data '{
  "statements": [
    "SELECT v FROM MATCH (v) ON TEST_GRAPH LIMIT 1"
  ],
  "driver": "GRAPH_SERVER_PGXE",
  "formatter": "GVT",
  "parameters": {
    "dynamicSampling": 2,
    "parallel": 8,
    "start": 0,
    "size": 100  
  },
  "visualize": true
}'


{
  "statements": [
    "SELECT v FROM MATCH (v) ON TEST_GRAPH LIMIT 1"
  ],
  "driver": "GRAPH_SERVER_PGXE",
  "formatter": "GVT",
  "parameters": {
    "dynamicSampling": 2,
    "parallel": 8,
    "start": 0,
    "size": 100
  },
  "visualize": true

## Response for query

{
    "results": [
        {
            "pgqlStatement": "DROP PROPERTY GRAPH TEST_GRAPH",
            "result": "Graph successfully dropped",
            "success": true,
            "error": null,
            "started": 1689656429130,
            "ended": 1689656429198
        },
        {
            "pgqlStatement": "SELECT v FROM MATCH (v) ON TEST_GRAPH LIMIT 1",
            "result": "{\"schema\":\"GRAPHUSER\",\"name\":\"TEST_GRAPH\",\"resultSetId\":\"\",\"graph\":{\"vertices\":[{\"id\":\"MALE(0)\",\"properties\":{\"AGE\":\"40\",\"BVAL\":\"Y\",\"LNAME\":\"Brown\",\"FNAME\":\"Bill\",\"PREFERENCES\":\"{ \\\"color\\\": \\\"blue\\\", \\\"number\\\": \\\"5\\\" }\",\"ID\":\"0\",\"TEXT\":\"the cat sat on the mat\",\"MVAL\":\"y\"}}],\"edges\":[],\"numResults\":1},\"table\":\"V\\nMALE(0)\"}",
            "success": true,
            "error": null,
            "started": 1689656429458,
            "ended": 1689656430029
        }
    ]
}