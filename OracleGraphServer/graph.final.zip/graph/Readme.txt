# Import certificates to java 17

´´´
sudo -i
export JAVA_HOME=/usr/java/jdk-17
export PATH=$JAVA_HOME/bin:$PATH
keytool -importkeystore -srckeystore /etc/oracle/graph/server_keystore.jks  -destkeystore $JAVA_HOME/lib/security/cacerts -deststorepass changeit   -srcstorepass changeit -noprompt
´´´
# Running the app

´´´
export JAVA_HOME=/usr/java/jdk-17
export PATH=$JAVA_HOME/bin:$PATH
./gradlew bootRun
´´´

# Creating a jar for the application

´´´
export JAVA_HOME=/usr/java/jdk-17
export PATH=$JAVA_HOME/bin:$PATH
./gradlew bootJar

java -jar build/libs/graph-0.0.1-SNAPSHOT.jar
´´´


# Loading a graph to PGX using Jshell


´´´
cd /opt/oracle/graph
./bin/opg4j --base_url https://localhost:7007 --username soe
var fullGraph = session.readGraphByName("BANKPV", GraphSource.PG_VIEW);
fullGraph.publish()
fullGraph.pin()
´´´

# Testing urls

http://localhost:8090/content/index.html


Smoke test: http://localhost:8090/graph?name=John

Get the list of available graphs: http://localhost:8090/getgraphs
Run Query: http://localhost:8090/exeQuery1?source=386&destination=781 


http://localhost:8090/content/index.html

# VScode extensions

To develop a Spring Boot application in Visual Studio Code, you need to install the following:

   * Java Development Kit (JDK)
   * Extension Pack for Java
   * Spring Boot Extension Pack


curl -k --location --request POST 'https://localhost:7007/v2/runQuery' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer eyJraWQiOiJEYXRhYmFzZVJlYWxtIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJTT0UiLCJyb2xlcyI6WyJHUkFQSF9ERVZFTE9QRVIiLCJQWVFBRE1JTiIsIkNPTk5FQ1QiLCJSRVNPVVJDRSJdLCJnZW5lcmFsX3Blcm1pc3Npb25zIjpbIlBHWF9TRVNTSU9OX0FERF9QVUJMSVNIRURfR1JBUEgiLCJQR1hfU0VTU0lPTl9HRVRfUFVCTElTSEVEX0dSQVBIIiwiUEdYX1NFU1NJT05fTU9ESUZZX01PREVMIiwiUEdYX1NFU1NJT05fUkVBRF9NT0RFTCIsIlNPREFfQVBQIiwiUEdYX1NFU1NJT05fQ1JFQVRFIiwiUEdYX1NFU1NJT05fTkVXX0dSQVBIIl0sInJlZnJlc2hfdGltZV9iZWZvcmVfdG9rZW5fZXhwaXJ5X3NlY29uZHMiOjE4MDAsImlzcyI6Im9yYWNsZS5wZy5pZGVudGl0eS5yZXN0LnNlcnZpY2UuQXV0aGVudGljYXRpb25TZXJ2aWNlIiwicGd4X3Nlc3Npb25fYXR0YWNoZWRfdG9fdG9rZW4iOiI0MzgzYzJlOC02ZTkyLTQ4NTEtOWY3Mi1kZjJhMzgwMGU0NGYiLCJpc19wZ3hfc2Vzc2lvbl9wcm92aWRlZF9leHRlcm5hbGx5IjpmYWxzZSwiZXhwIjoxNzAxNjk0ODQ3LCJudW1fdG9rZW5fcmVmcmVzaCI6MCwiZmlsZV9wZXJtaXNzaW9ucyI6e319.MgLqzwMhTMembY3u8crnIvchSEG3daOWsCHeKdAF9nUuFXFJYA2IDS0lXFgiFjVOwK45HR97VlTQA9-Vjq9APSW6Kzo3eUFY9l6YgRi20gvnFktTm7saGdxkLKWweZRfiFNgSLU0gZDGbPu_uPoTzWMfNY3RfMECLnxXCwzX6xZOJJmkdrgsJ2S4pXc-v5urFq2d0GD2smaKPOnK3t_kuIPG7Ja-2eXJvnnHBhYdkVQLthfu5OTp_OorZTWDGQoTXXWmbA3-sfYws_8GOhFfoGzPtB4xBslIjITslR82zH2FDGQ_selr5IvuHFdzRCOO9Ltvt0-GQnET8swLPG5Eyw' \
--data '{"statements":["SELECT v FROM MATCH (v) ON BANKPV LIMIT 1"], "driver":"GRAPH_SERVER_PGX", "formatter":"GVT", "parameters":{"dynamicSampling":2, "parallel":8, "start":0, "size":200}, "visualize":true}'

curl -k --location --request POST 'https://localhost:7007/v2/runQuery' \
--header 'Content-Type: application/json' \
--header 'Authorization: Bearer eyJraWQiOiJEYXRhYmFzZVJlYWxtIiwiYWxnIjoiUlMyNTYifQ.eyJzdWIiOiJTT0UiLCJyb2xlcyI6WyJHUkFQSF9ERVZFTE9QRVIiLCJQWVFBRE1JTiIsIkNPTk5FQ1QiLCJSRVNPVVJDRSJdLCJnZW5lcmFsX3Blcm1pc3Npb25zIjpbIlBHWF9TRVNTSU9OX0FERF9QVUJMSVNIRURfR1JBUEgiLCJQR1hfU0VTU0lPTl9HRVRfUFVCTElTSEVEX0dSQVBIIiwiUEdYX1NFU1NJT05fTU9ESUZZX01PREVMIiwiUEdYX1NFU1NJT05fUkVBRF9NT0RFTCIsIlNPREFfQVBQIiwiUEdYX1NFU1NJT05fQ1JFQVRFIiwiUEdYX1NFU1NJT05fTkVXX0dSQVBIIl0sInJlZnJlc2hfdGltZV9iZWZvcmVfdG9rZW5fZXhwaXJ5X3NlY29uZHMiOjE4MDAsImlzcyI6Im9yYWNsZS5wZy5pZGVudGl0eS5yZXN0LnNlcnZpY2UuQXV0aGVudGljYXRpb25TZXJ2aWNlIiwicGd4X3Nlc3Npb25fYXR0YWNoZWRfdG9fdG9rZW4iOiI0MzgzYzJlOC02ZTkyLTQ4NTEtOWY3Mi1kZjJhMzgwMGU0NGYiLCJpc19wZ3hfc2Vzc2lvbl9wcm92aWRlZF9leHRlcm5hbGx5IjpmYWxzZSwiZXhwIjoxNzAxNjk0ODQ3LCJudW1fdG9rZW5fcmVmcmVzaCI6MCwiZmlsZV9wZXJtaXNzaW9ucyI6e319.MgLqzwMhTMembY3u8crnIvchSEG3daOWsCHeKdAF9nUuFXFJYA2IDS0lXFgiFjVOwK45HR97VlTQA9-Vjq9APSW6Kzo3eUFY9l6YgRi20gvnFktTm7saGdxkLKWweZRfiFNgSLU0gZDGbPu_uPoTzWMfNY3RfMECLnxXCwzX6xZOJJmkdrgsJ2S4pXc-v5urFq2d0GD2smaKPOnK3t_kuIPG7Ja-2eXJvnnHBhYdkVQLthfu5OTp_OorZTWDGQoTXXWmbA3-sfYws_8GOhFfoGzPtB4xBslIjITslR82zH2FDGQ_selr5IvuHFdzRCOO9Ltvt0-GQnET8swLPG5Eyw' \
--data '{
  "statements": [
    "SELECT v FROM MATCH (v) ON BANKPV LIMIT 1"
  ],
  "driver": "GRAPH_SERVER_PGX",
  "formatter": "GVT",
  "parameters": {
    "dynamicSampling": 2,
    "parallel": 8,
    "start": 0,
    "size": 100  
  },
  "visualize": true
}'


{"statements"=["SELECT v FROM MATCH (v) ON BANKPV LIMIT 1"], "driver"="GRAPH_SERVER_PGX", "formatter"="GVT", "parameters"={"dynamicSampling"=2, "parallel"=8, "start"=0, "size"=200}, "visualize"=true}

{"results":[{"pgqlStatement":"SELECT v FROM MATCH (v) ON BANKPV LIMIT 1","result":"{\"schema\":null,\"name\":\"BANKPV\",\"resultSetId\":\"pgql_5\",\"graph\":{\"vertices\":[{\"id\":\"ACCOUNTS(1)\",\"properties\":{\"ID\":\"1\",\"ACCT_TYPE\":\"1\",\"NAME\":\"Account\"}}],\"edges\":[],\"numResults\":1},\"table\":\"V\\nPgxVertex[provider=ACCOUNTS,key=1,ID=ACCOUNTS(1)]\"}","success":true,"error":null,"started":1701688315969,"ended":1701688316773}]}