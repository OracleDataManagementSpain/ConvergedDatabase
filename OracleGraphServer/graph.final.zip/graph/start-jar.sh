#!/bin/bash


export JAVA_HOME=/usr/java/jdk-17
export PATH=$JAVA_HOME/bin:$PATH

cd /home/oracle/springboot/graph 
java -jar build/libs/graph-0.0.1-SNAPSHOT.jar

